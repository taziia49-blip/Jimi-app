package com.example.data

import android.content.Context
import com.example.ui.i18n.AppLanguage
import com.example.ui.model.AppSettings
import com.example.ui.model.BgChangeSpeed
import com.example.ui.model.FantasyBackground
import com.example.ui.model.RobotPersonality
import com.example.ui.model.VoiceSpeedOption
import com.example.ui.model.VoiceType

class SettingsRepository(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(
        "jimi_fantasy_ai_settings_v2",
        Context.MODE_PRIVATE
    )

    fun load(): AppSettings {
        val bg = runCatching {
            FantasyBackground.valueOf(
                prefs.getString(KEY_BG, FantasyBackground.MAGICAL_CASTLE.name)!!
            )
        }.getOrDefault(FantasyBackground.MAGICAL_CASTLE)

        val bgSpeed = runCatching {
            BgChangeSpeed.valueOf(
                prefs.getString(KEY_BG_SPEED, BgChangeSpeed.AUTO_8S.name)!!
            )
        }.getOrDefault(BgChangeSpeed.AUTO_8S)

        val language = runCatching {
            AppLanguage.valueOf(
                prefs.getString(KEY_LANGUAGE, AppLanguage.DARIJA.name)!!
            )
        }.getOrDefault(AppLanguage.DARIJA)

        val voiceType = runCatching {
            VoiceType.valueOf(
                prefs.getString(KEY_VOICE_TYPE, VoiceType.FEMALE.name)!!
            )
        }.getOrDefault(VoiceType.FEMALE)

        val voiceSpeed = runCatching {
            VoiceSpeedOption.valueOf(
                prefs.getString(KEY_VOICE_SPEED, VoiceSpeedOption.NORMAL.name)!!
            )
        }.getOrDefault(VoiceSpeedOption.NORMAL)

        val personality = runCatching {
            RobotPersonality.valueOf(
                prefs.getString(KEY_ROBOT_PERSONALITY, RobotPersonality.FRIEND.name)!!
            )
        }.getOrDefault(RobotPersonality.FRIEND)

        return AppSettings(
            autoChangeBackground = prefs.getBoolean(KEY_AUTO_BG, true),
            backgroundChangeSpeed = bgSpeed,
            selectedBackground = bg,
            customBackgroundPath = prefs.getString(KEY_CUSTOM_BG_PATH, null),
            useCustomBackground = prefs.getBoolean(KEY_USE_CUSTOM_BG, false),
            language = language,
            voiceEnabled = prefs.getBoolean(KEY_VOICE_ENABLED, true),
            voiceType = voiceType,
            voiceSpeed = voiceSpeed,
            robotName = prefs.getString(KEY_ROBOT_NAME, "JIMI")?.ifBlank { "JIMI" } ?: "JIMI",
            robotPersonality = personality,
            isDarkMode = prefs.getBoolean(KEY_DARK_MODE, false),
            wakeWordEnabled = prefs.getBoolean(KEY_WAKE_WORD, false),
            floatingOrbOnRight = prefs.getBoolean(KEY_ORB_ON_RIGHT, true),
            floatingOrbYFraction = prefs.getFloat(KEY_ORB_Y_FRAC, -1f),
            cachedBgDate = prefs.getString(KEY_CACHED_BG_DATE, "") ?: "",
            geminiApiKey = prefs.getString(KEY_GEMINI_API_KEY, "")?.trim() ?: ""
        )
    }

    fun save(settings: AppSettings) {
        prefs.edit()
            .putBoolean(KEY_AUTO_BG, settings.autoChangeBackground)
            .putString(KEY_BG_SPEED, settings.backgroundChangeSpeed.name)
            .putString(KEY_BG, settings.selectedBackground.name)
            .putString(KEY_CUSTOM_BG_PATH, settings.customBackgroundPath)
            .putBoolean(KEY_USE_CUSTOM_BG, settings.useCustomBackground)
            .putString(KEY_LANGUAGE, settings.language.name)
            .putBoolean(KEY_VOICE_ENABLED, settings.voiceEnabled)
            .putString(KEY_VOICE_TYPE, settings.voiceType.name)
            .putString(KEY_VOICE_SPEED, settings.voiceSpeed.name)
            .putString(KEY_ROBOT_NAME, settings.robotName)
            .putString(KEY_ROBOT_PERSONALITY, settings.robotPersonality.name)
            .putBoolean(KEY_DARK_MODE, settings.isDarkMode)
            .putBoolean(KEY_WAKE_WORD, settings.wakeWordEnabled)
            .putBoolean(KEY_ORB_ON_RIGHT, settings.floatingOrbOnRight)
            .putFloat(KEY_ORB_Y_FRAC, settings.floatingOrbYFraction)
            .putString(KEY_CACHED_BG_DATE, settings.cachedBgDate)
            .putString(KEY_GEMINI_API_KEY, settings.geminiApiKey.trim())
            .apply()
    }

    private companion object {
        const val KEY_AUTO_BG = "auto_bg"
        const val KEY_BG_SPEED = "bg_speed"
        const val KEY_BG = "selected_bg"
        const val KEY_CUSTOM_BG_PATH = "custom_bg_path"
        const val KEY_USE_CUSTOM_BG = "use_custom_bg"
        const val KEY_LANGUAGE = "language"
        const val KEY_VOICE_ENABLED = "voice_enabled"
        const val KEY_VOICE_TYPE = "voice_type"
        const val KEY_VOICE_SPEED = "voice_speed"
        const val KEY_ROBOT_NAME = "robot_name"
        const val KEY_ROBOT_PERSONALITY = "robot_personality"
        const val KEY_DARK_MODE = "dark_mode"
        const val KEY_WAKE_WORD = "wake_word_enabled"
        const val KEY_ORB_ON_RIGHT = "floating_orb_on_right"
        const val KEY_ORB_Y_FRAC = "floating_orb_y_fraction"
        const val KEY_CACHED_BG_DATE = "cached_bg_date"
        const val KEY_GEMINI_API_KEY = "user_gemini_api_key"
    }
}
