package com.example.device

sealed interface JimiIntent {
    data object WakeUpOnly : JimiIntent
    data object OpenYouTube : JimiIntent
    data object OpenWhatsApp : JimiIntent
    data object OpenTikTok : JimiIntent
    data object ChangeBackground : JimiIntent
    data class SetFlashlight(val on: Boolean) : JimiIntent
    data object ToggleFlashlight : JimiIntent
    data object VibratePhone : JimiIntent
    data class AdjustVolume(val increase: Boolean) : JimiIntent
    data object MuteVolume : JimiIntent
    data object OpenSettings : JimiIntent
    data class AskJimiQuestion(val question: String, val wokeWithKeyword: Boolean) : JimiIntent
}

object JimiCommandParser {

    private val wakeKeywords = listOf(
        "hey jimi",
        "ok jimi",
        "hi jimi",
        "hello jimi",
        "يا جيمي",
        "ألو جيمي",
        "الو جيمي",
        "اهلا جيمي",
        "أهلا جيمي",
        "jimi",
        "jimmy",
        "جيمي",
        "جيمى"
    )

    fun containsWakeWord(rawText: String): Boolean {
        val lower = normalize(rawText)
        return wakeKeywords.any { kw -> lower.contains(kw) }
    }

    fun parse(rawText: String, alreadyAwake: Boolean = false): JimiIntent {
        val original = rawText.trim()
        val wokeWithKeyword = containsWakeWord(original)
        val stripped = stripWakeWord(original)
        val cmd = normalize(stripped)

        if (wokeWithKeyword && cmd.isBlank()) {
            return JimiIntent.WakeUpOnly
        }

        if (!wokeWithKeyword && !alreadyAwake && cmd.isBlank()) {
            return JimiIntent.WakeUpOnly
        }

        // Check WhatsApp
        if (cmd.containsAny("whatsapp", "whats app", "watsapp", "واتساب", "واتس اب", "الواتس", "واتس")) {
            return JimiIntent.OpenWhatsApp
        }

        // Check YouTube
        if (cmd.containsAny("youtube", "you tube", "utube", "يوتيوب", "يوتوب", "اليوتيوب")) {
            return JimiIntent.OpenYouTube
        }

        // Check TikTok
        if (cmd.containsAny("tiktok", "tik tok", "تيك توك", "تيكتوك", "التيك توك")) {
            return JimiIntent.OpenTikTok
        }

        // Check Change Background
        if (cmd.containsAny(
                "بدل الخلفية", "غير الخلفية", "تبديل الخلفية", "تغيير الخلفية", "خلفيه", "الخلفية",
                "change background", "switch background", "next background", "background",
                "changer fond", "changer l'arriere", "arriere-plan", "fond"
            )
        ) {
            return JimiIntent.ChangeBackground
        }

        // Check Flashlight OFF
        if (cmd.containsAny(
                "طفي الفلاش", "اطفي الفلاش", "اقفل الفلاش", "سكت الفلاش", "اطفاء الفلاش",
                "turn off flash", "flash off", "flashlight off", "torch off",
                "eteins flash", "etaindre flash", "coupe flash"
            )
        ) {
            return JimiIntent.SetFlashlight(on = false)
        }

        // Check Flashlight ON
        if (cmd.containsAny(
                "شعل الفلاش", "افتح الفلاش", "ضوي الفلاش", "تشغيل الفلاش", "فلاش",
                "turn on flash", "flash on", "flashlight", "torch on",
                "allume flash", "lampe"
            )
        ) {
            return JimiIntent.SetFlashlight(on = true)
        }

        // Check Vibrate
        if (cmd.containsAny(
                "اهتزاز", "هز الهاتف", "هز التلفون", "رجة", "هز",
                "vibrate", "vibration", "vibrer", "vibre"
            )
        ) {
            return JimiIntent.VibratePhone
        }

        // Check Volume Mute
        if (cmd.containsAny("كتم الصوت", "سكت الصوت", "صامت", "mute", "silence", "coupe le son")) {
            return JimiIntent.MuteVolume
        }

        // Check Volume Up
        if (cmd.containsAny(
                "زيد الصوت", "علي الصوت", "رفع الصوت", "قوي الصوت",
                "volume up", "louder", "increase volume", "monte le son", "plus fort"
            )
        ) {
            return JimiIntent.AdjustVolume(increase = true)
        }

        // Check Volume Down
        if (cmd.containsAny(
                "نقص الصوت", "وطي الصوت", "خفض الصوت", "قلل الصوت",
                "volume down", "quieter", "lower volume", "decrease volume", "baisse le son", "moins fort"
            )
        ) {
            return JimiIntent.AdjustVolume(increase = false)
        }

        // Check Settings
        if (cmd.containsAny("الاعدادات", "الإعدادات", "بارامتر", "settings", "parametres")) {
            return JimiIntent.OpenSettings
        }

        val cleanQuestion = stripped.ifBlank { original }
        return JimiIntent.AskJimiQuestion(
            question = cleanQuestion,
            wokeWithKeyword = wokeWithKeyword
        )
    }

    private fun stripWakeWord(text: String): String {
        var result = text.trim()
        for (kw in wakeKeywords) {
            val regex = Regex("(?i)\\b${Regex.escape(kw)}\\b|${Regex.escape(kw)}")
            result = result.replace(regex, " ")
        }
        return result.replace(Regex("[,،:!.؟?\\s]+"), " ").trim()
    }

    private fun normalize(text: String): String {
        return text.lowercase()
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ة', 'ه')
            .replace('ى', 'ي')
            .replace("é", "e")
            .replace("è", "e")
            .replace("ê", "e")
            .trim()
    }

    private fun String.containsAny(vararg tokens: String): Boolean {
        return tokens.any { this.contains(it) }
    }
}
