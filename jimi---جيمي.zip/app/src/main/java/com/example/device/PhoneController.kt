package com.example.device

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.example.MainActivity
import com.example.R
import com.example.ui.i18n.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

private const val TAG = "PhoneController"

data class PhoneControlState(
    val isFlashOn: Boolean = false,
    val isFlashAvailable: Boolean = false,
    val volumePercent: Int = 50,
    val lastFeedbackMessage: String? = null
)

data class PhoneActionResult(
    val success: Boolean,
    val spokenFeedback: String
)

class PhoneController(context: Context) {

    private val appContext = context.applicationContext
    private val cameraManager = appContext.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val torchCameraId: String? = findTorchCameraId()

    private val _state = MutableStateFlow(
        PhoneControlState(
            isFlashOn = false,
            isFlashAvailable = torchCameraId != null,
            volumePercent = readCurrentVolumePercent()
        )
    )
    val state: StateFlow<PhoneControlState> = _state.asStateFlow()

    private fun findTorchCameraId(): String? {
        val manager = cameraManager ?: return null
        return try {
            manager.cameraIdList.firstOrNull { id ->
                val chars = manager.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) {
            Log.w(TAG, "Unable to query camera flash", e)
            null
        }
    }

    fun refreshVolume() {
        _state.update { it.copy(volumePercent = readCurrentVolumePercent()) }
    }

    private fun readCurrentVolumePercent(): Int {
        val manager = audioManager ?: return 50
        val max = manager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val current = manager.getStreamVolume(AudioManager.STREAM_MUSIC)
        return ((current * 100f) / max).toInt().coerceIn(0, 100)
    }

    fun openWhatsApp(language: AppLanguage): PhoneActionResult {
        val launched = launchAppOrWeb(
            packages = listOf("com.whatsapp", "com.whatsapp.w4b"),
            fallbackUrl = "https://wa.me/"
        )
        val msg = if (launched) {
            when (language) {
                AppLanguage.DARIJA -> "فتحت ليك واتساب دابا!"
                AppLanguage.ARABIC -> "تم فتح تطبيق واتساب."
                AppLanguage.FRENCH -> "J'ouvre WhatsApp maintenant !"
                AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Opening WhatsApp now!"
            }
        } else {
            when (language) {
                AppLanguage.DARIJA -> "ما لقيتش واتساب، ولكن تقدر تفتحه من المتصفح."
                AppLanguage.ARABIC -> "تعذر العثور على واتساب على هذا الجهاز."
                AppLanguage.FRENCH -> "Impossible d'ouvrir WhatsApp sur cet appareil."
                AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Could not open WhatsApp on this device."
            }
        }
        _state.update { it.copy(lastFeedbackMessage = msg) }
        return PhoneActionResult(launched, msg)
    }

    fun openYouTube(language: AppLanguage): PhoneActionResult {
        val launched = launchAppOrWeb(
            packages = listOf("com.google.android.youtube"),
            fallbackUrl = "https://www.youtube.com"
        )
        val msg = if (launched) {
            when (language) {
                AppLanguage.DARIJA -> "فتحت ليك يوتيوب دابا!"
                AppLanguage.ARABIC -> "تم فتح تطبيق يوتيوب."
                AppLanguage.FRENCH -> "J'ouvre YouTube maintenant !"
                AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Opening YouTube now!"
            }
        } else {
            when (language) {
                AppLanguage.DARIJA -> "تعذر فتح يوتيوب على هاد الجهاز."
                AppLanguage.ARABIC -> "تعذر فتح يوتيوب على هذا الجهاز."
                AppLanguage.FRENCH -> "Impossible d'ouvrir YouTube."
                AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Could not open YouTube."
            }
        }
        _state.update { it.copy(lastFeedbackMessage = msg) }
        return PhoneActionResult(launched, msg)
    }

    fun openTikTok(language: AppLanguage): PhoneActionResult {
        val launched = launchAppOrWeb(
            packages = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
            fallbackUrl = "https://www.tiktok.com"
        )
        val msg = if (launched) {
            when (language) {
                AppLanguage.DARIJA -> "فتحت ليك تيك توك دابا!"
                AppLanguage.ARABIC -> "تم فتح تطبيق تيك توك."
                AppLanguage.FRENCH -> "J'ouvre TikTok maintenant !"
                AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Opening TikTok now!"
            }
        } else {
            when (language) {
                AppLanguage.DARIJA -> "تعذر فتح تيك توك على هاد الجهاز."
                AppLanguage.ARABIC -> "تعذر فتح تيك توك على هذا الجهاز."
                AppLanguage.FRENCH -> "Impossible d'ouvrir TikTok."
                AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Could not open TikTok."
            }
        }
        _state.update { it.copy(lastFeedbackMessage = msg) }
        return PhoneActionResult(launched, msg)
    }

    private fun launchAppOrWeb(packages: List<String>, fallbackUrl: String): Boolean {
        val pm: PackageManager = appContext.packageManager
        for (pkg in packages) {
            try {
                val intent = pm.getLaunchIntentForPackage(pkg)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    appContext.startActivity(intent)
                    return true
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed launching package $pkg", e)
            }
        }
        return try {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(webIntent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed launching fallback URL $fallbackUrl", e)
            false
        }
    }

    fun vibratePhone(language: AppLanguage): PhoneActionResult {
        return try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(
                        VibrationEffect.createWaveform(longArrayOf(0, 180, 90, 260), -1)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(420L)
                }
                val msg = when (language) {
                    AppLanguage.DARIJA -> "تم اهتزاز الهاتف بنجاح!"
                    AppLanguage.ARABIC -> "تم تشغيل اهتزاز الهاتف."
                    AppLanguage.FRENCH -> "Vibration du téléphone activée !"
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Phone vibrated!"
                }
                _state.update { it.copy(lastFeedbackMessage = msg) }
                PhoneActionResult(true, msg)
            } else {
                val msg = when (language) {
                    AppLanguage.DARIJA -> "هاد الجهاز ما فيهش محرك اهتزاز متاح."
                    AppLanguage.ARABIC -> "محرك الاهتزاز غير متوفر على هذا الجهاز."
                    AppLanguage.FRENCH -> "Vibreur indisponible sur cet appareil."
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Vibrator unavailable on this device."
                }
                _state.update { it.copy(lastFeedbackMessage = msg) }
                PhoneActionResult(false, msg)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Vibrate error", e)
            PhoneActionResult(false, e.localizedMessage ?: "Vibrate failed")
        }
    }

    fun setFlashlight(enable: Boolean, language: AppLanguage): PhoneActionResult {
        val id = torchCameraId
        val manager = cameraManager
        if (id == null || manager == null) {
            val msg = when (language) {
                AppLanguage.DARIJA -> "الفلاش ما متوفرش فهاد الجهاز."
                AppLanguage.ARABIC -> "المصباح (الفلاش) غير متوفر على هذا الجهاز."
                AppLanguage.FRENCH -> "Flash indisponible sur cet appareil."
                AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Flashlight is not available on this device."
            }
            _state.update { it.copy(isFlashAvailable = false, lastFeedbackMessage = msg) }
            return PhoneActionResult(false, msg)
        }
        return try {
            manager.setTorchMode(id, enable)
            val msg = if (enable) {
                when (language) {
                    AppLanguage.DARIJA -> "شعلت ليك الفلاش دابا!"
                    AppLanguage.ARABIC -> "تم تشغيل الفلاش."
                    AppLanguage.FRENCH -> "Flash allumé !"
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Flashlight turned ON!"
                }
            } else {
                when (language) {
                    AppLanguage.DARIJA -> "طفيت الفلاش دابا!"
                    AppLanguage.ARABIC -> "تم إطفاء الفلاش."
                    AppLanguage.FRENCH -> "Flash éteint !"
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Flashlight turned OFF!"
                }
            }
            _state.update { it.copy(isFlashOn = enable, isFlashAvailable = true, lastFeedbackMessage = msg) }
            PhoneActionResult(true, msg)
        } catch (e: Exception) {
            Log.e(TAG, "Torch error", e)
            val msg = when (language) {
                AppLanguage.DARIJA -> "ما قدرتش نبدل حالة الفلاش على هاد الجهاز."
                AppLanguage.ARABIC -> "تعذر التحكم في الفلاش على هذا الجهاز."
                AppLanguage.FRENCH -> "Impossible de contrôler le flash."
                AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Unable to control flashlight."
            }
            _state.update { it.copy(lastFeedbackMessage = msg) }
            PhoneActionResult(false, msg)
        }
    }

    fun toggleFlashlight(language: AppLanguage): PhoneActionResult {
        return setFlashlight(!_state.value.isFlashOn, language)
    }

    fun adjustVolume(increase: Boolean, language: AppLanguage): PhoneActionResult {
        val manager = audioManager ?: return PhoneActionResult(false, "Audio unavailable")
        return try {
            val direction = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
            manager.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
            val pct = readCurrentVolumePercent()
            val msg = if (increase) {
                when (language) {
                    AppLanguage.DARIJA -> "زدت فالصوت ($pct%)"
                    AppLanguage.ARABIC -> "تم رفع الصوت إلى $pct%"
                    AppLanguage.FRENCH -> "Volume augmenté à $pct%"
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Volume increased to $pct%"
                }
            } else {
                when (language) {
                    AppLanguage.DARIJA -> "نقصت فالصوت ($pct%)"
                    AppLanguage.ARABIC -> "تم خفض الصوت إلى $pct%"
                    AppLanguage.FRENCH -> "Volume baissé à $pct%"
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Volume lowered to $pct%"
                }
            }
            _state.update { it.copy(volumePercent = pct, lastFeedbackMessage = msg) }
            PhoneActionResult(true, msg)
        } catch (e: Exception) {
            Log.e(TAG, "Volume adjust error", e)
            PhoneActionResult(false, e.localizedMessage ?: "Volume error")
        }
    }

    fun setVolumePercent(percent: Int, language: AppLanguage): PhoneActionResult {
        val manager = audioManager ?: return PhoneActionResult(false, "Audio unavailable")
        return try {
            val clamped = percent.coerceIn(0, 100)
            val max = manager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val target = ((clamped / 100f) * max).toInt().coerceIn(0, max)
            manager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            val actualPct = readCurrentVolumePercent()
            val msg = when (language) {
                AppLanguage.DARIJA -> "الصوت ولا فـ $actualPct%"
                AppLanguage.ARABIC -> "مستوى الصوت: $actualPct%"
                AppLanguage.FRENCH -> "Volume réglé à $actualPct%"
                AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Volume set to $actualPct%"
            }
            _state.update { it.copy(volumePercent = actualPct, lastFeedbackMessage = msg) }
            PhoneActionResult(true, msg)
        } catch (e: Exception) {
            Log.e(TAG, "Volume set error", e)
            PhoneActionResult(false, e.localizedMessage ?: "Volume error")
        }
    }

    fun pinJimiHomeShortcut(language: AppLanguage): PhoneActionResult {
        return try {
            if (ShortcutManagerCompat.isRequestPinShortcutSupported(appContext)) {
                val launchIntent = Intent(appContext, MainActivity::class.java).apply {
                    action = Intent.ACTION_VIEW
                }
                val shortcut = ShortcutInfoCompat.Builder(appContext, "jimi_home_shortcut")
                    .setShortLabel("JIMI - جيمي")
                    .setLongLabel("JIMI - جيمي AI")
                    .setIcon(IconCompat.createWithResource(appContext, R.mipmap.ic_launcher))
                    .setIntent(launchIntent)
                    .build()

                val callbackIntent = ShortcutManagerCompat.createShortcutResultIntent(appContext, shortcut)
                val pendingIntent = PendingIntent.getBroadcast(
                    appContext,
                    1042,
                    callbackIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                ShortcutManagerCompat.requestPinShortcut(appContext, shortcut, pendingIntent.intentSender)
                val msg = when (language) {
                    AppLanguage.DARIJA -> "تم إرسال أيقونة JIMI للشاشة الرئيسية!"
                    AppLanguage.ARABIC -> "تمت إضافة أيقونة JIMI إلى الشاشة الرئيسية!"
                    AppLanguage.FRENCH -> "Icône JIMI ajoutée à l'écran d'accueil !"
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "JIMI icon pinned to Home Screen!"
                }
                _state.update { it.copy(lastFeedbackMessage = msg) }
                PhoneActionResult(true, msg)
            } else {
                val msg = when (language) {
                    AppLanguage.DARIJA -> "التثبيت التلقائي ما مدعومش فهاد الواجهة، أيقونة JIMI راها فالشاشة الرئيسية."
                    AppLanguage.ARABIC -> "أيقونة JIMI مثبتة مسبقاً ضمن تطبيقات الشاشة الرئيسية."
                    AppLanguage.FRENCH -> "L'icône JIMI est déjà dans votre lanceur d'applications."
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "JIMI icon is already available on your app launcher."
                }
                _state.update { it.copy(lastFeedbackMessage = msg) }
                PhoneActionResult(false, msg)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Shortcut pin failed", e)
            PhoneActionResult(false, e.localizedMessage ?: "Shortcut unavailable")
        }
    }
}
