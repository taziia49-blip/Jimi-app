package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.media.VoiceInputState
import com.example.ui.i18n.LocalizedStrings
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun DraggableFloatingJimiOrb(
    containerWidthPx: Float,
    containerHeightPx: Float,
    savedOnRight: Boolean,
    savedYFraction: Float,
    isWakeActive: Boolean,
    isListening: Boolean,
    rmsLevel: Float,
    isSpeaking: Boolean,
    isExpanded: Boolean,
    assistantLabel: String,
    onSingleTap: () -> Unit,
    onPositionSaved: (onRight: Boolean, yFraction: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val hapticFeedback = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()

    val orbSizePx = with(density) { 60.dp.toPx() }
    val edgeMarginPx = with(density) { 16.dp.toPx() }
    val topMinYPx = with(density) { 12.dp.toPx() }
    val bottomMinGapAboveNavPx = with(density) { 12.dp.toPx() }
    val defaultYFromBottomPx = with(density) { 80.dp.toPx() }

    val maxXPx = (containerWidthPx - orbSizePx).coerceAtLeast(0f)
    val leftSnapXPx = edgeMarginPx.coerceIn(0f, maxXPx)
    val rightSnapXPx = (containerWidthPx - orbSizePx - edgeMarginPx).coerceIn(0f, maxXPx)

    val minYPx = topMinYPx
    val maxYPx = (containerHeightPx - orbSizePx - bottomMinGapAboveNavPx).coerceAtLeast(minYPx)
    val defaultYPx = (containerHeightPx - orbSizePx - defaultYFromBottomPx).coerceIn(minYPx, maxYPx)

    val targetX = if (savedOnRight) rightSnapXPx else leftSnapXPx
    val targetY = if (savedYFraction < 0f) {
        defaultYPx
    } else {
        minYPx + (maxYPx - minYPx) * savedYFraction.coerceIn(0f, 1f)
    }

    var isDragging by remember { mutableStateOf(false) }
    var shouldAnimateSnap by remember { mutableStateOf(false) }
    var dragX by remember { mutableFloatStateOf(targetX) }
    var dragY by remember { mutableFloatStateOf(targetY) }
    var orbCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }

    val offsetX = remember { Animatable(targetX) }
    val offsetY = remember { Animatable(targetY) }

    LaunchedEffect(targetX, targetY, isDragging) {
        if (!isDragging) {
            if (shouldAnimateSnap) {
                shouldAnimateSnap = false
                launch {
                    offsetX.animateTo(
                        targetValue = targetX,
                        animationSpec = spring(
                            dampingRatio = 0.72f,
                            stiffness = Spring.StiffnessMedium
                        )
                    )
                }
                launch {
                    offsetY.animateTo(
                        targetValue = targetY,
                        animationSpec = spring(
                            dampingRatio = 0.80f,
                            stiffness = Spring.StiffnessMedium
                        )
                    )
                }
            } else {
                offsetX.snapTo(targetX)
                offsetY.snapTo(targetY)
            }
        }
    }

    val currentOnTap by rememberUpdatedState(onSingleTap)
    val currentOnPositionSaved by rememberUpdatedState(onPositionSaved)
    val currentMaxXPx by rememberUpdatedState(maxXPx)
    val currentMinYPx by rememberUpdatedState(minYPx)
    val currentMaxYPx by rememberUpdatedState(maxYPx)
    val currentContainerWidthPx by rememberUpdatedState(containerWidthPx)
    val currentOrbSizePx by rememberUpdatedState(orbSizePx)

    Box(
        modifier = modifier
            .offset {
                val x = if (isDragging) dragX else offsetX.value
                val y = if (isDragging) dragY else offsetY.value
                IntOffset(x.roundToInt(), y.roundToInt())
            }
            .onGloballyPositioned { orbCoords = it }
    ) {
        FloatingJimiOrb(
            isWakeActive = isWakeActive,
            isListening = isListening,
            rmsLevel = rmsLevel,
            isSpeaking = isSpeaking,
            isExpanded = isExpanded,
            isDragging = isDragging,
            onClick = currentOnTap,
            interactiveModifier = Modifier
                .semantics {
                    contentDescription = assistantLabel
                    role = Role.Button
                    onClick {
                        currentOnTap()
                        true
                    }
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val longPressTimeout = viewConfiguration.longPressTimeoutMillis
                        val touchSlop = viewConfiguration.touchSlop

                        var cancelledByMove = false
                        val upBeforeLongPress = withTimeoutOrNull(longPressTimeout) {
                            var upChange: PointerInputChange? = null
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                if (!change.pressed) {
                                    upChange = change
                                    break
                                }
                                if ((change.position - down.position).getDistance() > touchSlop) {
                                    cancelledByMove = true
                                    break
                                }
                            }
                            upChange
                        }

                        if (upBeforeLongPress != null) {
                            upBeforeLongPress.consume()
                            currentOnTap()
                            return@awaitEachGesture
                        }

                        if (cancelledByMove) {
                            return@awaitEachGesture
                        }

                        val latestDown = currentEvent.changes.firstOrNull { it.id == down.id && it.pressed }
                            ?: return@awaitEachGesture
                        if ((latestDown.position - down.position).getDistance() > touchSlop) {
                            return@awaitEachGesture
                        }

                        // Long-press confirmed: vibrate lightly and enter free-drag mode
                        latestDown.consume()
                        var liveX = offsetX.value
                        var liveY = offsetY.value
                        dragX = liveX
                        dragY = liveY
                        isDragging = true
                        hapticFeedback.performHapticFeedback(HapticFeedbackType.LongPress)
                        triggerDragStartVibration(context)

                        var lastRootPos = orbCoords?.takeIf { it.isAttached }?.localToRoot(latestDown.position)

                        try {
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                if (!change.pressed) {
                                    change.consume()
                                    break
                                }
                                val coords = orbCoords?.takeIf { it.isAttached }
                                val delta = if (coords != null && lastRootPos != null) {
                                    val currentRoot = coords.localToRoot(change.position)
                                    val d = currentRoot - lastRootPos
                                    lastRootPos = currentRoot
                                    d
                                } else {
                                    if (coords != null) {
                                        lastRootPos = coords.localToRoot(change.position)
                                    }
                                    change.positionChange()
                                }

                                if (delta != Offset.Zero) {
                                    change.consume()
                                    liveX = (liveX + delta.x).coerceIn(0f, currentMaxXPx)
                                    liveY = (liveY + delta.y).coerceIn(currentMinYPx, currentMaxYPx)
                                    dragX = liveX
                                    dragY = liveY
                                }
                            }
                        } finally {
                            val centerX = liveX + currentOrbSizePx / 2f
                            val snapRight = centerX >= (currentContainerWidthPx / 2f)
                            val rangeY = currentMaxYPx - currentMinYPx
                            val yFraction = if (rangeY > 1f) {
                                ((liveY - currentMinYPx) / rangeY).coerceIn(0f, 1f)
                            } else {
                                1f
                            }
                            coroutineScope.launch {
                                offsetX.snapTo(liveX)
                                offsetY.snapTo(liveY)
                                shouldAnimateSnap = true
                                isDragging = false
                                currentOnPositionSaved(snapRight, yFraction)
                            }
                        }
                    }
                }
        )
    }
}

private fun triggerDragStartVibration(context: Context) {
    runCatching {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        if (vibrator != null && vibrator.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createOneShot(40L, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(40L)
            }
        }
    }
}

@Composable
fun FloatingJimiOrb(
    isWakeActive: Boolean,
    isListening: Boolean,
    rmsLevel: Float,
    isSpeaking: Boolean,
    isExpanded: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isDragging: Boolean = false,
    interactiveModifier: Modifier? = null
) {
    val activeListening = isListening || isWakeActive
    val infiniteTransition = rememberInfiniteTransition(label = "jimiOrbMotion")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.14f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (activeListening || isSpeaking) 650 else 1600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val waveProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "listeningWaves"
    )
    val dragScale by animateFloatAsState(
        targetValue = if (isDragging) 1.10f else 1.0f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium),
        label = "dragScale"
    )

    var eyeAnim by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { nanos ->
                if (last != 0L) eyeAnim += ((nanos - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
                last = nanos
            }
        }
    }

    val glowColor = when {
        isDragging -> Color(0xFF38BDF8)
        isListening -> Color(0xFF10B981)
        isWakeActive -> Color(0xFF2DD4BF)
        isSpeaking -> Color(0xFF38BDF8)
        else -> Color(0xFF8B5CF6)
    }

    Box(
        modifier = modifier
            .size(60.dp)
            .scale(dragScale),
        contentAlignment = Alignment.Center
    ) {
        // Outer glow halo & listening wave animation (drawn unclipped around the 60dp orb)
        Canvas(modifier = Modifier.matchParentSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = size.minDimension / 2f

            // Ambient soft glow
            val glowRadius = baseRadius * (if (isDragging || activeListening || isSpeaking || isExpanded) 1.55f * pulse else 1.38f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glowColor.copy(alpha = if (isDragging || activeListening) 0.78f else 0.50f),
                        glowColor.copy(alpha = 0.20f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = glowRadius
                ),
                radius = glowRadius,
                center = center
            )

            // Concentric expanding sound waves + oscillating wave ring when JIMI is listening
            if (isListening || isWakeActive) {
                val rmsBoost = if (isListening) (1f + rmsLevel * 0.45f) else 1f
                for (ringIdx in 0 until 3) {
                    val phase = (waveProgress + ringIdx / 3f) % 1f
                    val ringRadius = baseRadius + phase * (baseRadius * 0.95f * rmsBoost)
                    val ringAlpha = ((1f - phase) * if (isListening) 0.78f else 0.45f).coerceIn(0f, 1f)
                    drawCircle(
                        color = glowColor.copy(alpha = ringAlpha),
                        radius = ringRadius,
                        center = center,
                        style = androidx.compose.ui.graphics.drawscope.Stroke(
                            width = (if (isListening) 2.6f else 1.6f) * density
                        )
                    )
                }

                // Dynamic radial audio wave bars around perimeter during active speech recognition
                if (isListening) {
                    val barCount = 24
                    val waveAmpBase = (4f + rmsLevel * 8f) * density
                    for (i in 0 until barCount) {
                        val angle = (i.toFloat() / barCount) * (2f * PI.toFloat())
                        val osc = 0.35f + 0.65f * kotlin.math.abs(
                            sin(waveProgress * 2f * PI.toFloat() * 2f + i * 0.65f)
                        )
                        val startR = baseRadius + 2f * density
                        val endR = startR + waveAmpBase * osc
                        val cosA = kotlin.math.cos(angle)
                        val sinA = sin(angle)
                        drawLine(
                            color = Color(0xFF6EE7B7).copy(alpha = 0.85f),
                            start = Offset(center.x + cosA * startR, center.y + sinA * startR),
                            end = Offset(center.x + cosA * endR, center.y + sinA * endR),
                            strokeWidth = 2.dp.toPx(),
                            cap = androidx.compose.ui.graphics.StrokeCap.Round
                        )
                    }
                }
            }
        }

        val tapOrDragModifier = interactiveModifier ?: Modifier.clickable(onClick = onClick)

        Surface(
            shape = CircleShape,
            shadowElevation = if (isDragging) 18.dp else 12.dp,
            border = BorderStroke(
                width = if (isDragging) 2.5.dp else 2.dp,
                brush = Brush.linearGradient(
                    listOf(
                        if (activeListening) Color(0xFF34D399) else Color(0xFF38BDF8),
                        if (isDragging) Color(0xFFFBBF24) else Color(0xFFC084FC)
                    )
                )
            ),
            color = Color(0xFF160B3B),
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .then(tapOrDragModifier)
                .testTag("floating_jimi_orb")
        ) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    // Mini Visor
                    drawRoundRect(
                        color = Color(0xFF0A1229),
                        topLeft = Offset(w * 0.16f, h * 0.24f),
                        size = Size(w * 0.68f, h * 0.36f),
                        cornerRadius = CornerRadius(w * 0.16f, w * 0.16f)
                    )
                    // Blinking glowing eyes
                    val blink = (eyeAnim % 3.2f) in 2.95f..3.12f
                    val eyeScale = if (blink) 0.2f else 1f
                    val eyeColor = if (activeListening) Color(0xFF34D399) else Color(0xFF38BDF8)
                    val eyeH = h * 0.14f * eyeScale
                    val eyeY = h * 0.42f - eyeH / 2f
                    drawRoundRect(
                        color = eyeColor,
                        topLeft = Offset(w * 0.28f, eyeY),
                        size = Size(w * 0.14f, eyeH),
                        cornerRadius = CornerRadius(w * 0.07f, w * 0.07f)
                    )
                    drawRoundRect(
                        color = eyeColor,
                        topLeft = Offset(w * 0.58f, eyeY),
                        size = Size(w * 0.14f, eyeH),
                        cornerRadius = CornerRadius(w * 0.07f, w * 0.07f)
                    )
                }
                Text(
                    text = "JIMI",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 5.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FloatingJimiAssistantOverlay(
    visible: Boolean,
    isDarkMode: Boolean,
    wakeWordEnabled: Boolean,
    isListeningForCommand: Boolean,
    isSpeaking: Boolean,
    voiceInputState: VoiceInputState,
    lastTranscript: String,
    jimiResponseText: String,
    strings: LocalizedStrings,
    onDismiss: () -> Unit,
    onToggleWakeWord: (Boolean) -> Unit,
    onMicPermissionDenied: () -> Unit,
    onWakeAndListenNow: () -> Unit,
    onStopListening: () -> Unit,
    onExecuteCommandText: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val wakePermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) onToggleWakeWord(true) else onMicPermissionDenied()
    }

    val talkPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) onWakeAndListenNow() else onMicPermissionDenied()
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(200)) + scaleIn(initialScale = 0.90f),
        exit = fadeOut(tween(180)) + scaleOut(targetScale = 0.90f),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.42f))
                .clickable(onClick = onDismiss)
                .padding(horizontal = 16.dp, vertical = 24.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            GlassmorphicCard(
                isDarkMode = isDarkMode,
                accentColor = Color(0xFF8B5CF6),
                elevation = 12.dp,
                modifier = Modifier
                    .widthIn(max = 520.dp)
                    .fillMaxWidth()
                    .clickable(enabled = false, onClick = {})
                    .testTag("floating_jimi_panel")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = Color(0xFF1E1047),
                                shape = CircleShape,
                                border = BorderStroke(1.5.dp, Color(0xFF38BDF8)),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = Color(0xFFFBBF24),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = strings.floatingJimiTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = strings.floatingJimiSubtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("btn_close_jimi_overlay")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Wake-Word Always Listening Toggle
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = strings.floatingJimiWakeSwitch,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = strings.floatingJimiWakeHint,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = wakeWordEnabled,
                                onCheckedChange = { wantEnable ->
                                    if (!wantEnable) {
                                        onToggleWakeWord(false)
                                    } else {
                                        val granted = ContextCompat.checkSelfPermission(
                                            context,
                                            Manifest.permission.RECORD_AUDIO
                                        ) == PackageManager.PERMISSION_GRANTED
                                        if (granted) onToggleWakeWord(true)
                                        else wakePermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF10B981)
                                ),
                                modifier = Modifier.testTag("switch_jimi_wake_word")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // JIMI Live Response Bubble ("نعم؟ أنا JIMI" or command result)
                    if (jimiResponseText.isNotBlank() || isListeningForCommand || voiceInputState.partialText.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(
                                1.dp,
                                if (isListeningForCommand) Color(0xFF10B981) else MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                if (isListeningForCommand) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.GraphicEq,
                                            contentDescription = null,
                                            tint = Color(0xFF10B981),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = voiceInputState.partialText.ifBlank { strings.floatingJimiListeningCmd },
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                                if (lastTranscript.isNotBlank() && !isListeningForCommand) {
                                    Text(
                                        text = "🗣️ $lastTranscript",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                }
                                if (jimiResponseText.isNotBlank()) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.RecordVoiceOver,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = jimiResponseText,
                                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // Main Push-to-Talk Wake Button
                    Button(
                        onClick = {
                            if (isListeningForCommand) {
                                onStopListening()
                            } else {
                                val granted = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED
                                if (granted) onWakeAndListenNow()
                                else talkPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isListeningForCommand) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.primary,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(vertical = 14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("btn_floating_jimi_talk")
                    ) {
                        Icon(
                            imageVector = if (isListeningForCommand) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isListeningForCommand) strings.robotMicStopDesc else strings.floatingJimiTalkBtn,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = strings.floatingJimiTryCommands,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        strings.floatingJimiSampleCommands.forEach { sampleCmd ->
                            Surface(
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
                                shape = RoundedCornerShape(999.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .clickable { onExecuteCommandText(sampleCmd) }
                            ) {
                                Text(
                                    text = sampleCmd,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
