package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val PlayStoreLightColorScheme = lightColorScheme(
    primary = PlayBluePrimary,
    onPrimary = Color.White,
    primaryContainer = PlayBlueContainer,
    onPrimaryContainer = PlayOnBlueContainer,
    secondary = PlayTealAccent,
    onSecondary = Color.White,
    secondaryContainer = PlayTealContainer,
    onSecondaryContainer = PlayOnTealContainer,
    tertiary = PlayAmberAccent,
    onTertiary = TextPrimaryDark,
    tertiaryContainer = PlayAmberContainer,
    background = BackgroundCrisp,
    onBackground = TextPrimaryDark,
    surface = SurfacePureWhite,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceCardAlt,
    onSurfaceVariant = TextSecondarySlate,
    outline = OutlineSubtle,
    outlineVariant = OutlineSubtle,
    error = ErrorRed,
    onError = Color.White,
    errorContainer = ErrorContainerLight
)

private val PlayStoreDarkColorScheme = darkColorScheme(
    primary = Color(0xFF60A5FA),
    onPrimary = Color(0xFF0A192F),
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = Color(0xFF34D399),
    onSecondary = Color(0xFF052E16),
    secondaryContainer = Color(0xFF064E3B),
    onSecondaryContainer = Color(0xFFD1FAE5),
    tertiary = Color(0xFFFBBF24),
    onTertiary = Color(0xFF1F2937),
    tertiaryContainer = Color(0xFF451A03),
    background = Color(0xFF0B1120),
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF131C31),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF2B3A55),
    outlineVariant = Color(0xFF2B3A55),
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A),
    errorContainer = Color(0xFF7F1D1D)
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun DarijaVideoTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val scheme = if (darkTheme) PlayStoreDarkColorScheme else PlayStoreLightColorScheme
    MaterialTheme(
        colorScheme = scheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
