package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.LocalizedStrings
import com.example.ui.i18n.localizedLabel
import com.example.ui.model.BackgroundMusicMode
import com.example.ui.model.VideoArtStyle
import com.example.ui.model.VideoAspectRatio
import com.example.ui.model.VideoDuration
import com.example.ui.model.VideoQuality
import com.example.ui.model.VoiceType

private val ActiveBlueBorder = Color(0xFF2563EB)
private val ActiveBlueGlow = Color(0xFF38BDF8)

private enum class HighlightFocus {
    STYLE,
    DURATION,
    VOICE,
    MUSIC,
    RATIO,
    QUALITY
}

@Composable
fun ProVideoOptionsSection(
    selectedStyle: VideoArtStyle,
    selectedDuration: VideoDuration,
    selectedVoice: VoiceType,
    selectedMusic: BackgroundMusicMode,
    selectedQuality: VideoQuality,
    selectedRatio: VideoAspectRatio,
    language: AppLanguage,
    strings: LocalizedStrings,
    isDarkMode: Boolean,
    onSelectStyle: (VideoArtStyle) -> Unit,
    onSelectDuration: (VideoDuration) -> Unit,
    onSelectVoice: (VoiceType) -> Unit,
    onSelectMusic: (BackgroundMusicMode) -> Unit,
    onSelectQuality: (VideoQuality) -> Unit,
    onSelectRatio: (VideoAspectRatio) -> Unit
) {
    var focusCategory by remember { mutableStateOf(HighlightFocus.STYLE) }
    var selectionPulseTick by remember { mutableIntStateOf(0) }

    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        isDarkMode = isDarkMode
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = strings.secVideoOptions,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Enlarged Interactive Preview Stage (zooms & enlarges whenever any option is tapped)
            EnlargedVideoSettingsPreviewStage(
                focus = focusCategory,
                pulseTick = selectionPulseTick,
                selectedStyle = selectedStyle,
                selectedDuration = selectedDuration,
                selectedVoice = selectedVoice,
                selectedMusic = selectedMusic,
                selectedQuality = selectedQuality,
                selectedRatio = selectedRatio,
                language = language,
                isDarkMode = isDarkMode
            )

            // 1. STYLE (8 AI Preview Cards)
            VisualOptionSectionLabel(text = strings.optStyle)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(VideoArtStyle.entries) { style ->
                    StylePreviewCard(
                        style = style,
                        label = style.localizedLabel(language),
                        selected = style == selectedStyle,
                        onClick = {
                            focusCategory = HighlightFocus.STYLE
                            selectionPulseTick++
                            onSelectStyle(style)
                        },
                        modifier = Modifier.testTag("video_style_${style.name.lowercase()}")
                    )
                }
            }

            // 2. DURATION (Video Icon Preview [5s / 10s / 15s / 30s])
            VisualOptionSectionLabel(text = strings.optDuration)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                VideoDuration.entries.forEach { dur ->
                    DurationVideoPreviewCard(
                        duration = dur,
                        stylePreviewRes = selectedStyle.previewImageRes,
                        selected = dur == selectedDuration,
                        onClick = {
                            focusCategory = HighlightFocus.DURATION
                            selectionPulseTick++
                            onSelectDuration(dur)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("video_duration_${dur.seconds}")
                    )
                }
            }

            // 3. VOICE (AI Avatar Images: Man / Woman / Child / Robot)
            VisualOptionSectionLabel(text = strings.optVoice)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(VoiceType.entries) { vType ->
                    VoiceAvatarCard(
                        voiceType = vType,
                        label = vType.localizedLabel(language),
                        selected = vType == selectedVoice,
                        isDarkMode = isDarkMode,
                        onClick = {
                            focusCategory = HighlightFocus.VOICE
                            selectionPulseTick++
                            onSelectVoice(vType)
                        },
                        modifier = Modifier.testTag("video_voice_${vType.name.lowercase()}")
                    )
                }
            }

            // 4. MUSIC (Mute icon / Fire concert / Calm nature / Funny emoji)
            VisualOptionSectionLabel(text = strings.optMusic)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(BackgroundMusicMode.entries) { mode ->
                    MusicPreviewCard(
                        mode = mode,
                        label = mode.localizedLabel(language),
                        selected = mode == selectedMusic,
                        onClick = {
                            focusCategory = HighlightFocus.MUSIC
                            selectionPulseTick++
                            onSelectMusic(mode)
                        },
                        modifier = Modifier.testTag("video_music_${mode.name.lowercase()}")
                    )
                }
            }

            // 5. RATIO (Vertical Phone Frame / Square Frame / Wide YouTube Frame)
            VisualOptionSectionLabel(text = strings.optRatio)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                VideoAspectRatio.entries.forEach { ratio ->
                    RatioFramePreviewCard(
                        ratio = ratio,
                        label = ratio.localizedLabel(language),
                        previewRes = selectedStyle.previewImageRes,
                        selected = ratio == selectedRatio,
                        isDarkMode = isDarkMode,
                        onClick = {
                            focusCategory = HighlightFocus.RATIO
                            selectionPulseTick++
                            onSelectRatio(ratio)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("video_ratio_${ratio.name.lowercase()}")
                    )
                }
            }

            // 6. QUALITY (Standard 720p vs HD 1080p AI Preview Image)
            VisualOptionSectionLabel(text = strings.optQuality)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                VideoQuality.entries.forEach { quality ->
                    QualityPreviewCard(
                        quality = quality,
                        label = quality.localizedLabel(language),
                        selected = quality == selectedQuality,
                        onClick = {
                            focusCategory = HighlightFocus.QUALITY
                            selectionPulseTick++
                            onSelectQuality(quality)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("video_quality_${quality.name.lowercase()}")
                    )
                }
            }
        }
    }
}

@Composable
private fun EnlargedVideoSettingsPreviewStage(
    focus: HighlightFocus,
    pulseTick: Int,
    selectedStyle: VideoArtStyle,
    selectedDuration: VideoDuration,
    selectedVoice: VoiceType,
    selectedMusic: BackgroundMusicMode,
    selectedQuality: VideoQuality,
    selectedRatio: VideoAspectRatio,
    language: AppLanguage,
    isDarkMode: Boolean
) {
    val zoomAnim = remember { Animatable(1f) }
    LaunchedEffect(pulseTick) {
        if (pulseTick > 0) {
            zoomAnim.snapTo(0.95f)
            zoomAnim.animateTo(
                targetValue = 1.04f,
                animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium)
            )
            zoomAnim.animateTo(
                targetValue = 1f,
                animationSpec = spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow)
            )
        }
    }

    val stageHeight by animateDpAsState(
        targetValue = if (pulseTick > 0) 144.dp else 132.dp,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium),
        label = "stageHeight"
    )

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isDarkMode) Color(0xFF0F172A).copy(alpha = 0.85f) else Color(0xFFEFF6FF).copy(alpha = 0.90f),
        border = BorderStroke(1.5.dp, ActiveBlueBorder.copy(alpha = 0.65f)),
        shadowElevation = 6.dp,
        modifier = Modifier
            .fillMaxWidth()
            .height(stageHeight)
            .scale(zoomAnim.value)
            .testTag("enlarged_video_preview_stage")
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Enlarged active visual thumbnail framed in selected aspect ratio or focused option
            Box(
                modifier = Modifier
                    .width(126.dp)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                AnimatedContent(
                    targetState = Triple(focus, selectedStyle, Triple(selectedVoice, selectedMusic, selectedQuality)) to selectedRatio,
                    transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(160)) },
                    label = "enlargedSpotlight"
                ) { (triplet, ratio) ->
                    val (activeFocus, style, sub) = triplet
                    val (voice, music, quality) = sub
                    when (activeFocus) {
                        HighlightFocus.VOICE -> {
                            Image(
                                painter = painterResource(id = voice.avatarImageRes),
                                contentDescription = voice.localizedLabel(language),
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(112.dp)
                                    .clip(CircleShape)
                                    .border(2.5.dp, ActiveBlueBorder, CircleShape)
                            )
                        }
                        HighlightFocus.MUSIC -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(2.dp, ActiveBlueBorder, RoundedCornerShape(14.dp))
                                    .background(Color(0xFF1E1B4B)),
                                contentAlignment = Alignment.Center
                            ) {
                                val res = music.previewImageRes
                                if (res != null) {
                                    Image(
                                        painter = painterResource(id = res),
                                        contentDescription = music.localizedLabel(language),
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.VolumeOff,
                                        contentDescription = music.localizedLabel(language),
                                        tint = Color.White,
                                        modifier = Modifier.size(44.dp)
                                    )
                                }
                            }
                        }
                        HighlightFocus.QUALITY -> {
                            Image(
                                painter = painterResource(id = quality.previewImageRes),
                                contentDescription = quality.localizedLabel(language),
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(2.dp, ActiveBlueBorder, RoundedCornerShape(14.dp))
                            )
                        }
                        HighlightFocus.STYLE, HighlightFocus.DURATION, HighlightFocus.RATIO -> {
                            val clampedRatio = ratio.ratioFloat.coerceIn(0.62f, 1.78f)
                            Box(
                                modifier = Modifier
                                    .then(
                                        if (clampedRatio < 1f) {
                                            Modifier.fillMaxHeight().aspectRatio(clampedRatio)
                                        } else {
                                            Modifier.fillMaxWidth().aspectRatio(clampedRatio)
                                        }
                                    )
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(2.dp, ActiveBlueBorder, RoundedCornerShape(12.dp))
                            ) {
                                Image(
                                    painter = painterResource(id = style.previewImageRes),
                                    contentDescription = style.localizedLabel(language),
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Surface(
                                    color = Color.Black.copy(alpha = 0.60f),
                                    shape = RoundedCornerShape(999.dp),
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(4.dp)
                                ) {
                                    Text(
                                        text = selectedDuration.label,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Live Recipe Summary Pills beside the enlarged preview
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = selectedVoice.avatarImageRes),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, ActiveBlueGlow, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${selectedStyle.localizedLabel(language)} • ${selectedDuration.label}",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = "${selectedVoice.localizedLabel(language)} • ${selectedMusic.localizedLabel(language)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PreviewMetaBadge(text = selectedRatio.localizedLabel(language))
                    PreviewMetaBadge(text = selectedQuality.localizedLabel(language))
                }
            }
        }
    }
}

@Composable
private fun PreviewMetaBadge(text: String) {
    Surface(
        color = ActiveBlueBorder.copy(alpha = 0.14f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ActiveBlueBorder.copy(alpha = 0.45f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = ActiveBlueBorder,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun StylePreviewCard(
    style: VideoArtStyle,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.06f else 1.0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium),
        label = "styleScale"
    )
    val cardWidth by animateDpAsState(
        targetValue = if (selected) 112.dp else 94.dp,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = Spring.StiffnessMedium),
        label = "styleWidth"
    )
    val cardHeight by animateDpAsState(
        targetValue = if (selected) 124.dp else 108.dp,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = Spring.StiffnessMedium),
        label = "styleHeight"
    )

    Surface(
        shape = RoundedCornerShape(16.dp),
        shadowElevation = if (selected) 8.dp else 2.dp,
        border = BorderStroke(
            width = if (selected) 2.5.dp else 1.dp,
            color = if (selected) ActiveBlueBorder else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        ),
        modifier = modifier
            .width(cardWidth)
            .height(cardHeight)
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = style.previewImageRes),
                contentDescription = label,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .scale(if (selected) 1.10f else 1.0f)
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.18f),
                                Color.Black.copy(alpha = 0.82f)
                            )
                        )
                    )
            )
            if (selected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = ActiveBlueGlow,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(18.dp)
                )
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold
                ),
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 7.dp)
            )
        }
    }
}

@Composable
private fun DurationVideoPreviewCard(
    duration: VideoDuration,
    stylePreviewRes: Int,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.06f else 1.0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium),
        label = "durationScale"
    )
    val height by animateDpAsState(
        targetValue = if (selected) 88.dp else 78.dp,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = Spring.StiffnessMedium),
        label = "durationHeight"
    )
    val barFraction = when (duration) {
        VideoDuration.S5 -> 0.28f
        VideoDuration.S10 -> 0.50f
        VideoDuration.S15 -> 0.74f
        VideoDuration.S30 -> 1.0f
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        shadowElevation = if (selected) 6.dp else 1.dp,
        border = BorderStroke(
            width = if (selected) 2.5.dp else 1.dp,
            color = if (selected) ActiveBlueBorder else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        ),
        modifier = modifier
            .height(height)
            .scale(scale)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = stylePreviewRes),
                contentDescription = duration.label,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        if (selected) Color(0xFF0F172A).copy(alpha = 0.52f)
                        else Color(0xFF0F172A).copy(alpha = 0.68f)
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp, vertical = 7.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = null,
                        tint = if (selected) ActiveBlueGlow else Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(14.dp)
                    )
                    Icon(
                        imageVector = Icons.Default.PlayCircleFilled,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(if (selected) 22.dp else 18.dp)
                    )
                }
                Text(
                    text = duration.label,
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.ExtraBold
                    ),
                    color = Color.White
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color.White.copy(alpha = 0.25f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(barFraction)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (selected) ActiveBlueGlow else Color.White)
                    )
                }
            }
        }
    }
}

@Composable
private fun VoiceAvatarCard(
    voiceType: VoiceType,
    label: String,
    selected: Boolean,
    isDarkMode: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.06f else 1.0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium),
        label = "voiceScale"
    )
    val avatarSize by animateDpAsState(
        targetValue = if (selected) 62.dp else 52.dp,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = Spring.StiffnessMedium),
        label = "voiceAvatarSize"
    )

    Surface(
        color = if (selected) {
            if (isDarkMode) Color(0xFF1E3A8A).copy(alpha = 0.55f) else Color(0xFFDBEAFE).copy(alpha = 0.90f)
        } else {
            MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)
        },
        shape = RoundedCornerShape(16.dp),
        shadowElevation = if (selected) 6.dp else 1.dp,
        border = BorderStroke(
            width = if (selected) 2.5.dp else 1.dp,
            color = if (selected) ActiveBlueBorder else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        ),
        modifier = modifier
            .width(if (selected) 96.dp else 84.dp)
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 9.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Image(
                    painter = painterResource(id = voiceType.avatarImageRes),
                    contentDescription = label,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(avatarSize)
                        .clip(CircleShape)
                        .border(
                            width = if (selected) 2.dp else 1.dp,
                            color = if (selected) ActiveBlueBorder else Color.White.copy(alpha = 0.7f),
                            shape = CircleShape
                        )
                )
                if (selected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = ActiveBlueBorder,
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                }
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold
                ),
                color = if (selected) ActiveBlueBorder else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MusicPreviewCard(
    mode: BackgroundMusicMode,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.06f else 1.0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium),
        label = "musicScale"
    )
    val cardWidth by animateDpAsState(
        targetValue = if (selected) 108.dp else 94.dp,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = Spring.StiffnessMedium),
        label = "musicWidth"
    )
    val cardHeight by animateDpAsState(
        targetValue = if (selected) 104.dp else 92.dp,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = Spring.StiffnessMedium),
        label = "musicHeight"
    )

    Surface(
        shape = RoundedCornerShape(16.dp),
        shadowElevation = if (selected) 7.dp else 2.dp,
        border = BorderStroke(
            width = if (selected) 2.5.dp else 1.dp,
            color = if (selected) ActiveBlueBorder else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        ),
        modifier = modifier
            .width(cardWidth)
            .height(cardHeight)
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            val previewRes = mode.previewImageRes
            if (previewRes != null) {
                Image(
                    painter = painterResource(id = previewRes),
                    contentDescription = label,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .scale(if (selected) 1.10f else 1.0f)
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.78f)
                                )
                            )
                        )
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF1E293B), Color(0xFF334155))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeOff,
                        contentDescription = label,
                        tint = if (selected) ActiveBlueGlow else Color.White,
                        modifier = Modifier
                            .padding(bottom = 14.dp)
                            .size(if (selected) 36.dp else 30.dp)
                    )
                }
            }

            if (previewRes != null) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .size(16.dp)
                )
            }

            if (selected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = ActiveBlueGlow,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(18.dp)
                )
            }

            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold
                ),
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 7.dp)
            )
        }
    }
}

@Composable
private fun RatioFramePreviewCard(
    ratio: VideoAspectRatio,
    label: String,
    previewRes: Int,
    selected: Boolean,
    isDarkMode: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.05f else 1.0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium),
        label = "ratioScale"
    )
    val cardHeight by animateDpAsState(
        targetValue = if (selected) 106.dp else 94.dp,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = Spring.StiffnessMedium),
        label = "ratioHeight"
    )

    Surface(
        color = if (selected) {
            if (isDarkMode) Color(0xFF1E3A8A).copy(alpha = 0.55f) else Color(0xFFDBEAFE).copy(alpha = 0.90f)
        } else {
            MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)
        },
        shape = RoundedCornerShape(16.dp),
        shadowElevation = if (selected) 6.dp else 1.dp,
        border = BorderStroke(
            width = if (selected) 2.5.dp else 1.dp,
            color = if (selected) ActiveBlueBorder else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        ),
        modifier = modifier
            .height(cardHeight)
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Visual Frame Preview matching vertical phone / square / wide screen
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                val frameModifier = when (ratio) {
                    VideoAspectRatio.VERTICAL_9_16 -> Modifier.fillMaxHeight().aspectRatio(9f / 16f)
                    VideoAspectRatio.SQUARE_1_1 -> Modifier.fillMaxHeight(0.86f).aspectRatio(1f)
                    VideoAspectRatio.HORIZONTAL_16_9 -> Modifier.fillMaxWidth(0.92f).aspectRatio(16f / 9f)
                }
                Box(
                    modifier = frameModifier
                        .clip(RoundedCornerShape(if (ratio == VideoAspectRatio.VERTICAL_9_16) 7.dp else 5.dp))
                        .border(
                            width = if (selected) 2.dp else 1.5.dp,
                            color = if (selected) ActiveBlueBorder else MaterialTheme.colorScheme.onSurfaceVariant,
                            shape = RoundedCornerShape(if (ratio == VideoAspectRatio.VERTICAL_9_16) 7.dp else 5.dp)
                        )
                ) {
                    Image(
                        painter = painterResource(id = previewRes),
                        contentDescription = label,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (ratio == VideoAspectRatio.VERTICAL_9_16) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 2.dp)
                                .width(10.dp)
                                .height(2.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(Color.White.copy(alpha = 0.85f))
                        )
                    } else if (ratio == VideoAspectRatio.HORIZONTAL_16_9) {
                        Icon(
                            imageVector = Icons.Default.PlayCircleFilled,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.9f),
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(16.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold
                ),
                color = if (selected) ActiveBlueBorder else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun QualityPreviewCard(
    quality: VideoQuality,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.05f else 1.0f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium),
        label = "qualityScale"
    )
    val cardHeight by animateDpAsState(
        targetValue = if (selected) 88.dp else 76.dp,
        animationSpec = spring(dampingRatio = 0.68f, stiffness = Spring.StiffnessMedium),
        label = "qualityHeight"
    )

    Surface(
        shape = RoundedCornerShape(16.dp),
        shadowElevation = if (selected) 7.dp else 2.dp,
        border = BorderStroke(
            width = if (selected) 2.5.dp else 1.dp,
            color = if (selected) ActiveBlueBorder else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
        ),
        modifier = modifier
            .height(cardHeight)
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = quality.previewImageRes),
                contentDescription = label,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .scale(if (selected) 1.10f else 1.0f)
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.72f),
                                Color.Black.copy(alpha = 0.25f)
                            )
                        )
                    )
            )
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.HighQuality,
                            contentDescription = null,
                            tint = if (quality == VideoQuality.HD) Color(0xFFFBBF24) else Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = label,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.ExtraBold
                            ),
                            color = Color.White
                        )
                    }
                    Text(
                        text = if (quality == VideoQuality.HD) "1080p Ultra Crisp" else "720p Fast",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.86f)
                    )
                }
                if (selected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = ActiveBlueGlow,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun VisualOptionSectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary
    )
}
