package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.LocalizedStrings
import com.example.ui.i18n.localizedLabel
import com.example.ui.model.AiImageEditAction
import com.example.ui.model.FaceLandmarks
import com.example.ui.model.ImageFilterType
import com.example.ui.model.ImageSizeOption
import com.example.ui.model.PhotoAction
import com.example.ui.model.VideoArtStyle


@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ImageStudioWorkspace(
    photoGenPromptText: String,
    selectedImageStyle: VideoArtStyle,
    selectedImageSize: ImageSizeOption,
    selectedFilter: ImageFilterType,
    aiEditPromptText: String,
    uploadedBitmap: Bitmap?,
    landmarks: FaceLandmarks?,
    selectedAction: PhotoAction,
    speechText: String,
    isLoading: Boolean,
    isDarkMode: Boolean,
    language: AppLanguage,
    strings: LocalizedStrings,
    onPhotoGenPromptChange: (String) -> Unit,
    onSelectImageStyle: (VideoArtStyle) -> Unit,
    onSelectImageSize: (ImageSizeOption) -> Unit,
    onGenerateAiPhoto: () -> Unit,
    onSelectFilter: (ImageFilterType) -> Unit,
    onAiEditPromptChange: (String) -> Unit,
    onApplyAiEditPreset: (AiImageEditAction) -> Unit,
    onApplyCustomAiEdit: () -> Unit,
    onUploadPhotoClick: () -> Unit,
    onSelectAction: (PhotoAction) -> Unit,
    onSpeechTextChange: (String) -> Unit,
    onUseSampleSpeech: () -> Unit,
    onGenerateVideo: () -> Unit
) {
    val activeFilter = remember(selectedFilter) {
        selectedFilter.toColorMatrix()?.array?.let { ColorFilter.colorMatrix(ColorMatrix(it)) }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Upload Photo CTA
        Button(
            onClick = onUploadPhotoClick,
            enabled = !isLoading,
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
            contentPadding = PaddingValues(vertical = 16.dp, horizontal = 18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .testTag("btn_convert_photo_video")
        ) {
            Icon(
                imageVector = Icons.Default.PhotoCamera,
                contentDescription = null,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = strings.btnConvertPhotoVideo,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
        }

        // AI Image Generator Card (Style + Size + Prompt)
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            isDarkMode = isDarkMode
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = strings.secPhotoGenAndEdit,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                OutlinedTextField(
                    value = photoGenPromptText,
                    onValueChange = onPhotoGenPromptChange,
                    placeholder = {
                        Text(
                            text = strings.photoGenPromptHint,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    trailingIcon = {
                        if (photoGenPromptText.isNotEmpty()) {
                            IconButton(onClick = { onPhotoGenPromptChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = strings.clearTextDesc
                                )
                            }
                        }
                    },
                    minLines = 2,
                    maxLines = 4,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.56f),
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("photo_gen_prompt_input")
                )

                OptionRowLabel(text = strings.optStyle)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(VideoArtStyle.entries) { style ->
                        StylePreviewCard(
                            style = style,
                            label = style.localizedLabel(language),
                            selected = style == selectedImageStyle,
                            onClick = { onSelectImageStyle(style) },
                            modifier = Modifier.testTag("image_style_${style.name.lowercase()}")
                        )
                    }
                }

                OptionRowLabel(text = strings.optImageSize)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ImageSizeOption.entries.forEach { sizeOpt ->
                        StudioFilterChip(
                            label = sizeOpt.localizedLabel(language),
                            selected = sizeOpt == selectedImageSize,
                            onClick = { onSelectImageSize(sizeOpt) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("image_size_${sizeOpt.name.lowercase()}")
                        )
                    }
                }

                Button(
                    onClick = onGenerateAiPhoto,
                    enabled = !isLoading,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_generate_ai_photo")
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = strings.btnGeneratePhotoOnly,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }

        if (uploadedBitmap == null) {
            GlassmorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onUploadPhotoClick),
                shape = RoundedCornerShape(22.dp),
                isDarkMode = isDarkMode
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = CircleShape,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = strings.btnConvertPhotoVideo,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = strings.onboardingPhotoTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = strings.onboardingPhotoBody,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Active Photo Card: Live Filter + AI Edit Tools + Animate to Video
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                isDarkMode = isDarkMode
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.step1UploadedPhoto,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        OutlinedButton(
                            onClick = onUploadPhotoClick,
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_change_uploaded_photo")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = strings.changePhoto,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = strings.changePhoto,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(selectedImageSize.ratioFloat.coerceIn(0.65f, 1.78f))
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF0F172A))
                    ) {
                        Image(
                            bitmap = uploadedBitmap.asImageBitmap(),
                            contentDescription = strings.step1UploadedPhoto,
                            colorFilter = activeFilter,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("uploaded_photo_preview")
                        )
                        Surface(
                            color = Color.Black.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = if (landmarks?.hasFace == true) strings.faceDetectedBadge else strings.sceneReadyBadge,
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    // Filter Bar (نيون / سحري / أبيض وأسود / ملون / قديم)
                    OptionRowLabel(text = strings.optFilter)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ImageFilterType.entries) { filter ->
                            StudioFilterChip(
                                label = filter.localizedLabel(language),
                                selected = filter == selectedFilter,
                                onClick = { onSelectFilter(filter) },
                                modifier = Modifier.testTag("image_filter_${filter.name.lowercase()}")
                            )
                        }
                    }

                    // Edit with AI Section
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoFixHigh,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = strings.secAiImageEdit,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AiImageEditAction.entries.forEach { editAction ->
                            FilledTonalButton(
                                onClick = { onApplyAiEditPreset(editAction) },
                                enabled = !isLoading,
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                modifier = Modifier.testTag("ai_edit_${editAction.name.lowercase()}")
                            ) {
                                Text(
                                    text = editAction.localizedLabel(language),
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = aiEditPromptText,
                        onValueChange = onAiEditPromptChange,
                        placeholder = {
                            Text(
                                text = strings.aiEditPromptHint,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        trailingIcon = {
                            if (aiEditPromptText.isNotEmpty()) {
                                IconButton(onClick = { onAiEditPromptChange("") }) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = strings.clearTextDesc)
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.56f),
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_edit_custom_input")
                    )

                    FilledTonalButton(
                        onClick = onApplyCustomAiEdit,
                        enabled = !isLoading && aiEditPromptText.isNotBlank(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_apply_custom_ai_edit")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoFixHigh,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = strings.btnApplyAiEdit,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    // Photo Animation Controls
                    Text(
                        text = strings.step2WhatToDo,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.testTag("question_what_to_do")
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        PhotoAction.entries.chunked(3).forEach { rowActions ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rowActions.forEach { action ->
                                    val isSelected = action == selectedAction
                                    Surface(
                                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.surface.copy(alpha = 0.65f),
                                        shape = RoundedCornerShape(14.dp),
                                        border = BorderStroke(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.outline
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(52.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .clickable { onSelectAction(action) }
                                            .testTag("action_option_${action.name.lowercase()}")
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .padding(horizontal = 6.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(text = action.emoji, fontSize = 16.sp)
                                            Spacer(modifier = Modifier.width(5.dp))
                                            Text(
                                                text = action.localizedLabel(language),
                                                style = MaterialTheme.typography.labelLarge,
                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                                                else MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.step3WhatToSpeak,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        SuggestionChip(
                            onClick = onUseSampleSpeech,
                            label = {
                                Text(
                                    text = strings.fillSampleSpeech,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier.testTag("btn_fill_sample_speech")
                        )
                    }

                    OutlinedTextField(
                        value = speechText,
                        onValueChange = onSpeechTextChange,
                        placeholder = {
                            Text(
                                text = strings.speakTextHint,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        trailingIcon = {
                            if (speechText.isNotEmpty()) {
                                IconButton(onClick = { onSpeechTextChange("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = strings.clearTextDesc,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        },
                        minLines = 2,
                        maxLines = 4,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.56f),
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("image_to_video_speech_input")
                    )

                    Button(
                        onClick = onGenerateVideo,
                        enabled = !isLoading,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(vertical = 14.dp, horizontal = 16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("btn_generate_image_video")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MovieCreation,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.btnGenerateVideo,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionRowLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
fun StudioFilterChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
        ),
        modifier = modifier
            .height(42.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 12.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                ),
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
