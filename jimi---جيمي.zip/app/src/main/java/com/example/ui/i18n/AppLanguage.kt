package com.example.ui.i18n

import androidx.compose.ui.unit.LayoutDirection
import com.example.ui.model.AiImageEditAction
import com.example.ui.model.BackgroundMusicMode
import com.example.ui.model.BgChangeSpeed
import com.example.ui.model.FantasyBackground
import com.example.ui.model.ImageFilterType
import com.example.ui.model.ImageSizeOption
import com.example.ui.model.PhotoAction
import com.example.ui.model.RobotPersonality
import com.example.ui.model.VideoArtStyle
import com.example.ui.model.VideoAspectRatio
import com.example.ui.model.VideoCategory
import com.example.ui.model.VideoQuality
import com.example.ui.model.VoiceSpeedOption
import com.example.ui.model.VoiceType
import java.util.Locale

enum class AppLanguage(
    val chipLabel: String,
    val ttsLocales: List<Locale>,
    val speechRecognizerTag: String,
    val layoutDirection: LayoutDirection,
    val aiLanguageInstruction: String
) {
    DARIJA(
        chipLabel = "دارجة",
        ttsLocales = listOf(Locale("ar", "MA"), Locale("ar", "SA"), Locale("ar")),
        speechRecognizerTag = "ar-MA",
        layoutDirection = LayoutDirection.Rtl,
        aiLanguageInstruction = "natural Moroccan Darija (الدارجة المغربية)"
    ),
    ARABIC(
        chipLabel = "العربية",
        ttsLocales = listOf(Locale("ar", "SA"), Locale("ar", "MA"), Locale("ar")),
        speechRecognizerTag = "ar-SA",
        layoutDirection = LayoutDirection.Rtl,
        aiLanguageInstruction = "clear Modern Standard Arabic (العربية الفصحى)"
    ),
    FRENCH(
        chipLabel = "Français",
        ttsLocales = listOf(Locale.FRANCE, Locale.FRENCH),
        speechRecognizerTag = "fr-FR",
        layoutDirection = LayoutDirection.Ltr,
        aiLanguageInstruction = "natural French"
    ),
    ENGLISH(
        chipLabel = "English",
        ttsLocales = listOf(Locale.US, Locale.ENGLISH),
        speechRecognizerTag = "en-US",
        layoutDirection = LayoutDirection.Ltr,
        aiLanguageInstruction = "natural English"
    ),
    SPANISH(
        chipLabel = "Español",
        ttsLocales = listOf(Locale("es", "ES"), Locale("es")),
        speechRecognizerTag = "es-ES",
        layoutDirection = LayoutDirection.Ltr,
        aiLanguageInstruction = "natural Spanish"
    );

    companion object {
        val primaryLanguages = listOf(DARIJA, ARABIC, FRENCH, ENGLISH)
    }
}

data class LocalizedStrings(
    val studioBadge: String,
    val studioTagline: String,
    val freeBadge: String,
    val heroTitle: String,
    val heroSubtitle: String,
    val tabVideo: String,
    val tabPhoto: String,
    val tabRobot: String,
    val openSettingsDesc: String,
    // Text to Video + Extended Video Options
    val promptHint: String,
    val clearTextDesc: String,
    val btnWriteWithJimi: String,
    val btnTextToVideo: String,
    val btnAnimatePhoto: String,
    val btnImageGen: String,
    val btnAiCreate: String,
    val secVideoOptions: String,
    val optStyle: String,
    val optDuration: String,
    val optVoice: String,
    val optMusic: String,
    val optQuality: String,
    val optRatio: String,
    val categoriesTitle: String,
    val chooseCategoryHint: String,
    val readyIdeasPrefix: String,
    val recentCreationsTitle: String,
    // Image Generation, Editing & Animation
    val btnConvertPhotoVideo: String,
    val onboardingPhotoTitle: String,
    val onboardingPhotoBody: String,
    val secPhotoGenAndEdit: String,
    val photoGenPromptHint: String,
    val btnGeneratePhotoOnly: String,
    val optImageSize: String,
    val optFilter: String,
    val secAiImageEdit: String,
    val aiEditPromptHint: String,
    val btnApplyAiEdit: String,
    val step1UploadedPhoto: String,
    val changePhoto: String,
    val faceDetectedBadge: String,
    val sceneReadyBadge: String,
    val step2WhatToDo: String,
    val step3WhatToSpeak: String,
    val fillSampleSpeech: String,
    val speakTextHint: String,
    val btnGenerateVideo: String,
    // Video Player
    val liveVideoBadge: String,
    val pausedBadge: String,
    val generatedImageSubtitle: String,
    val talkingFaceSubtitle: String,
    val cinematicMotionSubtitle: String,
    val btnPlay: String,
    val btnPause: String,
    val btnConvertToVideo: String,
    val btnDownload: String,
    val btnShare: String,
    val retryBtn: String,
    // Errors & loading
    val emptyPromptError: String,
    val emptyImagePromptError: String,
    val emptyPhotoError: String,
    val emptySpeechError: String,
    val emptyAiEditError: String,
    val stepWritingScript: String,
    val stepPreparingScript: String,
    val stepGeneratingImage: String,
    val stepEditingImage: String,
    val stepAnalyzingFace: String,
    val stepAnalyzingPhoto: String,
    val exportingLabel: String,
    val shareReadyLabel: String,
    // JIMI Chat
    val robotTitle: String,
    val robotSubtitle: String,
    val robotStatusReady: String,
    val robotStatusListening: String,
    val robotStatusThinking: String,
    val robotStatusSpeaking: String,
    val robotWelcomeMessage: String,
    val robotInputHint: String,
    val robotQuickTopicsTitle: String,
    val robotQuickTopics: List<Pair<String, String>>,
    val robotSpeakAnswerDesc: String,
    val robotStopSpeakingDesc: String,
    val robotMicStartDesc: String,
    val robotMicStopDesc: String,
    val robotMicDeniedError: String,
    val robotMicUnavailableError: String,
    val robotEmptyQuestionError: String,
    // Settings Screen
    val settingsTitle: String,
    val btnBack: String,
    val secBackground: String,
    val autoChangeBgLabel: String,
    val bgSpeedLabel: String,
    val favoriteBgLabel: String,
    val btnChangeBg: String,
    val btnUploadCustomBg: String,
    val customBgActiveLabel: String,
    val secLanguage: String,
    val secVoice: String,
    val voiceOnOffLabel: String,
    val chooseVoiceLabel: String,
    val voiceSpeedLabel: String,
    val secRobot: String,
    val robotNameLabel: String,
    val robotNameHint: String,
    val robotPersonalityLabel: String,
    val secAppearance: String,
    val lightModeLabel: String,
    val darkModeLabel: String,
    val settingsSavedAutoNote: String,
    // Phone Control & Home Icon
    val secPhoneControl: String,
    val btnOpenWhatsApp: String,
    val btnOpenYouTube: String,
    val btnOpenTikTok: String,
    val btnVibrate: String,
    val btnFlashlightOn: String,
    val btnFlashlightOff: String,
    val volumeLabel: String,
    val btnVolumeDown: String,
    val btnVolumeUp: String,
    val btnPinHomeIcon: String,
    // Floating JIMI Assistant & Wake Word
    val floatingJimiTitle: String,
    val floatingJimiSubtitle: String,
    val floatingJimiWakeGreeting: String,
    val floatingJimiWakeSwitch: String,
    val floatingJimiWakeHint: String,
    val floatingJimiTalkBtn: String,
    val floatingJimiListeningCmd: String,
    val floatingJimiTryCommands: String,
    val floatingJimiSampleCommands: List<String>,
    // Daily 24h Background & Tomorrow Preview
    val dailyBgLabel: String,
    val btnPreviewTomorrowBg: String,
    val tomorrowBgTitle: String,
    val tomorrowBgMidnightNote: String,
    val tomorrowBgNextDayBtn: String,
    val closeBtn: String,
    // Gemini API Key Gate & Settings
    val secApiKey: String,
    val apiKeyTitle: String,
    val apiKeySubtitle: String,
    val apiKeyInputHint: String,
    val btnGetFreeKey: String,
    val btnSaveApiKey: String,
    val btnSkipApiKey: String,
    val btnChangeApiKey: String,
    val apiKeySavedStatus: String,
    val apiKeyNotSetStatus: String,
    val apiKeyMissingError: String
)

fun stringsFor(language: AppLanguage): LocalizedStrings = when (language) {
    AppLanguage.DARIJA -> LocalizedStrings(
        studioBadge = "JIMI - جيمي",
        studioTagline = "المساعد الخيالي الذكي",
        freeBadge = "AI سحري",
        heroTitle = "مولد الفيديو مع جيمي",
        heroSubtitle = "صاوب فيديوهات، عدّل وحرك صورك، وتحكم فهاتفك بالصوت مع JIMI",
        tabVideo = "فيديو",
        tabPhoto = "صورة",
        tabRobot = "جيمي",
        openSettingsDesc = "الإعدادات",
        promptHint = "كتب شنو بغيتي في الفيديو...",
        clearTextDesc = "مسح النص",
        btnWriteWithJimi = "خلي JIMI يكتب ليا النص ✨",
        btnTextToVideo = "تحويل النص إلى فيديو",
        btnAnimatePhoto = "تحريك صورة",
        btnImageGen = "مولد الصور",
        btnAiCreate = "إنشاء بالذكاء الاصطناعي",
        secVideoOptions = "إعدادات الفيديو الاحترافية",
        optStyle = "الستايل",
        optDuration = "المدة",
        optVoice = "الصوت",
        optMusic = "الموسيقى",
        optQuality = "الجودة",
        optRatio = "المقاس",
        categoriesTitle = "الأقسام الشائعة",
        chooseCategoryHint = "اختار موضوع الفيديو",
        readyIdeasPrefix = "أفكار جاهزة لقسم",
        recentCreationsTitle = "إبداعاتك الأخيرة",
        btnConvertPhotoVideo = "حول صورتك لفيديو 📸",
        onboardingPhotoTitle = "توليد، تعديل وتحريك الصور مع JIMI",
        onboardingPhotoBody = "ولد صورة بالذكاء الاصطناعي ولا رفع صورتك، زيد فلاتر، عدلها بـ AI، وحولها لفيديو كيهضر!",
        secPhotoGenAndEdit = "توليد وتعديل الصور بالذكاء الاصطناعي",
        photoGenPromptHint = "وصف الصورة لي بغيتي JIMI يصاوبها ليك...",
        btnGeneratePhotoOnly = "توليد صورة بـ AI ✨",
        optImageSize = "حجم الصورة",
        optFilter = "الفلتر",
        secAiImageEdit = "تعديل بالذكاء الاصطناعي ✨",
        aiEditPromptHint = "شنو بغيتي JIMI يبدل في الصورة؟",
        btnApplyAiEdit = "طبق التعديل بـ AI",
        step1UploadedPhoto = "الصورة المختارة",
        changePhoto = "تبديل الصورة",
        faceDetectedBadge = "✓ تم تحديد الوجه والعينين والفك",
        sceneReadyBadge = "✓ جاهزة للتحريك والتعديل",
        step2WhatToDo = "شنو بغيتي يدير في الفيديو؟",
        step3WhatToSpeak = "شنو بغيتي يقول في الفيديو؟",
        fillSampleSpeech = "جملة جاهزة",
        speakTextHint = "كتب النص لي بغيتيه ينطق بيه...",
        btnGenerateVideo = "ولد الفيديو",
        liveVideoBadge = "فيديو مباشر",
        pausedBadge = "متوقف",
        generatedImageSubtitle = "صورة مولدة بالذكاء الاصطناعي",
        talkingFaceSubtitle = "تحريك الوجه والشفاه",
        cinematicMotionSubtitle = "تحريك سينمائي ذكي",
        btnPlay = "تشغيل",
        btnPause = "إيقاف",
        btnConvertToVideo = "حولها لفيديو",
        btnDownload = "تحميل",
        btnShare = "مشاركة",
        retryBtn = "إعادة",
        emptyPromptError = "عافاك كتب شنو بغيتي في الفيديو أولاً أو ضغط على \"خلي JIMI يكتب ليا النص\".",
        emptyImagePromptError = "كتب وصف الصورة لي بغيتي تولد بالذكاء الاصطناعي.",
        emptyPhotoError = "عافاك رفع صورة ولا ولد وحدة بالذكاء الاصطناعي أولاً.",
        emptySpeechError = "عافاك كتب النص لي بغيتي الصورة تقول في الفيديو!",
        emptyAiEditError = "اختار تعديل جاهز ولا كتب شنو بغيتي JIMI يبدل في الصورة.",
        stepWritingScript = "JIMI كيكتب ليك نص مبدع بالذكاء الاصطناعي...",
        stepPreparingScript = "جيمي كيجهز السيناريو والستايل...",
        stepGeneratingImage = "جيمي كيرسم المشهد بالذكاء الاصطناعي...",
        stepEditingImage = "جيمي كيعدل الصورة بالذكاء الاصطناعي...",
        stepAnalyzingFace = "كنحللو ملامح الوجه وكنحضرو الفيديو...",
        stepAnalyzingPhoto = "كنقراو الصورة وكنحللو ملامح الوجه...",
        exportingLabel = "كنجهزو الملف...",
        shareReadyLabel = "جاهز للمشاركة!",
        robotTitle = "جيمي - JIMI 🤖",
        robotSubtitle = "سولني بالكتابة أو الميكروفون أو عطيني أوامر التحكم فالهاتف",
        robotStatusReady = "نعم؟ أنا JIMI جاهز",
        robotStatusListening = "جيمي كيسمعك دابا...",
        robotStatusThinking = "جيمي كيفكر في الجواب...",
        robotStatusSpeaking = "جيمي كيتكلم دابا...",
        robotWelcomeMessage = "نعم؟ أنا JIMI 🤖! سولني أي سؤال بالدارجة (دروس، قصص، نكت، تمارين) أو قول ليا: افتح يوتيوب، بدل الخلفية، ولا شعل الفلاش!",
        robotInputHint = "هضر مع جيمي بالكتابة أو بالميكروفون...",
        robotQuickTopicsTitle = "جرب تسول JIMI على:",
        robotQuickTopics = listOf(
            "📚 درس مبسط" to "شرح ليا كيفاش كتخدم الجاذبية بطريقة سهلة بالدارجة",
            "📖 قصة خيالية" to "حكي ليا قصة خيالية قصيرة ومشوقة بالدارجة المغربية",
            "😂 نكتة زوينة" to "قول ليا شي نكتة زوينة ومضحكة بالدارجة",
            "📝 تمرين رياضيات" to "عاوني نفهم كيفاش نحل معادلة من الدرجة الأولى بمثال بسيط"
        ),
        robotSpeakAnswerDesc = "قراءة الجواب بالصوت",
        robotStopSpeakingDesc = "إيقاف الصوت",
        robotMicStartDesc = "تحدث بالميكروفون",
        robotMicStopDesc = "إيقاف الميكروفون",
        robotMicDeniedError = "خاصك تسمح للميكروفون باش تقدر تهضر مع JIMI بالصوت.",
        robotMicUnavailableError = "التعرف على الصوت ما متوفرش على هاد الجهاز، تقدر تكتب سؤالك مباشرة.",
        robotEmptyQuestionError = "كتب سؤالك أو تكلم في الميكروفون أولاً.",
        settingsTitle = "إعدادات JIMI",
        btnBack = "رجوع",
        secBackground = "1) خلفية اليوم (تتبدل عند 00:00)",
        autoChangeBgLabel = "تغيير تلقائي كل 24 ساعة (00:00)",
        bgSpeedLabel = "تغيير كل 24 ساعة",
        favoriteBgLabel = "اختار خلفية اليوم من 10 خلفيات حقيقية",
        btnChangeBg = "شوف خلفيات غدا",
        btnUploadCustomBg = "رفع صورة خلفية خاصة 📸",
        customBgActiveLabel = "✓ الخلفية المخصصة مفعلة",
        secLanguage = "2) اللغة",
        secVoice = "3) الصوت",
        voiceOnOffLabel = "تفعيل الصوت",
        chooseVoiceLabel = "نوع الصوت (رجل / مرا / طفل / روبوت)",
        voiceSpeedLabel = "سرعة الصوت",
        secRobot = "4) شخصية جيمي",
        robotNameLabel = "الاسم",
        robotNameHint = "JIMI",
        robotPersonalityLabel = "أسلوب الإجابة",
        secAppearance = "5) المظهر",
        lightModeLabel = "نهاري (فاتح)",
        darkModeLabel = "ليلي (داكن)",
        settingsSavedAutoNote = "جميع إعدادات JIMI كتحفظ تلقائياً",
        secPhoneControl = "6) التحكم في الهاتف والأيقونة",
        btnOpenWhatsApp = "افتح واتساب",
        btnOpenYouTube = "افتح يوتيوب",
        btnOpenTikTok = "افتح تيك توك",
        btnVibrate = "اهتزاز الهاتف",
        btnFlashlightOn = "شعل الفلاش",
        btnFlashlightOff = "طفي الفلاش",
        volumeLabel = "مستوى الصوت",
        btnVolumeDown = "نقص الصوت",
        btnVolumeUp = "زيد الصوت",
        btnPinHomeIcon = "تثبيت أيقونة JIMI على الشاشة الرئيسية",
        floatingJimiTitle = "المساعد العائم JIMI ✨",
        floatingJimiSubtitle = "قول \"JIMI\" أو \"جيمي\" باش يفيق ويجاوبك: نعم؟ أنا JIMI",
        floatingJimiWakeGreeting = "نعم؟ أنا JIMI",
        floatingJimiWakeSwitch = "تفعيل النداء الصوتي \"JIMI / جيمي\"",
        floatingJimiWakeHint = "ملي كيكون مفعل، غير قول \"JIMI افتح يوتيوب\" أو \"JIMI شعل الفلاش\"",
        floatingJimiTalkBtn = "تكلم مع JIMI دابا",
        floatingJimiListeningCmd = "قول أمرك دابا (مثلاً: افتح يوتيوب، بدل الخلفية، شعل الفلاش)...",
        floatingJimiTryCommands = "أوامر سريعة تقدر تقولها أو تضغط عليها:",
        floatingJimiSampleCommands = listOf(
            "JIMI افتح يوتيوب",
            "JIMI بدل الخلفية",
            "JIMI شعل الفلاش",
            "JIMI افتح واتساب",
            "JIMI افتح تيك توك",
            "JIMI هز الهاتف"
        ),
        dailyBgLabel = "خلفية اليوم",
        btnPreviewTomorrowBg = "شوف خلفيات غدا",
        tomorrowBgTitle = "معاينة خلفيات غدا ✨",
        tomorrowBgMidnightNote = "كتبدل الخلفية مرة وحدة كل 24 ساعة مع 00:00",
        tomorrowBgNextDayBtn = "شوف اليوم لي بعدو",
        closeBtn = "إغلاق",
        secApiKey = "مفتاح Gemini API",
        apiKeyTitle = "أدخل مفتاح Gemini API الخاص بك",
        apiKeySubtitle = "جميع ميزات الذكاء الاصطناعي كتخدم فقط بمفتاحك المجاني من Google AI Studio وكيتحفظ فجهازك.",
        apiKeyInputHint = "لصق مفتاح Gemini API (AIza...) هنا",
        btnGetFreeKey = "Get Free Key",
        btnSaveApiKey = "حفظ المفتاح والمتابعة",
        btnSkipApiKey = "متابعة بدون مفتاح",
        btnChangeApiKey = "تغيير مفتاح Gemini API",
        apiKeySavedStatus = "مفتاح مفعل ومحفوظ",
        apiKeyNotSetStatus = "ما كاينش مفتاح — الذكاء الاصطناعي متوقف",
        apiKeyMissingError = "عافاك دخل مفتاح Gemini API ديالك أولاً باش تقدر تولد بالذكاء الاصطناعي."
    )

    AppLanguage.ARABIC -> LocalizedStrings(
        studioBadge = "JIMI - جيمي",
        studioTagline = "المساعد الخيالي الذكي",
        freeBadge = "AI سحري",
        heroTitle = "مولد الفيديو مع جيمي",
        heroSubtitle = "أنشئ فيديوهات، عدّل وحرّك صورك، وتحكم بهاتفك صوتياً مع JIMI",
        tabVideo = "فيديو",
        tabPhoto = "صورة",
        tabRobot = "جيمي",
        openSettingsDesc = "الإعدادات",
        promptHint = "اكتب ما تريد مشاهدته في الفيديو...",
        clearTextDesc = "مسح النص",
        btnWriteWithJimi = "خلي JIMI يكتب ليا النص ✨",
        btnTextToVideo = "تحويل النص إلى فيديو",
        btnAnimatePhoto = "تحريك صورة",
        btnImageGen = "مولد الصور",
        btnAiCreate = "إنشاء بالذكاء الاصطناعي",
        secVideoOptions = "خيارات الفيديو المتقدمة",
        optStyle = "النمط",
        optDuration = "المدة",
        optVoice = "الصوت",
        optMusic = "الموسيقى",
        optQuality = "الجودة",
        optRatio = "الأبعاد",
        categoriesTitle = "الأقسام الشائعة",
        chooseCategoryHint = "اختر موضوع الفيديو",
        readyIdeasPrefix = "أفكار جاهزة لقسم",
        recentCreationsTitle = "إبداعاتك الأخيرة",
        btnConvertPhotoVideo = "حوّل صورتك إلى فيديو 📸",
        onboardingPhotoTitle = "توليد وتعديل وتحريك الصور مع JIMI",
        onboardingPhotoBody = "أنشئ صورة بالذكاء الاصطناعي أو ارفع صورتك، أضف فلتراً، عدلها بـ AI، وحوّلها لفيديو ناطق!",
        secPhotoGenAndEdit = "توليد وتعديل الصور بالذكاء الاصطناعي",
        photoGenPromptHint = "صف الصورة التي تريد من JIMI رسمها...",
        btnGeneratePhotoOnly = "توليد صورة بـ AI ✨",
        optImageSize = "الحجم",
        optFilter = "الفلتر",
        secAiImageEdit = "تعديل بالذكاء الاصطناعي ✨",
        aiEditPromptHint = "شنو بغيتي JIMI يبدل في الصورة؟",
        btnApplyAiEdit = "تطبيق التعديل بـ AI",
        step1UploadedPhoto = "الصورة المختارة",
        changePhoto = "تغيير الصورة",
        faceDetectedBadge = "✓ تم تحديد الوجه والعينين والفك",
        sceneReadyBadge = "✓ جاهزة للتحريك والتعديل",
        step2WhatToDo = "ماذا تريد أن يفعل في الفيديو؟",
        step3WhatToSpeak = "ماذا تريد أن يقول في الفيديو؟",
        fillSampleSpeech = "عبارة جاهزة",
        speakTextHint = "اكتب النص الذي سينطق به...",
        btnGenerateVideo = "ولّد الفيديو",
        liveVideoBadge = "فيديو مباشر",
        pausedBadge = "متوقف",
        generatedImageSubtitle = "صورة مولدة بالذكاء الاصطناعي",
        talkingFaceSubtitle = "تحريك الوجه والشفاه",
        cinematicMotionSubtitle = "تحريك سينمائي ذكي",
        btnPlay = "تشغيل",
        btnPause = "إيقاف",
        btnConvertToVideo = "تحويل لفيديو",
        btnDownload = "تحميل",
        btnShare = "مشاركة",
        retryBtn = "إعادة",
        emptyPromptError = "يرجى كتابة وصف الفيديو أو الضغط على \"خلي JIMI يكتب ليا النص\".",
        emptyImagePromptError = "يرجى كتابة وصف الصورة التي تريد إنشاءها.",
        emptyPhotoError = "يرجى رفع صورة أو توليد صورة بالذكاء الاصطناعي أولاً.",
        emptySpeechError = "يرجى كتابة النص الذي ستنطق به الصورة.",
        emptyAiEditError = "اختر إجراء تعديل أو اكتب التعديل المطلوب للصورة.",
        stepWritingScript = "جيمي يكتب لك نصاً إبداعياً...",
        stepPreparingScript = "جيمي يجهز السيناريو والنمط...",
        stepGeneratingImage = "جيمي يرسم المشهد بالذكاء الاصطناعي...",
        stepEditingImage = "جيمي يعدل الصورة بالذكاء الاصطناعي...",
        stepAnalyzingFace = "جاري تحليل ملامح الوجه وإعداد الفيديو...",
        stepAnalyzingPhoto = "جاري تحليل الصورة المرفوعة...",
        exportingLabel = "جاري حفظ الملف...",
        shareReadyLabel = "جاهز للمشاركة!",
        robotTitle = "جيمي - JIMI 🤖",
        robotSubtitle = "اسألني كتابةً أو صوتاً أو أعطني أوامر التحكم بالهاتف",
        robotStatusReady = "نعم؟ أنا JIMI جاهز",
        robotStatusListening = "جيمي يستمع إليك...",
        robotStatusThinking = "جيمي يفكر في الإجابة...",
        robotStatusSpeaking = "جيمي يتحدث الآن...",
        robotWelcomeMessage = "نعم؟ أنا JIMI 🤖! اسألني أي سؤال في الدروس أو القصص، أو اطلب مني فتح يوتيوب، تغيير الخلفية، أو تشغيل الفلاش!",
        robotInputHint = "تحدث مع جيمي كتابةً أو عبر الميكروفون...",
        robotQuickTopicsTitle = "جرّب سؤال JIMI عن:",
        robotQuickTopics = listOf(
            "📚 درس مبسط" to "اشرح لي كيفية عمل الجاذبية بأسلوب مبسط وواضح",
            "📖 قصة خيالية" to "احكِ لي قصة خيالية قصيرة ومشوقة",
            "😂 طرفة لطيفة" to "أخبرني طرفة لطيفة ومناسبة للجميع",
            "📝 مساعدة واجبات" to "ساعدني على فهم حل معادلة من الدرجة الأولى بمثال واضح"
        ),
        robotSpeakAnswerDesc = "قراءة الإجابة صوتياً",
        robotStopSpeakingDesc = "إيقاف الصوت",
        robotMicStartDesc = "التحدث عبر الميكروفون",
        robotMicStopDesc = "إيقاف الميكروفون",
        robotMicDeniedError = "يرجى السماح بإذن الميكروفون للتحدث صوتياً مع JIMI.",
        robotMicUnavailableError = "التعرف الصوتي غير متوفر على هذا الجهاز، يمكنك كتابة سؤالك.",
        robotEmptyQuestionError = "يرجى كتابة سؤال أو التحدث في الميكروفون أولاً.",
        settingsTitle = "إعدادات JIMI",
        btnBack = "رجوع",
        secBackground = "1) خلفية اليوم (تتغير عند 00:00)",
        autoChangeBgLabel = "تغيير تلقائي كل 24 ساعة (00:00)",
        bgSpeedLabel = "تغيير كل 24 ساعة",
        favoriteBgLabel = "اختر خلفية اليوم",
        btnChangeBg = "شوف خلفيات غدا",
        btnUploadCustomBg = "رفع خلفية من الهاتف 📸",
        customBgActiveLabel = "✓ الخلفية المخصصة مفعلة",
        secLanguage = "2) اللغة",
        secVoice = "3) الصوت",
        voiceOnOffLabel = "تفعيل الصوت",
        chooseVoiceLabel = "نوع الصوت",
        voiceSpeedLabel = "سرعة الصوت",
        secRobot = "4) شخصية جيمي",
        robotNameLabel = "الاسم",
        robotNameHint = "JIMI",
        robotPersonalityLabel = "أسلوب الرد",
        secAppearance = "5) المظهر",
        lightModeLabel = "الوضع الفاتح",
        darkModeLabel = "الوضع الداكن",
        settingsSavedAutoNote = "يتم حفظ جميع إعدادات JIMI تلقائياً",
        secPhoneControl = "6) التحكم في الهاتف والأيقونة",
        btnOpenWhatsApp = "افتح واتساب",
        btnOpenYouTube = "افتح يوتيوب",
        btnOpenTikTok = "افتح تيك توك",
        btnVibrate = "اهتزاز الهاتف",
        btnFlashlightOn = "شعل الفلاش",
        btnFlashlightOff = "إطفاء الفلاش",
        volumeLabel = "مستوى الصوت",
        btnVolumeDown = "خفض الصوت",
        btnVolumeUp = "رفع الصوت",
        btnPinHomeIcon = "تثبيت أيقونة JIMI على الشاشة الرئيسية",
        floatingJimiTitle = "المساعد العائم JIMI ✨",
        floatingJimiSubtitle = "قل \"JIMI\" أو \"جيمي\" ليستيقظ ويرد: نعم؟ أنا JIMI",
        floatingJimiWakeGreeting = "نعم؟ أنا JIMI",
        floatingJimiWakeSwitch = "تفعيل النداء الصوتي \"JIMI / جيمي\"",
        floatingJimiWakeHint = "عند التفعيل، قل مثلاً: \"JIMI افتح يوتيوب\" أو \"JIMI شعل الفلاش\"",
        floatingJimiTalkBtn = "تحدث مع JIMI الآن",
        floatingJimiListeningCmd = "انطق أمرك الآن...",
        floatingJimiTryCommands = "أوامر سريعة يمكنك قولها أو النقر عليها:",
        floatingJimiSampleCommands = listOf(
            "JIMI افتح يوتيوب",
            "JIMI بدل الخلفية",
            "JIMI شعل الفلاش",
            "JIMI افتح واتساب",
            "JIMI افتح تيك توك",
            "JIMI اهتزاز الهاتف"
        ),
        dailyBgLabel = "خلفية اليوم",
        btnPreviewTomorrowBg = "شوف خلفيات غدا",
        tomorrowBgTitle = "معاينة خلفيات غدا ✨",
        tomorrowBgMidnightNote = "تتغير الخلفية تلقائياً مرة واحدة يومياً عند الساعة 00:00",
        tomorrowBgNextDayBtn = "معاينة اليوم التالي",
        closeBtn = "إغلاق",
        secApiKey = "مفتاح Gemini API",
        apiKeyTitle = "أدخل مفتاح Gemini API الخاص بك",
        apiKeySubtitle = "تعمل جميع ميزات الذكاء الاصطناعي حصرياً بمفتاحك من Google AI Studio ويتم حفظه محلياً.",
        apiKeyInputHint = "الصق مفتاح Gemini API (AIza...) هنا",
        btnGetFreeKey = "Get Free Key",
        btnSaveApiKey = "حفظ المفتاح والمتابعة",
        btnSkipApiKey = "متابعة بدون مفتاح",
        btnChangeApiKey = "تغيير مفتاح Gemini API",
        apiKeySavedStatus = "المفتاح محفوظ ومفعل",
        apiKeyNotSetStatus = "لا يوجد مفتاح — التوليد بالذكاء الاصطناعي معطل",
        apiKeyMissingError = "يرجى إدخال مفتاح Gemini API الخاص بك أولاً لتشغيل التوليد بالذكاء الاصطناعي."
    )

    AppLanguage.FRENCH -> LocalizedStrings(
        studioBadge = "JIMI - جيمي",
        studioTagline = "Assistant IA Fantastique",
        freeBadge = "Magie IA",
        heroTitle = "Générateur Vidéo JIMI",
        heroSubtitle = "Créez des vidéos, éditez & animez vos photos et contrôlez votre téléphone",
        tabVideo = "Vidéo",
        tabPhoto = "Photo",
        tabRobot = "JIMI",
        openSettingsDesc = "Paramètres",
        promptHint = "Décrivez la vidéo que vous voulez créer...",
        clearTextDesc = "Effacer",
        btnWriteWithJimi = "Laisser JIMI écrire le texte ✨",
        btnTextToVideo = "Texte en Vidéo",
        btnAnimatePhoto = "Animer Photo",
        btnImageGen = "Générer Image",
        btnAiCreate = "Créer avec l'IA",
        secVideoOptions = "Options Vidéo Pro",
        optStyle = "Style",
        optDuration = "Durée",
        optVoice = "Voix",
        optMusic = "Musique",
        optQuality = "Qualité",
        optRatio = "Format",
        categoriesTitle = "Catégories populaires",
        chooseCategoryHint = "Choisissez un thème",
        readyIdeasPrefix = "Idées prêtes :",
        recentCreationsTitle = "Créations récentes",
        btnConvertPhotoVideo = "Transformer votre photo en vidéo 📸",
        onboardingPhotoTitle = "Générer, Éditer et Animer avec JIMI",
        onboardingPhotoBody = "Générez ou importez une photo, appliquez des filtres, éditez-la par IA et animez-la en vidéo !",
        secPhotoGenAndEdit = "Génération & Édition IA",
        photoGenPromptHint = "Décrivez l'image que JIMI doit créer...",
        btnGeneratePhotoOnly = "Générer l'image IA ✨",
        optImageSize = "Taille",
        optFilter = "Filtre",
        secAiImageEdit = "Édition par IA ✨",
        aiEditPromptHint = "Que voulez-vous que JIMI modifie ?",
        btnApplyAiEdit = "Appliquer l'édition IA",
        step1UploadedPhoto = "Image active",
        changePhoto = "Changer",
        faceDetectedBadge = "✓ Visage, yeux et mâchoire détectés",
        sceneReadyBadge = "✓ Prêt pour l'animation et l'édition",
        step2WhatToDo = "Que doit-il faire dans la vidéo ?",
        step3WhatToSpeak = "Que doit-il dire dans la vidéo ?",
        fillSampleSpeech = "Exemple rapide",
        speakTextHint = "Écrivez le texte à prononcer...",
        btnGenerateVideo = "Générer la vidéo",
        liveVideoBadge = "Vidéo en direct",
        pausedBadge = "En pause",
        generatedImageSubtitle = "Image générée par IA",
        talkingFaceSubtitle = "Animation visage & lèvres",
        cinematicMotionSubtitle = "Mouvement cinématique IA",
        btnPlay = "Lire",
        btnPause = "Pause",
        btnConvertToVideo = "En vidéo",
        btnDownload = "Télécharger",
        btnShare = "Partager",
        retryBtn = "Réessayer",
        emptyPromptError = "Veuillez décrire votre vidéo ou cliquer sur \"Laisser JIMI écrire le texte\".",
        emptyImagePromptError = "Veuillez décrire l'image à générer.",
        emptyPhotoError = "Veuillez d'abord importer ou générer une photo.",
        emptySpeechError = "Veuillez écrire le texte que la photo doit prononcer.",
        emptyAiEditError = "Choisissez une action ou décrivez la modification souhaitée.",
        stepWritingScript = "JIMI rédige un script créatif...",
        stepPreparingScript = "JIMI prépare le scénario...",
        stepGeneratingImage = "JIMI crée l'image fantastique...",
        stepEditingImage = "JIMI modifie la photo par IA...",
        stepAnalyzingFace = "Analyse du visage et préparation vidéo...",
        stepAnalyzingPhoto = "Analyse de votre photo...",
        exportingLabel = "Préparation du fichier...",
        shareReadyLabel = "Prêt à partager !",
        robotTitle = "JIMI - جيمي 🤖",
        robotSubtitle = "Posez vos questions par texte ou micro, ou contrôlez votre téléphone",
        robotStatusReady = "Oui ? Je suis JIMI",
        robotStatusListening = "JIMI vous écoute...",
        robotStatusThinking = "JIMI réfléchit...",
        robotStatusSpeaking = "JIMI parle...",
        robotWelcomeMessage = "Oui ? Je suis JIMI 🤖 ! Posez-moi n'importe quelle question ou dites : JIMI ouvre YouTube, change le fond ou allume le flash !",
        robotInputHint = "Écrivez à JIMI ou utilisez le micro...",
        robotQuickTopicsTitle = "Idées à demander à JIMI :",
        robotQuickTopics = listOf(
            "📚 Cours simple" to "Explique-moi simplement comment fonctionne la photosynthèse",
            "📖 Histoire magique" to "Raconte-moi une courte histoire fantastique inspirante",
            "😂 Blague drôle" to "Raconte-moi une blague amusante",
            "📝 Aide aux devoirs" to "Aide-moi à résoudre une équation du premier degré"
        ),
        robotSpeakAnswerDesc = "Écouter la réponse",
        robotStopSpeakingDesc = "Arrêter la voix",
        robotMicStartDesc = "Parler au micro",
        robotMicStopDesc = "Arrêter le micro",
        robotMicDeniedError = "Autorisez le microphone pour parler à JIMI.",
        robotMicUnavailableError = "La reconnaissance vocale n'est pas disponible sur cet appareil.",
        robotEmptyQuestionError = "Écrivez une question ou utilisez le microphone.",
        settingsTitle = "Paramètres JIMI",
        btnBack = "Retour",
        secBackground = "1) Fond du jour (change à 00:00)",
        autoChangeBgLabel = "Changement auto toutes les 24h (00:00)",
        bgSpeedLabel = "Toutes les 24 heures",
        favoriteBgLabel = "Fond d'écran du jour",
        btnChangeBg = "Aperçu de demain",
        btnUploadCustomBg = "Importer un fond personnalisé 📸",
        customBgActiveLabel = "✓ Fond personnalisé actif",
        secLanguage = "2) Langue",
        secVoice = "3) Voix",
        voiceOnOffLabel = "Voix activée",
        chooseVoiceLabel = "Voix (Homme / Femme / Enfant / Robot)",
        voiceSpeedLabel = "Vitesse vocale",
        secRobot = "4) Personnalité JIMI",
        robotNameLabel = "Nom de l'assistant",
        robotNameHint = "JIMI",
        robotPersonalityLabel = "Style de JIMI",
        secAppearance = "5) Apparence",
        lightModeLabel = "Mode clair",
        darkModeLabel = "Mode sombre",
        settingsSavedAutoNote = "Tous les paramètres JIMI sont sauvegardés",
        secPhoneControl = "6) Contrôle du téléphone & Icône",
        btnOpenWhatsApp = "Ouvrir WhatsApp",
        btnOpenYouTube = "Ouvrir YouTube",
        btnOpenTikTok = "Ouvrir TikTok",
        btnVibrate = "Vibrer",
        btnFlashlightOn = "Allumer Flash",
        btnFlashlightOff = "Éteindre Flash",
        volumeLabel = "Volume",
        btnVolumeDown = "Baisser",
        btnVolumeUp = "Monter",
        btnPinHomeIcon = "Ajouter l'icône JIMI à l'écran d'accueil",
        floatingJimiTitle = "Assistant Flottant JIMI ✨",
        floatingJimiSubtitle = "Dites \"JIMI\" pour le réveiller : Oui ? Je suis JIMI",
        floatingJimiWakeGreeting = "Oui ? Je suis JIMI",
        floatingJimiWakeSwitch = "Écoute du mot-clé \"JIMI / جيمي\"",
        floatingJimiWakeHint = "Dites par ex. \"JIMI ouvre YouTube\" ou \"JIMI allume le flash\"",
        floatingJimiTalkBtn = "Parler à JIMI",
        floatingJimiListeningCmd = "Dites votre commande maintenant...",
        floatingJimiTryCommands = "Commandes rapides à dire ou toucher :",
        floatingJimiSampleCommands = listOf(
            "JIMI ouvre YouTube",
            "JIMI change le fond",
            "JIMI allume le flash",
            "JIMI ouvre WhatsApp",
            "JIMI ouvre TikTok",
            "JIMI vibrer"
        ),
        dailyBgLabel = "Fond du jour",
        btnPreviewTomorrowBg = "Voir fond de demain",
        tomorrowBgTitle = "Aperçu de demain ✨",
        tomorrowBgMidnightNote = "Le fond change automatiquement une fois par jour à 00:00",
        tomorrowBgNextDayBtn = "Jour suivant",
        closeBtn = "Fermer",
        secApiKey = "Clé API Gemini",
        apiKeyTitle = "Entrez votre clé API Gemini",
        apiKeySubtitle = "Toutes les générations IA utilisent uniquement votre clé personnelle Google AI Studio enregistrée localement.",
        apiKeyInputHint = "Collez votre clé Gemini API (AIza...) ici",
        btnGetFreeKey = "Get Free Key",
        btnSaveApiKey = "Enregistrer et continuer",
        btnSkipApiKey = "Plus tard (sans IA)",
        btnChangeApiKey = "Changer la clé API Gemini",
        apiKeySavedStatus = "Clé enregistrée et active",
        apiKeyNotSetStatus = "Aucune clé — génération IA désactivée",
        apiKeyMissingError = "Veuillez entrer votre clé API Gemini pour utiliser la génération IA."
    )

    AppLanguage.ENGLISH, AppLanguage.SPANISH -> LocalizedStrings(
        studioBadge = "JIMI - جيمي",
        studioTagline = "Fantasy AI Assistant",
        freeBadge = "Magic AI",
        heroTitle = "JIMI AI Video Studio",
        heroSubtitle = "Generate videos, AI-edit & animate photos, and control your phone with JIMI",
        tabVideo = "Video",
        tabPhoto = "Photo",
        tabRobot = "JIMI",
        openSettingsDesc = "Settings",
        promptHint = "Write what you want in the video...",
        clearTextDesc = "Clear",
        btnWriteWithJimi = "Let JIMI write my script ✨",
        btnTextToVideo = "Text to Video",
        btnAnimatePhoto = "Animate Photo",
        btnImageGen = "Image Generator",
        btnAiCreate = "Create with AI",
        secVideoOptions = "Pro Video Options",
        optStyle = "Style",
        optDuration = "Duration",
        optVoice = "Voice",
        optMusic = "Music",
        optQuality = "Quality",
        optRatio = "Ratio",
        categoriesTitle = "Popular Categories",
        chooseCategoryHint = "Pick a topic",
        readyIdeasPrefix = "Quick ideas for",
        recentCreationsTitle = "Recent Creations",
        btnConvertPhotoVideo = "Turn Your Photo into Video 📸",
        onboardingPhotoTitle = "Generate, AI-Edit & Animate with JIMI",
        onboardingPhotoBody = "Generate an AI image or upload your photo, apply filters, edit with AI, and animate it speaking!",
        secPhotoGenAndEdit = "AI Image Generation & Editing",
        photoGenPromptHint = "Describe the image JIMI should generate...",
        btnGeneratePhotoOnly = "Generate AI Photo ✨",
        optImageSize = "Size",
        optFilter = "Filter",
        secAiImageEdit = "Edit with AI ✨",
        aiEditPromptHint = "What should JIMI change in the photo?",
        btnApplyAiEdit = "Apply AI Edit",
        step1UploadedPhoto = "Active Photo",
        changePhoto = "Change",
        faceDetectedBadge = "✓ Face, eyes & jaw tracked",
        sceneReadyBadge = "✓ Ready for AI edit & motion",
        step2WhatToDo = "What should they do in the video?",
        step3WhatToSpeak = "What should they say?",
        fillSampleSpeech = "Sample line",
        speakTextHint = "Write the text to speak...",
        btnGenerateVideo = "Generate Video",
        liveVideoBadge = "Live Video",
        pausedBadge = "Paused",
        generatedImageSubtitle = "AI Generated Image",
        talkingFaceSubtitle = "Face & Lip Sync",
        cinematicMotionSubtitle = "Smart Cinematic Motion",
        btnPlay = "Play",
        btnPause = "Pause",
        btnConvertToVideo = "Animate",
        btnDownload = "Download",
        btnShare = "Share",
        retryBtn = "Retry",
        emptyPromptError = "Please describe your video or tap \"Let JIMI write my script\".",
        emptyImagePromptError = "Please enter an image description first.",
        emptyPhotoError = "Please upload or generate a photo first.",
        emptySpeechError = "Please enter the text to speak in the video.",
        emptyAiEditError = "Select an AI edit preset or type what JIMI should change.",
        stepWritingScript = "JIMI is writing a creative script...",
        stepPreparingScript = "JIMI is preparing your script...",
        stepGeneratingImage = "JIMI is creating fantasy artwork...",
        stepEditingImage = "JIMI is editing your photo with AI...",
        stepAnalyzingFace = "Tracking facial landmarks & animating...",
        stepAnalyzingPhoto = "Analyzing photo...",
        exportingLabel = "Exporting media...",
        shareReadyLabel = "Ready to share!",
        robotTitle = "JIMI - جيمي 🤖",
        robotSubtitle = "Ask anything by text or mic, or give JIMI phone commands",
        robotStatusReady = "Yes? I am JIMI",
        robotStatusListening = "JIMI is listening...",
        robotStatusThinking = "JIMI is thinking...",
        robotStatusSpeaking = "JIMI is speaking...",
        robotWelcomeMessage = "Yes? I am JIMI 🤖! Ask me any question or try voice commands like: JIMI open YouTube, change background, or turn on flashlight!",
        robotInputHint = "Ask JIMI or tap the microphone...",
        robotQuickTopicsTitle = "Try asking JIMI about:",
        robotQuickTopics = listOf(
            "📚 Easy Lesson" to "Explain how gravity works in simple words",
            "📖 Fantasy Story" to "Tell me a short magical fantasy story",
            "😂 Funny Joke" to "Tell me a clever, family-friendly joke",
            "📝 Homework Help" to "Show me how to solve a linear equation step by step"
        ),
        robotSpeakAnswerDesc = "Speak answer",
        robotStopSpeakingDesc = "Stop speaking",
        robotMicStartDesc = "Speak with microphone",
        robotMicStopDesc = "Stop microphone",
        robotMicDeniedError = "Please allow microphone permission to talk to JIMI.",
        robotMicUnavailableError = "Speech recognition is unavailable on this device.",
        robotEmptyQuestionError = "Please type a question or speak into the microphone.",
        settingsTitle = "JIMI Settings",
        btnBack = "Back",
        secBackground = "1) Today's Background (24h @ 00:00)",
        autoChangeBgLabel = "Auto-change daily at 00:00",
        bgSpeedLabel = "Updates once every 24 hours",
        favoriteBgLabel = "Today's fantasy background",
        btnChangeBg = "Preview Tomorrow",
        btnUploadCustomBg = "Upload Custom Background 📸",
        customBgActiveLabel = "✓ Custom background active",
        secLanguage = "2) Language",
        secVoice = "3) Voice",
        voiceOnOffLabel = "Voice ON / OFF",
        chooseVoiceLabel = "Voice character",
        voiceSpeedLabel = "Speech speed",
        secRobot = "4) JIMI Personality",
        robotNameLabel = "Assistant name",
        robotNameHint = "JIMI",
        robotPersonalityLabel = "JIMI personality",
        secAppearance = "5) Appearance",
        lightModeLabel = "Light Mode",
        darkModeLabel = "Dark Mode",
        settingsSavedAutoNote = "All JIMI settings are saved automatically",
        secPhoneControl = "6) Phone Control & Home Icon",
        btnOpenWhatsApp = "Open WhatsApp",
        btnOpenYouTube = "Open YouTube",
        btnOpenTikTok = "Open TikTok",
        btnVibrate = "Vibrate",
        btnFlashlightOn = "Flash ON",
        btnFlashlightOff = "Flash OFF",
        volumeLabel = "Media Volume",
        btnVolumeDown = "Vol -",
        btnVolumeUp = "Vol +",
        btnPinHomeIcon = "Add JIMI Icon to Home Screen",
        floatingJimiTitle = "Floating JIMI Assistant ✨",
        floatingJimiSubtitle = "Say \"JIMI\" / \"جيمي\" to wake up: Yes? I am JIMI",
        floatingJimiWakeGreeting = "نعم؟ أنا JIMI",
        floatingJimiWakeSwitch = "Wake word listening (\"JIMI / جيمي\")",
        floatingJimiWakeHint = "Try saying \"JIMI open YouTube\" or \"JIMI turn on flashlight\"",
        floatingJimiTalkBtn = "Talk to JIMI now",
        floatingJimiListeningCmd = "Speak your command now...",
        floatingJimiTryCommands = "Quick commands to speak or tap:",
        floatingJimiSampleCommands = listOf(
            "JIMI open YouTube",
            "JIMI change background",
            "JIMI turn on flashlight",
            "JIMI open WhatsApp",
            "JIMI open TikTok",
            "JIMI vibrate"
        ),
        dailyBgLabel = "Today's Background",
        btnPreviewTomorrowBg = "Preview Tomorrow",
        tomorrowBgTitle = "Tomorrow's Backgrounds ✨",
        tomorrowBgMidnightNote = "Background updates automatically once every 24h at 00:00",
        tomorrowBgNextDayBtn = "Next Day",
        closeBtn = "Close",
        secApiKey = "Gemini API Key",
        apiKeyTitle = "Enter Your Gemini API Key",
        apiKeySubtitle = "All AI generation uses only your own Google AI Studio key, saved locally on your device.",
        apiKeyInputHint = "Paste your Gemini API key (AIza...) here",
        btnGetFreeKey = "Get Free Key",
        btnSaveApiKey = "Save Key & Continue",
        btnSkipApiKey = "Later (No AI)",
        btnChangeApiKey = "Change Gemini API Key",
        apiKeySavedStatus = "API Key saved & active",
        apiKeyNotSetStatus = "No API key — AI generation disabled",
        apiKeyMissingError = "Please enter your Gemini API Key first to generate with AI."
    )
}

fun FantasyBackground.localizedName(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        FantasyBackground.MAGICAL_CASTLE -> "قصر سحري"
        FantasyBackground.NEON_CITY -> "مدينة نيون"
        FantasyBackground.GALAXY -> "المجرة"
        FantasyBackground.OCEAN_DREAM -> "حلم المحيط"
        FantasyBackground.FOREST_MAGIC -> "غابة سحرية"
        FantasyBackground.DESERT_SUNSET -> "غروب الصحراء"
        FantasyBackground.ANIME_WORLD -> "عالم الأنمي"
        FantasyBackground.CYBERPUNK -> "سايبربانك"
        FantasyBackground.CLOUD_KINGDOM -> "مملكة السحاب"
        FantasyBackground.FIRE_DRAGON -> "تنين النار"
    }
    AppLanguage.FRENCH -> when (this) {
        FantasyBackground.MAGICAL_CASTLE -> "Château"
        FantasyBackground.NEON_CITY -> "Néon Ville"
        FantasyBackground.GALAXY -> "Galaxie"
        FantasyBackground.OCEAN_DREAM -> "Océan"
        FantasyBackground.FOREST_MAGIC -> "Forêt"
        FantasyBackground.DESERT_SUNSET -> "Désert"
        FantasyBackground.ANIME_WORLD -> "Anime"
        FantasyBackground.CYBERPUNK -> "Cyberpunk"
        FantasyBackground.CLOUD_KINGDOM -> "Nuages"
        FantasyBackground.FIRE_DRAGON -> "Dragon"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        FantasyBackground.MAGICAL_CASTLE -> "Castle"
        FantasyBackground.NEON_CITY -> "Neon City"
        FantasyBackground.GALAXY -> "Galaxy"
        FantasyBackground.OCEAN_DREAM -> "Ocean"
        FantasyBackground.FOREST_MAGIC -> "Forest"
        FantasyBackground.DESERT_SUNSET -> "Desert"
        FantasyBackground.ANIME_WORLD -> "Anime"
        FantasyBackground.CYBERPUNK -> "Cyberpunk"
        FantasyBackground.CLOUD_KINGDOM -> "Clouds"
        FantasyBackground.FIRE_DRAGON -> "Dragon"
    }
}

fun BgChangeSpeed.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        BgChangeSpeed.FAST_5S -> "5 ثواني"
        BgChangeSpeed.AUTO_8S -> "8 ثواني"
        BgChangeSpeed.MEDIUM_15S -> "15 ثانية"
        BgChangeSpeed.SLOW_30S -> "30 ثانية"
    }
    AppLanguage.FRENCH, AppLanguage.ENGLISH, AppLanguage.SPANISH -> "${seconds}s"
}

fun VoiceType.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA -> when (this) {
        VoiceType.MALE -> "رجل"
        VoiceType.FEMALE -> "مرا"
        VoiceType.CHILD -> "طفل"
        VoiceType.ROBOT -> "روبوت"
    }
    AppLanguage.ARABIC -> when (this) {
        VoiceType.MALE -> "رجل"
        VoiceType.FEMALE -> "امرأة"
        VoiceType.CHILD -> "طفل"
        VoiceType.ROBOT -> "روبوت"
    }
    AppLanguage.FRENCH -> when (this) {
        VoiceType.MALE -> "Homme"
        VoiceType.FEMALE -> "Femme"
        VoiceType.CHILD -> "Enfant"
        VoiceType.ROBOT -> "Robot"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        VoiceType.MALE -> "Man"
        VoiceType.FEMALE -> "Woman"
        VoiceType.CHILD -> "Child"
        VoiceType.ROBOT -> "Robot"
    }
}

fun VoiceSpeedOption.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        VoiceSpeedOption.SLOW -> "بطيء"
        VoiceSpeedOption.NORMAL -> "عادي"
        VoiceSpeedOption.FAST -> "سريع"
    }
    AppLanguage.FRENCH -> when (this) {
        VoiceSpeedOption.SLOW -> "Lent"
        VoiceSpeedOption.NORMAL -> "Normal"
        VoiceSpeedOption.FAST -> "Rapide"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        VoiceSpeedOption.SLOW -> "Slow"
        VoiceSpeedOption.NORMAL -> "Normal"
        VoiceSpeedOption.FAST -> "Fast"
    }
}

fun VideoArtStyle.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        VideoArtStyle.REALISTIC -> "واقعي"
        VideoArtStyle.CARTOON -> "كرتون"
        VideoArtStyle.ANIME -> "أنمي"
        VideoArtStyle.FANTASY -> "خيالي"
        VideoArtStyle.THREE_D -> "3D"
        VideoArtStyle.CINEMATIC -> "سينمائي"
        VideoArtStyle.HORROR -> "رعب"
        VideoArtStyle.COMEDY -> "كوميدي"
    }
    AppLanguage.FRENCH -> when (this) {
        VideoArtStyle.REALISTIC -> "Réaliste"
        VideoArtStyle.CARTOON -> "Cartoon"
        VideoArtStyle.ANIME -> "Anime"
        VideoArtStyle.FANTASY -> "Fantaisie"
        VideoArtStyle.THREE_D -> "3D"
        VideoArtStyle.CINEMATIC -> "Cinéma"
        VideoArtStyle.HORROR -> "Horreur"
        VideoArtStyle.COMEDY -> "Comédie"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        VideoArtStyle.REALISTIC -> "Realistic"
        VideoArtStyle.CARTOON -> "Cartoon"
        VideoArtStyle.ANIME -> "Anime"
        VideoArtStyle.FANTASY -> "Fantasy"
        VideoArtStyle.THREE_D -> "3D"
        VideoArtStyle.CINEMATIC -> "Cinematic"
        VideoArtStyle.HORROR -> "Horror"
        VideoArtStyle.COMEDY -> "Comedy"
    }
}

fun BackgroundMusicMode.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        BackgroundMusicMode.NONE -> "بدون"
        BackgroundMusicMode.ENERGETIC -> "حماسي"
        BackgroundMusicMode.CALM -> "هادئ"
        BackgroundMusicMode.FUNNY -> "مضحك"
    }
    AppLanguage.FRENCH -> when (this) {
        BackgroundMusicMode.NONE -> "Aucune"
        BackgroundMusicMode.ENERGETIC -> "Énergique"
        BackgroundMusicMode.CALM -> "Calme"
        BackgroundMusicMode.FUNNY -> "Drôle"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        BackgroundMusicMode.NONE -> "None"
        BackgroundMusicMode.ENERGETIC -> "Hype"
        BackgroundMusicMode.CALM -> "Calm"
        BackgroundMusicMode.FUNNY -> "Funny"
    }
}

fun VideoQuality.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        VideoQuality.STANDARD -> "عادي"
        VideoQuality.HD -> "HD"
    }
    AppLanguage.FRENCH, AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        VideoQuality.STANDARD -> "Standard"
        VideoQuality.HD -> "HD"
    }
}

fun VideoAspectRatio.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        VideoAspectRatio.VERTICAL_9_16 -> "عمودي TikTok"
        VideoAspectRatio.SQUARE_1_1 -> "مربع"
        VideoAspectRatio.HORIZONTAL_16_9 -> "أفقي YouTube"
    }
    AppLanguage.FRENCH -> when (this) {
        VideoAspectRatio.VERTICAL_9_16 -> "Vertical TikTok"
        VideoAspectRatio.SQUARE_1_1 -> "Carré"
        VideoAspectRatio.HORIZONTAL_16_9 -> "Horizontal YouTube"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        VideoAspectRatio.VERTICAL_9_16 -> "Vertical TikTok"
        VideoAspectRatio.SQUARE_1_1 -> "Square"
        VideoAspectRatio.HORIZONTAL_16_9 -> "Wide YouTube"
    }
}

fun ImageSizeOption.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        ImageSizeOption.SQUARE -> "مربع"
        ImageSizeOption.STORY -> "ستوري"
        ImageSizeOption.COVER -> "غلاف"
    }
    AppLanguage.FRENCH -> when (this) {
        ImageSizeOption.SQUARE -> "Carré"
        ImageSizeOption.STORY -> "Story"
        ImageSizeOption.COVER -> "Couverture"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        ImageSizeOption.SQUARE -> "Square"
        ImageSizeOption.STORY -> "Story"
        ImageSizeOption.COVER -> "Cover"
    }
}

fun ImageFilterType.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        ImageFilterType.NONE -> "عادي"
        ImageFilterType.NEON -> "نيون"
        ImageFilterType.MAGICAL -> "سحري"
        ImageFilterType.BW -> "أبيض وأسود"
        ImageFilterType.VIVID -> "ملون"
        ImageFilterType.VINTAGE -> "قديم"
    }
    AppLanguage.FRENCH -> when (this) {
        ImageFilterType.NONE -> "Normal"
        ImageFilterType.NEON -> "Néon"
        ImageFilterType.MAGICAL -> "Magique"
        ImageFilterType.BW -> "N&B"
        ImageFilterType.VIVID -> "Vif"
        ImageFilterType.VINTAGE -> "Rétro"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        ImageFilterType.NONE -> "Normal"
        ImageFilterType.NEON -> "Neon"
        ImageFilterType.MAGICAL -> "Magical"
        ImageFilterType.BW -> "B&W"
        ImageFilterType.VIVID -> "Vivid"
        ImageFilterType.VINTAGE -> "Vintage"
    }
}

fun AiImageEditAction.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        AiImageEditAction.REMOVE_BG -> "حيد الخلفية"
        AiImageEditAction.CHANGE_BG -> "بدل الخلفية"
        AiImageEditAction.ENHANCE_QUALITY -> "حسن الجودة"
        AiImageEditAction.TO_CARTOON -> "حول لكرتون"
        AiImageEditAction.TO_ANIME -> "حول لأنمي"
        AiImageEditAction.ADD_LIGHTING -> "زيد إضاءة"
        AiImageEditAction.REMOVE_PERSON -> "حيد شخص"
        AiImageEditAction.UPSCALE_EXPAND -> "كبر الصورة"
    }
    AppLanguage.FRENCH -> when (this) {
        AiImageEditAction.REMOVE_BG -> "Retirer fond"
        AiImageEditAction.CHANGE_BG -> "Changer fond"
        AiImageEditAction.ENHANCE_QUALITY -> "Qualité HD"
        AiImageEditAction.TO_CARTOON -> "En Cartoon"
        AiImageEditAction.TO_ANIME -> "En Anime"
        AiImageEditAction.ADD_LIGHTING -> "+ Lumière"
        AiImageEditAction.REMOVE_PERSON -> "Retirer perso"
        AiImageEditAction.UPSCALE_EXPAND -> "Agrandir"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        AiImageEditAction.REMOVE_BG -> "Remove BG"
        AiImageEditAction.CHANGE_BG -> "Change BG"
        AiImageEditAction.ENHANCE_QUALITY -> "Enhance HD"
        AiImageEditAction.TO_CARTOON -> "To Cartoon"
        AiImageEditAction.TO_ANIME -> "To Anime"
        AiImageEditAction.ADD_LIGHTING -> "Add Light"
        AiImageEditAction.REMOVE_PERSON -> "Remove Person"
        AiImageEditAction.UPSCALE_EXPAND -> "Upscale"
    }
}

fun RobotPersonality.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> when (this) {
        RobotPersonality.FUNNY -> "مضحك"
        RobotPersonality.SERIOUS -> "جدي"
        RobotPersonality.TEACHER -> "أستاذ"
        RobotPersonality.FRIEND -> "صديق"
    }
    AppLanguage.FRENCH -> when (this) {
        RobotPersonality.FUNNY -> "Drôle"
        RobotPersonality.SERIOUS -> "Sérieux"
        RobotPersonality.TEACHER -> "Professeur"
        RobotPersonality.FRIEND -> "Ami"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        RobotPersonality.FUNNY -> "Funny"
        RobotPersonality.SERIOUS -> "Serious"
        RobotPersonality.TEACHER -> "Teacher"
        RobotPersonality.FRIEND -> "Friend"
    }
}

fun PhotoAction.localizedLabel(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA -> labelAr
    AppLanguage.ARABIC -> when (this) {
        PhotoAction.SPEAK -> "يتحدث"
        PhotoAction.SING -> "يغني"
        PhotoAction.SMILE -> "يبتسم"
        PhotoAction.MOVE_HEAD -> "يحرك رأسه"
        PhotoAction.CRY -> "يبكي"
        PhotoAction.LAUGH -> "يضحك"
    }
    AppLanguage.FRENCH -> when (this) {
        PhotoAction.SPEAK -> "Parler"
        PhotoAction.SING -> "Chanter"
        PhotoAction.SMILE -> "Sourire"
        PhotoAction.MOVE_HEAD -> "Bouger tête"
        PhotoAction.CRY -> "Pleurer"
        PhotoAction.LAUGH -> "Rire"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        PhotoAction.SPEAK -> "Talk"
        PhotoAction.SING -> "Sing"
        PhotoAction.SMILE -> "Smile"
        PhotoAction.MOVE_HEAD -> "Move Head"
        PhotoAction.CRY -> "Cry"
        PhotoAction.LAUGH -> "Laugh"
    }
}

fun PhotoAction.localizedSampleSpeech(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA -> sampleSpeechDarija
    AppLanguage.ARABIC -> when (this) {
        PhotoAction.SPEAK -> "السلام عليكم! أنا جيمي، أهلاً بكم في هذا الفيديو الجديد بالذكاء الاصطناعي."
        PhotoAction.SING -> "ما أجمل هذا اليوم المشرق، لنغنِّ معاً بفرح وأمل!"
        PhotoAction.SMILE -> "ابتسامتك تزيد العالم جمالاً، أتمنى لك يوماً سعيداً!"
        PhotoAction.MOVE_HEAD -> "شاهد كيف تتحول هذه الصورة إلى حياة وحركة طبيعية!"
        PhotoAction.CRY -> "لقد تأثرت كثيراً بهذه اللحظة، لكن الأمل يظل مشرقاً دائماً."
        PhotoAction.LAUGH -> "هههه! يا لها من فكرة رائعة ومبهجة مع جيمي!"
    }
    AppLanguage.FRENCH -> when (this) {
        PhotoAction.SPEAK -> "Bonjour ! Je suis JIMI, bienvenue dans cette nouvelle vidéo créée avec l'IA."
        PhotoAction.SING -> "La vie est belle aujourd'hui, chantons ensemble avec joie et énergie !"
        PhotoAction.SMILE -> "Votre sourire illumine la journée, je vous souhaite plein de bonheur !"
        PhotoAction.MOVE_HEAD -> "Regardez comme cette photo prend vie naturellement avec JIMI !"
        PhotoAction.CRY -> "Ce moment est vraiment émouvant, mais gardons toujours espoir pour demain."
        PhotoAction.LAUGH -> "Hahaha ! Cette idée est vraiment géniale et tellement drôle !"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        PhotoAction.SPEAK -> "Hello everyone! I am JIMI, welcome to this amazing video brought to life with AI."
        PhotoAction.SING -> "What a wonderful bright day, let us sing together with joy and rhythm!"
        PhotoAction.SMILE -> "A warm smile makes every day brighter, wishing you happiness!"
        PhotoAction.MOVE_HEAD -> "Look how smoothly this photo moves and comes alive with JIMI!"
        PhotoAction.CRY -> "That moment touched my heart deeply, yet hope always shines ahead."
        PhotoAction.LAUGH -> "Hahaha! That is honestly the funniest and coolest thing ever!"
    }
}

fun VideoCategory.localizedTitle(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA, AppLanguage.ARABIC -> titleAr
    AppLanguage.FRENCH -> when (this) {
        VideoCategory.STORIES -> "Histoires"
        VideoCategory.EDUCATION -> "Éducation"
        VideoCategory.SONGS -> "Chansons"
        VideoCategory.ADS -> "Publicités"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        VideoCategory.STORIES -> "Stories"
        VideoCategory.EDUCATION -> "Education"
        VideoCategory.SONGS -> "Songs"
        VideoCategory.ADS -> "Ads"
    }
}

fun VideoCategory.localizedSubtitle(language: AppLanguage): String = when (language) {
    AppLanguage.DARIJA -> subtitleDarija
    AppLanguage.ARABIC -> when (this) {
        VideoCategory.STORIES -> "حكايات مشوقة ومصورة"
        VideoCategory.EDUCATION -> "شروحات واضحة وممتعة"
        VideoCategory.SONGS -> "كلمات وإيقاعات عصرية"
        VideoCategory.ADS -> "إعلانات احترافية للمنتجات"
    }
    AppLanguage.FRENCH -> when (this) {
        VideoCategory.STORIES -> "Récits captivants"
        VideoCategory.EDUCATION -> "Explications simples"
        VideoCategory.SONGS -> "Rythmes et paroles"
        VideoCategory.ADS -> "Promos de produits"
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        VideoCategory.STORIES -> "Visual magical tales"
        VideoCategory.EDUCATION -> "Easy explanations"
        VideoCategory.SONGS -> "Lyrics & beats"
        VideoCategory.ADS -> "Product promos"
    }
}

fun VideoCategory.localizedSamples(language: AppLanguage): List<String> = when (language) {
    AppLanguage.DARIJA -> samplePrompts
    AppLanguage.ARABIC -> when (this) {
        VideoCategory.STORIES -> listOf(
            "حكيم في الصحراء يروي قصة الكنز المفقود تحت ضوء النجوم",
            "قصة قصيرة عن الصداقة والوفاء في قرية جبلية جميلة"
        )
        VideoCategory.EDUCATION -> listOf(
            "أستاذ يشرح كيف يعمل الذكاء الاصطناعي بطريقة بسيطة وسهلة",
            "معلومات شيقة عن الكواكب والفضاء للطلاب"
        )
        VideoCategory.SONGS -> listOf(
            "مغني في استوديو بإضاءة زرقاء يغني أغنية حماسية عن النجاح",
            "أغنية صباحية مبهجة عن الأمل والانطلاقة الجديدة"
        )
        VideoCategory.ADS -> listOf(
            "إعلان احترافي لعطر فاخر برائحة العود والعنبر",
            "إعلان جذاب لمتجر هواتف ذكية بعروض مميزة"
        )
    }
    AppLanguage.FRENCH -> when (this) {
        VideoCategory.STORIES -> listOf(
            "Un sage conteur dans le désert marocain sous les étoiles et les lanternes dorées",
            "Une courte histoire touchante sur l'amitié dans un village de montagne"
        )
        VideoCategory.EDUCATION -> listOf(
            "Un professeur explique comment fonctionne l'intelligence artificielle de façon simple",
            "Faits fascinants sur les planètes et le système solaire pour les élèves"
        )
        VideoCategory.SONGS -> listOf(
            "Un chanteur dans un studio bleu néon interprète une chanson motivante sur la réussite",
            "Douce chanson matinale sur la joie et les nouveaux départs"
        )
        VideoCategory.ADS -> listOf(
            "Publicité élégante pour un parfum de luxe à l'ambre et à l'argan",
            "Annonce dynamique pour une nouvelle boutique de smartphones"
        )
    }
    AppLanguage.ENGLISH, AppLanguage.SPANISH -> when (this) {
        VideoCategory.STORIES -> listOf(
            "A wise storyteller in a glowing desert night telling the tale of a hidden treasure",
            "A heartwarming short story about friendship in a peaceful mountain village"
        )
        VideoCategory.EDUCATION -> listOf(
            "A friendly teacher explaining how artificial intelligence works in simple terms",
            "Amazing facts about space and planets for curious students"
        )
        VideoCategory.SONGS -> listOf(
            "A singer in a vibrant blue studio performing an upbeat song about chasing dreams",
            "A cheerful morning song celebrating sunshine and hope"
        )
        VideoCategory.ADS -> listOf(
            "A sleek luxury commercial for an artisan amber and argan perfume",
            "An energetic short promo video for a modern smartphone launch"
        )
    }
}
