package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Frosted glassmorphism container styled for fantasy backgrounds.
 */
@Composable
fun GlassmorphicCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    isDarkMode: Boolean = false,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    elevation: Dp = 4.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val bgBrush = if (isDarkMode) {
        Brush.verticalGradient(
            listOf(
                Color(0xFF171E3E).copy(alpha = 0.78f),
                Color(0xFF0E142C).copy(alpha = 0.70f)
            )
        )
    } else {
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.84f),
                Color(0xFFF5F3FF).copy(alpha = 0.72f)
            )
        )
    }

    val borderBrush = if (isDarkMode) {
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.28f),
                accentColor.copy(alpha = 0.35f),
                Color.White.copy(alpha = 0.12f)
            )
        )
    } else {
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.92f),
                accentColor.copy(alpha = 0.28f),
                Color.White.copy(alpha = 0.55f)
            )
        )
    }

    Card(
        modifier = modifier
            .clip(shape)
            .border(BorderStroke(1.2.dp, borderBrush), shape),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = elevation)
    ) {
        Box(
            modifier = Modifier.background(bgBrush)
        ) {
            Column(content = content)
        }
    }
}
