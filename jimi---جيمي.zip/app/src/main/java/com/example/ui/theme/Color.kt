package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Play Store inspired bright, clean white & royal blue palette
val PlayBluePrimary = Color(0xFF1A73E8)
val PlayBlueDark = Color(0xFF1557B0)
val PlayBlueContainer = Color(0xFFE8F0FE)
val PlayOnBlueContainer = Color(0xFF0D3C78)

val PlayTealAccent = Color(0xFF01875F)
val PlayTealContainer = Color(0xFFE6F4EA)
val PlayOnTealContainer = Color(0xFF0D4E35)

val PlayAmberAccent = Color(0xFFF9AB00)
val PlayAmberContainer = Color(0xFFFEF7E0)

val SurfacePureWhite = Color(0xFFFFFFFF)
val BackgroundCrisp = Color(0xFFF8FAFD)
val SurfaceCardAlt = Color(0xFFF1F5F9)
val OutlineSubtle = Color(0xFFE2E8F0)
val OutlineFocused = Color(0xFF1A73E8)

val TextPrimaryDark = Color(0xFF111827)
val TextSecondarySlate = Color(0xFF4B5563)
val TextMutedGrey = Color(0xFF6B7280)

val ErrorRed = Color(0xFFD93025)
val ErrorContainerLight = Color(0xFFFCE8E6)
