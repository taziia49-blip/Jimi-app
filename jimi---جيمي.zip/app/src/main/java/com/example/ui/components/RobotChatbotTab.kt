package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.absolutePadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.media.SpeechUiState
import com.example.media.VoiceInputState
import com.example.ui.i18n.LocalizedStrings
import com.example.ui.model.ChatMessage
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun RobotAvatarHeaderCard(
    strings: LocalizedStrings,
    robotName: String,
    personalityLabel: String,
    isSpeaking: Boolean,
    isThinking: Boolean,
    isListening: Boolean,
    isDarkMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    var animTime by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var lastNanos = 0L
        while (true) {
            withFrameNanos { nanos ->
                if (lastNanos != 0L) {
                    animTime += ((nanos - lastNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
                }
                lastNanos = nanos
            }
        }
    }

    val statusText = when {
        isListening -> strings.robotStatusListening
        isThinking -> strings.robotStatusThinking
        isSpeaking -> strings.robotStatusSpeaking
        else -> strings.robotStatusReady
    }

    val statusColor = when {
        isListening -> Color(0xFF01875F)
        isThinking -> Color(0xFFF9AB00)
        isSpeaking -> MaterialTheme.colorScheme.primary
        else -> Color(0xFF34A853)
    }

    GlassmorphicCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        isDarkMode = isDarkMode,
        elevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Animated Talking Robot Avatar
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF0F172A), Color(0xFF1E3A8A))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val bobY = sin(animTime * if (isSpeaking) 6.5f else 2.4f) * (h * 0.028f)
                    val tiltDeg = if (isSpeaking) sin(animTime * 3.8f) * 3.2f else sin(animTime * 1.3f) * 1.4f

                    rotate(degrees = tiltDeg, pivot = Offset(w / 2f, h / 2f + bobY)) {
                        // Antenna stem
                        drawLine(
                            color = Color(0xFF93C5FD),
                            start = Offset(w * 0.5f, h * 0.16f + bobY),
                            end = Offset(w * 0.5f, h * 0.27f + bobY),
                            strokeWidth = w * 0.04f
                        )
                        // Glowing antenna bulb
                        val bulbPulse = 0.7f + 0.3f * sin(animTime * if (isThinking || isSpeaking) 10f else 3f)
                        val bulbColor = when {
                            isListening -> Color(0xFF34D399)
                            isThinking -> Color(0xFFFBBF24)
                            else -> Color(0xFF38BDF8)
                        }
                        drawCircle(
                            color = bulbColor.copy(alpha = bulbPulse),
                            radius = w * 0.065f,
                            center = Offset(w * 0.5f, h * 0.14f + bobY)
                        )

                        // Ear pods
                        drawRoundRect(
                            color = Color(0xFF3B82F6),
                            topLeft = Offset(w * 0.11f, h * 0.43f + bobY),
                            size = Size(w * 0.08f, h * 0.20f),
                            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
                        )
                        drawRoundRect(
                            color = Color(0xFF3B82F6),
                            topLeft = Offset(w * 0.81f, h * 0.43f + bobY),
                            size = Size(w * 0.08f, h * 0.20f),
                            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
                        )

                        // Robot head outer shell
                        drawRoundRect(
                            color = Color(0xFFEFF6FF),
                            topLeft = Offset(w * 0.17f, h * 0.27f + bobY),
                            size = Size(w * 0.66f, h * 0.56f),
                            cornerRadius = CornerRadius(w * 0.16f, w * 0.16f)
                        )

                        // Dark visor screen
                        drawRoundRect(
                            color = Color(0xFF0F172A),
                            topLeft = Offset(w * 0.23f, h * 0.34f + bobY),
                            size = Size(w * 0.54f, h * 0.31f),
                            cornerRadius = CornerRadius(w * 0.10f, w * 0.10f)
                        )

                        // Blinking LED eyes
                        val blinkPhase = animTime % 3.0f
                        val eyeScaleY = if (blinkPhase in 2.75f..2.93f) {
                            1f - sin(((blinkPhase - 2.75f) / 0.18f) * PI).toFloat().coerceIn(0f, 0.88f)
                        } else 1f
                        val eyeColor = if (isListening) Color(0xFF34D399) else Color(0xFF38BDF8)
                        val eyeW = w * 0.11f
                        val eyeH = (h * 0.11f) * eyeScaleY
                        val eyeY = h * 0.495f + bobY - eyeH / 2f

                        drawRoundRect(
                            color = eyeColor,
                            topLeft = Offset(w * 0.32f, eyeY),
                            size = Size(eyeW, eyeH),
                            cornerRadius = CornerRadius(eyeW * 0.45f, eyeW * 0.45f)
                        )
                        drawRoundRect(
                            color = eyeColor,
                            topLeft = Offset(w * 0.57f, eyeY),
                            size = Size(eyeW, eyeH),
                            cornerRadius = CornerRadius(eyeW * 0.45f, eyeW * 0.45f)
                        )

                        // Talking Jaw / Soundwave Mouth Panel
                        val mouthCenterY = h * 0.735f + bobY
                        if (isSpeaking) {
                            for (bar in 0 until 5) {
                                val amp = 0.35f + 0.65f * abs(sin(animTime * 11.5f + bar * 1.1f))
                                val barH = h * 0.085f * amp
                                val barX = w * (0.34f + bar * 0.072f)
                                drawRoundRect(
                                    color = Color(0xFF1A73E8),
                                    topLeft = Offset(barX, mouthCenterY - barH / 2f),
                                    size = Size(w * 0.045f, barH),
                                    cornerRadius = CornerRadius(w * 0.02f, w * 0.02f)
                                )
                            }
                        } else {
                            // Friendly smiling LED line
                            drawRoundRect(
                                color = Color(0xFF1A73E8),
                                topLeft = Offset(w * 0.36f, mouthCenterY - h * 0.018f),
                                size = Size(w * 0.28f, h * 0.036f),
                                cornerRadius = CornerRadius(w * 0.02f, w * 0.02f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = robotName.ifBlank { strings.robotTitle },
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = strings.robotSubtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        color = statusColor.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(999.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(statusColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.labelMedium,
                                color = statusColor
                            )
                        }
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(999.dp)
                    ) {
                        Text(
                            text = personalityLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RobotQuickTopicsRow(
    strings: LocalizedStrings,
    onSelectTopicPrompt: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = strings.robotQuickTopicsTitle,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(strings.robotQuickTopics) { (chipLabel, prompt) ->
                SuggestionChip(
                    onClick = { onSelectTopicPrompt(prompt) },
                    label = {
                        Text(
                            text = chipLabel,
                            style = MaterialTheme.typography.labelMedium
                        )
                    },
                    shape = RoundedCornerShape(999.dp),
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        labelColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                )
            }
        }
    }
}

@Composable
fun RobotChatMessageBubble(
    message: ChatMessage,
    robotName: String,
    speechState: SpeechUiState,
    strings: LocalizedStrings,
    onSpeakMessage: (ChatMessage) -> Unit,
    onStopSpeech: () -> Unit,
    isDarkMode: Boolean = false
) {
    val isThisMessageSpeaking = speechState.isSpeaking && speechState.speakingTag == message.id

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isFromUser) Arrangement.End else Arrangement.Start
    ) {
        if (message.isFromUser) {
            Surface(
                color = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 4.dp),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth(0.84f)
                    .testTag("user_chat_bubble_${message.id}")
            ) {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        } else {
            GlassmorphicCard(
                shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomEnd = 18.dp, bottomStart = 4.dp),
                isDarkMode = isDarkMode,
                accentColor = if (isThisMessageSpeaking) MaterialTheme.colorScheme.primary else Color(0xFF8B5CF6),
                elevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .testTag("robot_chat_bubble_${message.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = CircleShape,
                                modifier = Modifier.size(26.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.SmartToy,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = robotName.ifBlank { "Robot AI" },
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Small speaker button on every Robot answer
                        if (!message.isStreaming && message.text.isNotBlank()) {
                            Surface(
                                color = if (isThisMessageSpeaking) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.primaryContainer,
                                shape = CircleShape,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .clickable {
                                        if (isThisMessageSpeaking) onStopSpeech()
                                        else onSpeakMessage(message)
                                    }
                                    .testTag("robot_speaker_btn_${message.id}")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (isThisMessageSpeaking) Icons.Default.Stop
                                        else Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = if (isThisMessageSpeaking) strings.robotStopSpeakingDesc
                                        else strings.robotSpeakAnswerDesc,
                                        tint = if (isThisMessageSpeaking) Color.White
                                        else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (message.text.isBlank() && message.isStreaming) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = strings.robotStatusThinking,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RobotInputCard(
    inputText: String,
    isThinking: Boolean,
    voiceInputState: VoiceInputState,
    strings: LocalizedStrings,
    onInputChange: (String) -> Unit,
    onSendText: () -> Unit,
    onStartVoiceMic: () -> Unit,
    onStopVoiceMic: () -> Unit,
    onMicPermissionDenied: () -> Unit,
    isDarkMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onStartVoiceMic()
        } else {
            onMicPermissionDenied()
        }
    }

    GlassmorphicCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        isDarkMode = isDarkMode,
        elevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            if (voiceInputState.isListening) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .absolutePadding(right = 64.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = voiceInputState.partialText.ifBlank { strings.robotStatusListening },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            if (!voiceInputState.errorMessage.isNullOrBlank()) {
                Text(
                    text = voiceInputState.errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Start,
                    modifier = Modifier.padding(bottom = 6.dp, start = 4.dp, end = 4.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Voice Microphone Button
                FilledIconButton(
                    onClick = {
                        if (voiceInputState.isListening) {
                            onStopVoiceMic()
                        } else {
                            val hasPerm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPerm) {
                                onStartVoiceMic()
                            } else {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    enabled = !isThinking,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (voiceInputState.isListening) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.primaryContainer,
                        contentColor = if (voiceInputState.isListening) Color.White
                        else MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("robot_mic_button")
                ) {
                    Icon(
                        imageVector = if (voiceInputState.isListening) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = if (voiceInputState.isListening) strings.robotMicStopDesc
                        else strings.robotMicStartDesc
                    )
                }

                // Typing Box
                OutlinedTextField(
                    value = inputText,
                    onValueChange = onInputChange,
                    placeholder = {
                        Text(
                            text = strings.robotInputHint,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    maxLines = 3,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { if (!isThinking) onSendText() }),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.background,
                        unfocusedContainerColor = MaterialTheme.colorScheme.background,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("robot_input_field")
                )

                // Send Button
                FilledIconButton(
                    onClick = onSendText,
                    enabled = !isThinking && inputText.isNotBlank(),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("robot_send_button")
                ) {
                    if (isThinking) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send"
                        )
                    }
                }
            }
        }
    }
}
