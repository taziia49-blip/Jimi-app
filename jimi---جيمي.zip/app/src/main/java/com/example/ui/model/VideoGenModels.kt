package com.example.ui.model

import android.graphics.Bitmap
import android.graphics.ColorMatrix
import androidx.annotation.DrawableRes
import com.example.R

enum class AppTab {
    VIDEO,
    IMAGE_TO_VIDEO,
    ROBOT
}

data class ChatMessage(
    val id: String,
    val text: String,
    val isFromUser: Boolean,
    val isStreaming: Boolean = false
)

enum class VideoArtStyle(
    val promptEnglish: String,
    val emoji: String,
    @DrawableRes val previewImageRes: Int
) {
    REALISTIC(
        promptEnglish = "photorealistic 8k DSLR photography, lifelike textures, natural lighting",
        emoji = "📷",
        previewImageRes = R.drawable.img_style_realistic
    ),
    CARTOON(
        promptEnglish = "colorful 2D/3D stylized cartoon animation, expressive characters, vibrant palette",
        emoji = "🎨",
        previewImageRes = R.drawable.img_style_cartoon
    ),
    ANIME(
        promptEnglish = "high-detail Japanese anime art style, glowing atmospheric sky, crisp cel shading",
        emoji = "🌸",
        previewImageRes = R.drawable.img_style_anime
    ),
    FANTASY(
        promptEnglish = "epic magical fantasy illustration, enchanted aura, ethereal glow, mystical details",
        emoji = "✨",
        previewImageRes = R.drawable.img_bg_castle
    ),
    THREE_D(
        promptEnglish = "Pixar/Unreal Engine 5 3D CGI render, soft subsurface scattering, studio lighting",
        emoji = "🧊",
        previewImageRes = R.drawable.img_style_3d
    ),
    CINEMATIC(
        promptEnglish = "cinematic film still, dramatic anamorphic lens flare, rich color grading",
        emoji = "🎬",
        previewImageRes = R.drawable.img_style_cinematic
    ),
    HORROR(
        promptEnglish = "spooky atmospheric dark gothic horror style, mysterious fog, eerie dramatic shadows",
        emoji = "👻",
        previewImageRes = R.drawable.img_style_horror
    ),
    COMEDY(
        promptEnglish = "bright playful lighthearted comedy scene, expressive cheerful colors and fun energy",
        emoji = "😂",
        previewImageRes = R.drawable.img_style_comedy
    )
}

enum class VideoDuration(val seconds: Int, val label: String) {
    S5(5, "5s"),
    S10(10, "10s"),
    S15(15, "15s"),
    S30(30, "30s")
}

enum class BackgroundMusicMode(@DrawableRes val previewImageRes: Int?) {
    NONE(null),
    ENERGETIC(R.drawable.img_music_concert),
    CALM(R.drawable.img_bg_forest),
    FUNNY(R.drawable.img_music_funny)
}

enum class VideoQuality(
    val exportMaxSide: Int,
    val promptSuffix: String,
    @DrawableRes val previewImageRes: Int
) {
    STANDARD(720, "clean balanced detail", R.drawable.img_bg_cloud),
    HD(1080, "ultra high definition 4K crisp sharp focus, rich intricate detail", R.drawable.img_quality_hd)
}

enum class VideoAspectRatio(val ratioFloat: Float, val promptHint: String) {
    VERTICAL_9_16(9f / 16f, "vertical 9:16 portrait composition framed cleanly for TikTok/Reels"),
    SQUARE_1_1(1f, "balanced 1:1 square centered composition"),
    HORIZONTAL_16_9(16f / 9f, "wide 16:9 widescreen cinematic YouTube composition")
}

enum class ImageSizeOption(val ratioFloat: Float) {
    SQUARE(1f),
    STORY(9f / 16f),
    COVER(16f / 9f)
}

enum class ImageFilterType {
    NONE,
    NEON,
    MAGICAL,
    BW,
    VIVID,
    VINTAGE;

    fun toColorMatrix(): ColorMatrix? = when (this) {
        NONE -> null
        BW -> ColorMatrix().apply { setSaturation(0f) }
        VIVID -> ColorMatrix().apply { setSaturation(1.45f) }
        NEON -> ColorMatrix(
            floatArrayOf(
                1.25f, 0f, 0.25f, 0f, -12f,
                0f, 1.15f, 0.35f, 0f, 5f,
                0.25f, 0.1f, 1.4f, 0f, 18f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        MAGICAL -> ColorMatrix(
            floatArrayOf(
                1.18f, 0.08f, 0.15f, 0f, 12f,
                0.05f, 1.10f, 0.12f, 0f, 8f,
                0.18f, 0.08f, 1.28f, 0f, 18f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        VINTAGE -> ColorMatrix(
            floatArrayOf(
                0.95f, 0.32f, 0.12f, 0f, 14f,
                0.14f, 0.88f, 0.10f, 0f, 8f,
                0.06f, 0.16f, 0.65f, 0f, -6f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }
}

enum class AiImageEditAction(val editInstructionEnglish: String) {
    REMOVE_BG("Remove the background completely and isolate the main subject cleanly on a pure bright white studio background while keeping the subject crisp and untouched."),
    CHANGE_BG("Keep the main subject exactly the same, and replace the background with a breathtaking magical fantasy castle aurora landscape."),
    ENHANCE_QUALITY("Enhance image quality to ultra HD studio sharpness, fix lighting balance, refine facial and texture details naturally without changing composition."),
    TO_CARTOON("Transform this exact image and character into a vibrant stylized 3D cartoon animation style while preserving identity and pose."),
    TO_ANIME("Transform this exact image and scene into high-detail Japanese anime illustration style with expressive colors and clean linework."),
    ADD_LIGHTING("Add dramatic warm golden cinematic lighting, soft lens glow, and crisp rim illumination to make the image pop."),
    REMOVE_PERSON("Cleanly remove any distracting background person or extra crowd people and naturally inpaint the background behind them."),
    UPSCALE_EXPAND("Zoom out slightly, expand the surrounding environment seamlessly with rich high-resolution scenic details, and sharpen textures.")
}

enum class PhotoAction(
    val labelAr: String,
    val emoji: String,
    val sampleSpeechDarija: String,
    val ttsPitch: Float
) {
    SPEAK(
        labelAr = "يهضر",
        emoji = "🗣️",
        sampleSpeechDarija = "السلام عليكم! أنا جيمي، مرحباً بكم في هاد الفيديو الجديد بالذكاء الاصطناعي.",
        ttsPitch = 1.0f
    ),
    SING(
        labelAr = "يغني",
        emoji = "🎵",
        sampleSpeechDarija = "يا سلام على الفرحة والأمل، اليوم نهار زوين وكولو نشاط وموسيقى!",
        ttsPitch = 1.15f
    ),
    LAUGH(
        labelAr = "يضحك",
        emoji = "😂",
        sampleSpeechDarija = "هههه! والله هاد الفكرة واعرة بزاف مع جيمي، ضحكت من قلبي!",
        ttsPitch = 1.18f
    ),
    SMILE(
        labelAr = "يبتسم",
        emoji = "😊",
        sampleSpeechDarija = "ابتسامتك كتزيد الدنيا جمال، كنتمنى ليك نهار سعيد ومليان بالخير!",
        ttsPitch = 1.05f
    ),
    MOVE_HEAD(
        labelAr = "يحرك راسو",
        emoji = "🙂",
        sampleSpeechDarija = "شوف كيفاش الصورة ولات حية وكتتحرك بكل سلاسة بالذكاء الاصطناعي!",
        ttsPitch = 1.0f
    ),
    CRY(
        labelAr = "يبكي",
        emoji = "😢",
        sampleSpeechDarija = "تأثرت بزاف بهاد اللحظة، ولكن ديما كاين الأمل لغد أفضل إن شاء الله.",
        ttsPitch = 0.88f
    )
}

enum class VideoCategory(
    val id: String,
    val titleAr: String,
    val subtitleDarija: String,
    @DrawableRes val imageRes: Int,
    val samplePrompts: List<String>
) {
    STORIES(
        id = "stories",
        titleAr = "قصص",
        subtitleDarija = "حكايات مشوقة ومصورة",
        imageRes = R.drawable.img_cat_stories,
        samplePrompts = listOf(
            "حكيم مغربي في الصحراء كيحكي قصة الكنز المفقود تحت ضو النجوم والفوانيس",
            "قصة قصيرة بالدارجة على الصداقة والوفاء فقرية جبلية زوينة"
        )
    ),
    EDUCATION(
        id = "education",
        titleAr = "تعليم",
        subtitleDarija = "شروحات ساهلة وممتعة",
        imageRes = R.drawable.img_cat_education,
        samplePrompts = listOf(
            "أستاذ يشرح كيفاش كيخدم الذكاء الاصطناعي بطريقة بسيطة بالدارجة المغربية",
            "معلومات عجيبة على الفضاء والكواكب بأسلوب مشوق للتلاميذ"
        )
    ),
    SONGS(
        id = "songs",
        titleAr = "أغاني",
        subtitleDarija = "كلمات وإيقاعات عصرية",
        imageRes = R.drawable.img_cat_songs,
        samplePrompts = listOf(
            "مغني شاب في ستوديو بإضاءة زرقاء كيغني أغنية حماسية على النجاح والطموح",
            "كلمات أغنية مغربية هادئة على جمال الصباح والأمل"
        )
    ),
    ADS(
        id = "ads",
        titleAr = "إعلانات",
        subtitleDarija = "إشهارات احترافية لمنتجاتك",
        imageRes = R.drawable.img_cat_ads,
        samplePrompts = listOf(
            "إعلان احترافي لعطر مغربي فاخر بالأركان والعود مع عرض جذاب",
            "فيديو إشهاري قصير بالدارجة لمتجر إلكتروني كيبيع هواتف ذكية بأحسن ثمن"
        )
    )
}

enum class CreationMode(val labelAr: String) {
    TEXT_TO_VIDEO("تحويل النص إلى فيديو"),
    ANIMATE_PHOTO("تحريك صورة"),
    IMAGE_ONLY("مولد الصور"),
    AI_STUDIO("إنشاء بالذكاء الاصطناعي")
}

data class FaceLandmarks(
    val hasFace: Boolean,
    val leftEyeX: Float = 0.42f,
    val leftEyeY: Float = 0.40f,
    val rightEyeX: Float = 0.58f,
    val rightEyeY: Float = 0.40f,
    val eyeRadiusNorm: Float = 0.045f,
    val mouthCenterX: Float = 0.50f,
    val mouthCenterY: Float = 0.62f,
    val mouthWidthNorm: Float = 0.18f,
    val mouthHeightNorm: Float = 0.09f,
    val skinColorArgb: Int = 0xFFD9A684.toInt(),
    val lipShadowArgb: Int = 0xFF3E1C18.toInt()
)

data class GeneratedMedia(
    val id: String,
    val title: String,
    val narrationText: String,
    val bitmap: Bitmap,
    val faceLandmarks: FaceLandmarks,
    val mode: CreationMode,
    val category: VideoCategory?,
    val isVideoAnimated: Boolean,
    val photoAction: PhotoAction = PhotoAction.SPEAK,
    val aspectRatio: Float = 1f,
    val durationSeconds: Int = 10,
    val artStyle: VideoArtStyle = VideoArtStyle.FANTASY,
    val quality: VideoQuality = VideoQuality.HD,
    val musicMode: BackgroundMusicMode = BackgroundMusicMode.NONE,
    val filter: ImageFilterType = ImageFilterType.NONE,
    val createdAtMillis: Long = System.currentTimeMillis()
)

sealed interface GenerationUiState {
    data object Idle : GenerationUiState
    data class Loading(val stepLabel: String, val mode: CreationMode) : GenerationUiState
    data class Success(val media: GeneratedMedia) : GenerationUiState
    data class Error(val message: String) : GenerationUiState
}

sealed interface ExportUiState {
    data object Idle : ExportUiState
    data class Exporting(val message: String) : ExportUiState
    data class Completed(val message: String, val isShareReady: Boolean = false) : ExportUiState
    data class Failed(val message: String) : ExportUiState
}
