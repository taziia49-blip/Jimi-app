package com.example.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FaceRetouchingNatural
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.ui.components.AnimatedVideoPlayerCard
import com.example.ui.components.DraggableFloatingJimiOrb
import com.example.ui.components.FantasyBackdrop
import com.example.ui.components.FloatingJimiAssistantOverlay
import com.example.ui.components.GeminiApiKeyDialog
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.ImageStudioWorkspace
import com.example.ui.components.ProVideoOptionsSection
import com.example.ui.components.RobotAvatarHeaderCard
import com.example.ui.components.RobotChatMessageBubble
import com.example.ui.components.RobotInputCard
import com.example.ui.components.RobotQuickTopicsRow
import com.example.ui.components.SettingsScreen
import com.example.ui.components.TomorrowBackgroundPreviewDialog
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.LocalizedStrings
import com.example.ui.i18n.localizedLabel
import com.example.ui.i18n.localizedName
import com.example.ui.i18n.localizedSamples
import com.example.ui.i18n.localizedSubtitle
import com.example.ui.i18n.localizedTitle
import com.example.ui.i18n.stringsFor
import com.example.ui.model.AppTab
import com.example.ui.model.FantasyBackground
import com.example.ui.model.GeneratedMedia
import com.example.ui.model.GenerationUiState
import com.example.ui.model.VideoCategory
import com.example.ui.theme.DarijaVideoTheme

@Composable
fun HomeScreen(
    viewModel: VideoGenViewModel = viewModel()
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val phoneState by viewModel.phoneState.collectAsStateWithLifecycle()
    val isSettingsOpen by viewModel.isSettingsOpen.collectAsStateWithLifecycle()
    val isApiKeyDialogOpen by viewModel.isApiKeyDialogOpen.collectAsStateWithLifecycle()
    val isTomorrowBgPreviewOpen by viewModel.isTomorrowBgPreviewOpen.collectAsStateWithLifecycle()
    val selectedLanguage = settings.language
    val strings = stringsFor(selectedLanguage)

    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val promptText by viewModel.promptText.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()

    // Pro Video Options
    val selectedVideoStyle by viewModel.selectedVideoStyle.collectAsStateWithLifecycle()
    val selectedDuration by viewModel.selectedDuration.collectAsStateWithLifecycle()
    val selectedMusicMode by viewModel.selectedMusicMode.collectAsStateWithLifecycle()
    val selectedQuality by viewModel.selectedQuality.collectAsStateWithLifecycle()
    val selectedAspectRatio by viewModel.selectedAspectRatio.collectAsStateWithLifecycle()

    // Photo Studio & Animation
    val photoGenPromptText by viewModel.photoGenPromptText.collectAsStateWithLifecycle()
    val selectedImageStyle by viewModel.selectedImageStyle.collectAsStateWithLifecycle()
    val selectedImageSize by viewModel.selectedImageSize.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val aiEditPromptText by viewModel.aiEditPromptText.collectAsStateWithLifecycle()
    val uploadedPhotoBitmap by viewModel.uploadedPhotoBitmap.collectAsStateWithLifecycle()
    val uploadedPhotoLandmarks by viewModel.uploadedPhotoLandmarks.collectAsStateWithLifecycle()
    val selectedPhotoAction by viewModel.selectedPhotoAction.collectAsStateWithLifecycle()
    val imageToVideoSpeechText by viewModel.imageToVideoSpeechText.collectAsStateWithLifecycle()

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val speechState by viewModel.speechState.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val exportState by viewModel.exportState.collectAsStateWithLifecycle()
    val recentCreations by viewModel.recentCreations.collectAsStateWithLifecycle()

    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val robotInputText by viewModel.robotInputText.collectAsStateWithLifecycle()
    val isRobotThinking by viewModel.isRobotThinking.collectAsStateWithLifecycle()
    val robotErrorText by viewModel.robotErrorText.collectAsStateWithLifecycle()
    val voiceInputState by viewModel.voiceInputState.collectAsStateWithLifecycle()

    val isFloatingJimiOpen by viewModel.isFloatingJimiOpen.collectAsStateWithLifecycle()
    val isFloatingListeningCmd by viewModel.isFloatingListeningCmd.collectAsStateWithLifecycle()
    val floatingLastTranscript by viewModel.floatingLastTranscript.collectAsStateWithLifecycle()
    val floatingJimiResponse by viewModel.floatingJimiResponse.collectAsStateWithLifecycle()

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.onPhotoUploaded(uri)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.shareEvents.collect { (exported, caption) ->
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = exported.mimeType
                putExtra(Intent.EXTRA_STREAM, exported.shareUri)
                putExtra(Intent.EXTRA_TEXT, caption)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, strings.btnShare))
        }
    }

    DarijaVideoTheme(darkTheme = settings.isDarkMode) {
        CompositionLocalProvider(LocalLayoutDirection provides selectedLanguage.layoutDirection) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (isSettingsOpen) {
                    SettingsScreen(
                        settings = settings,
                        phoneState = phoneState,
                        strings = strings,
                        onBack = viewModel::closeSettings,
                        onOpenChangeApiKey = viewModel::openApiKeyDialog,
                        onOpenTomorrowBgPreview = viewModel::openTomorrowBgPreview,
                        onAutoChangeBgToggle = viewModel::setAutoChangeBackground,
                        onSelectBackground = viewModel::selectBackground,
                        onUploadCustomBackground = viewModel::onCustomBackgroundUploaded,
                        onSelectLanguage = viewModel::setLanguage,
                        onVoiceEnabledToggle = viewModel::setVoiceEnabled,
                        onSelectVoiceType = viewModel::setVoiceType,
                        onSelectVoiceSpeed = viewModel::setVoiceSpeed,
                        onRobotNameChange = viewModel::setRobotName,
                        onSelectRobotPersonality = viewModel::setRobotPersonality,
                        onDarkModeChange = viewModel::setDarkMode,
                        onWakeWordToggle = viewModel::setWakeWordEnabled,
                        onMicPermissionDenied = viewModel::onMicPermissionDenied,
                        onOpenWhatsApp = { viewModel.openWhatsApp() },
                        onOpenYouTube = { viewModel.openYouTube() },
                        onOpenTikTok = { viewModel.openTikTok() },
                        onVibratePhone = { viewModel.vibratePhone() },
                        onToggleFlashlight = { viewModel.toggleFlashlight() },
                        onVolumeDown = { viewModel.volumeDown() },
                        onVolumeUp = { viewModel.volumeUp() },
                        onPinHomeIcon = { viewModel.pinJimiHomeIcon() }
                    )
                } else {
                    FantasyBackdrop(
                        background = settings.selectedBackground,
                        isDarkMode = settings.isDarkMode,
                        intense = false,
                        customBackgroundPath = settings.customBackgroundPath,
                        useCustomBackground = settings.useCustomBackground,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Scaffold(
                            containerColor = Color.Transparent,
                            contentWindowInsets = WindowInsets.safeDrawing,
                            bottomBar = {
                                AppBottomNavigationBar(
                                    selectedTab = selectedTab,
                                    strings = strings,
                                    isDarkMode = settings.isDarkMode,
                                    onSelectTab = viewModel::selectTab
                                )
                            }
                        ) { innerPadding ->
                            BoxWithConstraints(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding),
                                contentAlignment = Alignment.TopCenter
                            ) {
                                val isWide = maxWidth >= 680.dp
                                val containerWidthPx = constraints.maxWidth.toFloat()
                                val containerHeightPx = constraints.maxHeight.toFloat()

                                if (selectedTab == AppTab.ROBOT) {
                                    RobotScreenContent(
                                        strings = strings,
                                        robotName = settings.robotName,
                                        personalityLabel = settings.robotPersonality.localizedLabel(selectedLanguage),
                                        isDarkMode = settings.isDarkMode,
                                        chatMessages = chatMessages,
                                        robotInputText = robotInputText,
                                        isRobotThinking = isRobotThinking,
                                        robotErrorText = robotErrorText,
                                        speechState = speechState,
                                        voiceInputState = voiceInputState,
                                        onOpenMagic = viewModel::openFloatingJimi,
                                        onOpenSettings = viewModel::openSettings,
                                        onInputChange = viewModel::updateRobotInput,
                                        onSend = { viewModel.sendRobotMessage() },
                                        onSelectTopicPrompt = { prompt -> viewModel.sendRobotMessage(prompt) },
                                        onSpeakMessage = viewModel::speakChatMessage,
                                        onStopSpeech = viewModel::stopSpeech,
                                        onStartVoiceMic = viewModel::startRobotVoiceInput,
                                        onStopVoiceMic = viewModel::stopRobotVoiceInput,
                                        onMicPermissionDenied = viewModel::onMicPermissionDenied,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .widthIn(max = 760.dp)
                                    )
                                } else {
                                    LazyColumn(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .widthIn(max = 760.dp),
                                        contentPadding = PaddingValues(
                                            start = 16.dp,
                                            end = 16.dp,
                                            top = 12.dp,
                                            bottom = 168.dp
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        // Clean Top Bar (ONLY JIMI logo + AI Magic button + Settings) + Hero Title & Change BG pill
                                        item {
                                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                                TopAppBarWithSettingsGear(
                                                    strings = strings,
                                                    isDarkMode = settings.isDarkMode,
                                                    onOpenMagic = viewModel::openFloatingJimi,
                                                    onOpenSettings = viewModel::openSettings
                                                )
                                                HeroTitleSection(
                                                    strings = strings,
                                                    selectedBackground = settings.selectedBackground,
                                                    language = selectedLanguage,
                                                    hasGeminiApiKey = settings.geminiApiKey.isNotBlank(),
                                                    isDarkMode = settings.isDarkMode,
                                                    onOpenTomorrowPreview = viewModel::openTomorrowBgPreview,
                                                    onOpenApiKeyPrompt = viewModel::openApiKeyDialog
                                                )
                                            }
                                        }

                                        if (selectedTab == AppTab.VIDEO) {
                                            item {
                                                PromptComposerCard(
                                                    promptText = promptText,
                                                    isLoading = uiState is GenerationUiState.Loading,
                                                    isDarkMode = settings.isDarkMode,
                                                    strings = strings,
                                                    onPromptChange = viewModel::updatePrompt,
                                                    onWriteWithJimi = viewModel::writeScriptWithJimi,
                                                    onTextToVideo = viewModel::generateTextToVideo,
                                                    onAnimatePhoto = {
                                                        viewModel.selectTab(AppTab.IMAGE_TO_VIDEO)
                                                        photoPickerLauncher.launch(
                                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                        )
                                                    },
                                                    onImageGenerator = viewModel::generateImageOnly,
                                                    onAiCreate = viewModel::generateWithAiAssistant
                                                )
                                            }

                                            item {
                                                ProVideoOptionsSection(
                                                    selectedStyle = selectedVideoStyle,
                                                    selectedDuration = selectedDuration,
                                                    selectedVoice = settings.voiceType,
                                                    selectedMusic = selectedMusicMode,
                                                    selectedQuality = selectedQuality,
                                                    selectedRatio = selectedAspectRatio,
                                                    language = selectedLanguage,
                                                    strings = strings,
                                                    isDarkMode = settings.isDarkMode,
                                                    onSelectStyle = viewModel::selectVideoStyle,
                                                    onSelectDuration = viewModel::selectDuration,
                                                    onSelectVoice = viewModel::setVoiceType,
                                                    onSelectMusic = viewModel::selectMusicMode,
                                                    onSelectQuality = viewModel::selectQuality,
                                                    onSelectRatio = viewModel::selectAspectRatio
                                                )
                                            }
                                        } else {
                                            item {
                                                ImageStudioWorkspace(
                                                    photoGenPromptText = photoGenPromptText,
                                                    selectedImageStyle = selectedImageStyle,
                                                    selectedImageSize = selectedImageSize,
                                                    selectedFilter = selectedFilter,
                                                    aiEditPromptText = aiEditPromptText,
                                                    uploadedBitmap = uploadedPhotoBitmap,
                                                    landmarks = uploadedPhotoLandmarks,
                                                    selectedAction = selectedPhotoAction,
                                                    speechText = imageToVideoSpeechText,
                                                    isLoading = uiState is GenerationUiState.Loading,
                                                    isDarkMode = settings.isDarkMode,
                                                    language = selectedLanguage,
                                                    strings = strings,
                                                    onPhotoGenPromptChange = viewModel::updatePhotoGenPrompt,
                                                    onSelectImageStyle = viewModel::selectImageStyle,
                                                    onSelectImageSize = viewModel::selectImageSize,
                                                    onGenerateAiPhoto = viewModel::generatePhotoStudioImage,
                                                    onSelectFilter = viewModel::selectFilter,
                                                    onAiEditPromptChange = viewModel::updateAiEditPrompt,
                                                    onApplyAiEditPreset = { preset ->
                                                        viewModel.applyAiImageEdit(action = preset)
                                                    },
                                                    onApplyCustomAiEdit = {
                                                        viewModel.applyAiImageEdit(action = null)
                                                    },
                                                    onUploadPhotoClick = {
                                                        photoPickerLauncher.launch(
                                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                        )
                                                    },
                                                    onSelectAction = viewModel::selectPhotoAction,
                                                    onSpeechTextChange = viewModel::updateImageToVideoSpeechText,
                                                    onUseSampleSpeech = viewModel::applySampleSpeechForSelectedAction,
                                                    onGenerateVideo = viewModel::generateImageToVideo
                                                )
                                            }
                                        }

                                        item {
                                            AnimatedVisibility(visible = uiState !is GenerationUiState.Idle) {
                                                when (val state = uiState) {
                                                    is GenerationUiState.Loading -> GenerationLoadingCard(
                                                        stepLabel = state.stepLabel,
                                                        isDarkMode = settings.isDarkMode
                                                    )
                                                    is GenerationUiState.Success -> AnimatedVideoPlayerCard(
                                                        media = state.media,
                                                        speechState = speechState,
                                                        isPlaying = isPlaying,
                                                        exportState = exportState,
                                                        strings = strings,
                                                        language = selectedLanguage,
                                                        isDarkMode = settings.isDarkMode,
                                                        onTogglePlay = viewModel::togglePlayPause,
                                                        onReplay = viewModel::replay,
                                                        onCycleSpeed = viewModel::cycleSpeechRate,
                                                        onDownload = viewModel::downloadCurrent,
                                                        onShare = viewModel::shareCurrent,
                                                        onConvertToVideo = viewModel::convertCurrentImageToVideo
                                                    )
                                                    is GenerationUiState.Error -> ErrorNoticeCard(
                                                        message = state.message,
                                                        retryLabel = strings.retryBtn,
                                                        onRetry = {
                                                            if (selectedTab == AppTab.VIDEO) {
                                                                viewModel.generateTextToVideo()
                                                            } else {
                                                                viewModel.generateImageToVideo()
                                                            }
                                                        }
                                                    )
                                                    GenerationUiState.Idle -> Unit
                                                }
                                            }
                                        }

                                        if (selectedTab == AppTab.VIDEO) {
                                            item {
                                                CategoriesSection(
                                                    selectedCategory = selectedCategory,
                                                    isWide = isWide,
                                                    isDarkMode = settings.isDarkMode,
                                                    language = selectedLanguage,
                                                    strings = strings,
                                                    onSelectCategory = viewModel::selectCategory,
                                                    onPickSamplePrompt = viewModel::applySamplePrompt
                                                )
                                            }
                                        }

                                        if (recentCreations.isNotEmpty()) {
                                            item {
                                                RecentCreationsSection(
                                                    items = recentCreations,
                                                    title = strings.recentCreationsTitle,
                                                    isDarkMode = settings.isDarkMode,
                                                    onSelectItem = viewModel::selectRecentItem
                                                )
                                            }
                                        }
                                    }
                                }

                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        if (containerWidthPx > 0f && containerHeightPx > 0f) {
                                            DraggableFloatingJimiOrb(
                                                containerWidthPx = containerWidthPx,
                                                containerHeightPx = containerHeightPx,
                                                savedOnRight = settings.floatingOrbOnRight,
                                                savedYFraction = settings.floatingOrbYFraction,
                                                isWakeActive = settings.wakeWordEnabled || voiceInputState.isWakeMonitorActive,
                                                isListening = isFloatingListeningCmd || voiceInputState.isListening,
                                                rmsLevel = voiceInputState.rmsLevel,
                                                isSpeaking = speechState.isSpeaking,
                                                isExpanded = isFloatingJimiOpen,
                                                assistantLabel = strings.floatingJimiTitle,
                                                onSingleTap = viewModel::openFloatingJimi,
                                                onPositionSaved = viewModel::saveFloatingOrbPosition
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                FloatingJimiAssistantOverlay(
                    visible = isFloatingJimiOpen,
                    isDarkMode = settings.isDarkMode,
                    wakeWordEnabled = settings.wakeWordEnabled,
                    isListeningForCommand = isFloatingListeningCmd,
                    isSpeaking = speechState.isSpeaking,
                    voiceInputState = voiceInputState,
                    lastTranscript = floatingLastTranscript,
                    jimiResponseText = floatingJimiResponse,
                    strings = strings,
                    onDismiss = viewModel::closeFloatingJimi,
                    onToggleWakeWord = viewModel::setWakeWordEnabled,
                    onMicPermissionDenied = viewModel::onMicPermissionDenied,
                    onWakeAndListenNow = viewModel::wakeJimiAndListen,
                    onStopListening = viewModel::stopFloatingListening,
                    onExecuteCommandText = { cmd -> viewModel.handleJimiVoiceOrCommand(cmd, alreadyAwake = true) }
                )

                if (isTomorrowBgPreviewOpen) {
                    TomorrowBackgroundPreviewDialog(
                        currentBackground = settings.selectedBackground,
                        language = selectedLanguage,
                        isDarkMode = settings.isDarkMode,
                        strings = strings,
                        onDismiss = viewModel::closeTomorrowBgPreview
                    )
                }

                if (isApiKeyDialogOpen) {
                    GeminiApiKeyDialog(
                        initialKey = settings.geminiApiKey,
                        isDarkMode = settings.isDarkMode,
                        strings = strings,
                        onSaveKey = viewModel::saveGeminiApiKey,
                        onDismiss = viewModel::closeApiKeyDialog
                    )
                }
            }
        }
    }
}

@Composable
private fun TopAppBarWithSettingsGear(
    strings: LocalizedStrings,
    isDarkMode: Boolean,
    onOpenMagic: () -> Unit,
    onOpenSettings: () -> Unit
) {
    // Clean top bar: ONLY JIMI logo + AI Magic button + Settings gear
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    shadowElevation = 4.dp,
                    border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.7f)),
                    modifier = Modifier.size(46.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.jimi_app_icon_fg),
                        contentDescription = strings.studioBadge,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = strings.studioBadge,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = strings.studioTagline,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = if (isDarkMode) Color(0xFF312E81).copy(alpha = 0.85f)
                    else Color.White.copy(alpha = 0.84f),
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = if (isDarkMode) 0.2f else 0.7f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .clickable(onClick = onOpenMagic)
                        .testTag("btn_top_ai_magic")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = strings.freeBadge,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Surface(
                    color = if (isDarkMode) Color(0xFF1E293B).copy(alpha = 0.84f)
                    else Color.White.copy(alpha = 0.84f),
                    shape = CircleShape,
                    border = BorderStroke(1.dp, Color.White.copy(alpha = if (isDarkMode) 0.24f else 0.85f)),
                    shadowElevation = 3.dp,
                    modifier = Modifier.size(48.dp)
                ) {
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("btn_open_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = strings.openSettingsDesc,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroTitleSection(
    strings: LocalizedStrings,
    selectedBackground: FantasyBackground,
    language: AppLanguage,
    hasGeminiApiKey: Boolean,
    isDarkMode: Boolean,
    onOpenTomorrowPreview: () -> Unit,
    onOpenApiKeyPrompt: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = strings.heroTitle,
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.testTag("home_big_title")
        )
        Text(
            text = strings.heroSubtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Daily Background Pill ("خلفية اليوم") + Preview Tomorrow Button ("شوف خلفيات غدا")
        Surface(
            color = if (isDarkMode) Color(0xFF0F172A).copy(alpha = 0.72f)
            else Color.White.copy(alpha = 0.78f),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = if (isDarkMode) 0.20f else 0.75f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Image(
                        painter = painterResource(id = selectedBackground.imageRes),
                        contentDescription = strings.dailyBgLabel,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = strings.dailyBgLabel,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.testTag("label_daily_background")
                        )
                        Text(
                            text = selectedBackground.localizedName(language),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                FilledTonalButton(
                    onClick = onOpenTomorrowPreview,
                    shape = RoundedCornerShape(999.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .height(40.dp)
                        .testTag("btn_home_preview_tomorrow_bg")
                ) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = strings.btnPreviewTomorrowBg,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = strings.btnPreviewTomorrowBg,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1
                    )
                }
            }
        }

        if (!hasGeminiApiKey) {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.88f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(onClick = onOpenApiKeyPrompt)
                    .testTag("banner_missing_api_key")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.apiKeyNotSetStatus,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = strings.btnChangeApiKey,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun AppBottomNavigationBar(
    selectedTab: AppTab,
    strings: LocalizedStrings,
    isDarkMode: Boolean,
    onSelectTab: (AppTab) -> Unit
) {
    val navBg = if (isDarkMode) Color(0xFF0F172A).copy(alpha = 0.88f)
    else Color.White.copy(alpha = 0.86f)

    NavigationBar(
        containerColor = navBg,
        tonalElevation = 4.dp,
        windowInsets = WindowInsets.navigationBars
    ) {
        val items = listOf(
            Triple(AppTab.VIDEO, strings.tabVideo, Icons.Default.MovieCreation),
            Triple(AppTab.IMAGE_TO_VIDEO, strings.tabPhoto, Icons.Default.FaceRetouchingNatural),
            Triple(AppTab.ROBOT, strings.tabRobot, Icons.Default.SmartToy)
        )
        items.forEach { (tab, label, icon) ->
            val selected = selectedTab == tab
            NavigationBarItem(
                selected = selected,
                onClick = { onSelectTab(tab) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label
                    )
                },
                label = {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag("bottom_tab_${tab.name.lowercase()}")
            )
        }
    }
}

@Composable
private fun RobotScreenContent(
    strings: LocalizedStrings,
    robotName: String,
    personalityLabel: String,
    isDarkMode: Boolean,
    chatMessages: List<com.example.ui.model.ChatMessage>,
    robotInputText: String,
    isRobotThinking: Boolean,
    robotErrorText: String?,
    speechState: com.example.media.SpeechUiState,
    voiceInputState: com.example.media.VoiceInputState,
    onOpenMagic: () -> Unit,
    onOpenSettings: () -> Unit,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onSelectTopicPrompt: (String) -> Unit,
    onSpeakMessage: (com.example.ui.model.ChatMessage) -> Unit,
    onStopSpeech: () -> Unit,
    onStartVoiceMic: () -> Unit,
    onStopVoiceMic: () -> Unit,
    onMicPermissionDenied: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    LaunchedEffect(chatMessages.size, chatMessages.lastOrNull()?.text?.length) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.lastIndex)
        }
    }

    Column(
        modifier = modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        TopAppBarWithSettingsGear(
            strings = strings,
            isDarkMode = isDarkMode,
            onOpenMagic = onOpenMagic,
            onOpenSettings = onOpenSettings
        )

        RobotAvatarHeaderCard(
            strings = strings,
            robotName = robotName,
            personalityLabel = personalityLabel,
            isSpeaking = speechState.isSpeaking,
            isThinking = isRobotThinking,
            isListening = voiceInputState.isListening,
            isDarkMode = isDarkMode
        )

        RobotQuickTopicsRow(
            strings = strings,
            onSelectTopicPrompt = onSelectTopicPrompt
        )

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 4.dp, bottom = 72.dp)
        ) {
            items(chatMessages, key = { it.id }) { msg ->
                RobotChatMessageBubble(
                    message = msg,
                    robotName = robotName,
                    speechState = speechState,
                    strings = strings,
                    isDarkMode = isDarkMode,
                    onSpeakMessage = onSpeakMessage,
                    onStopSpeech = onStopSpeech
                )
            }
        }

        if (!robotErrorText.isNullOrBlank()) {
            Text(
                text = robotErrorText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }

        RobotInputCard(
            inputText = robotInputText,
            isThinking = isRobotThinking,
            voiceInputState = voiceInputState,
            strings = strings,
            isDarkMode = isDarkMode,
            onInputChange = onInputChange,
            onSendText = onSend,
            onStartVoiceMic = onStartVoiceMic,
            onStopVoiceMic = onStopVoiceMic,
            onMicPermissionDenied = onMicPermissionDenied
        )
    }
}

@Composable
private fun PromptComposerCard(
    promptText: String,
    isLoading: Boolean,
    isDarkMode: Boolean,
    strings: LocalizedStrings,
    onPromptChange: (String) -> Unit,
    onWriteWithJimi: () -> Unit,
    onTextToVideo: () -> Unit,
    onAnimatePhoto: () -> Unit,
    onImageGenerator: () -> Unit,
    onAiCreate: () -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        isDarkMode = isDarkMode
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = promptText,
                onValueChange = onPromptChange,
                placeholder = {
                    Text(
                        text = strings.promptHint,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                trailingIcon = {
                    if (promptText.isNotEmpty()) {
                        IconButton(
                            onClick = { onPromptChange("") },
                            modifier = Modifier.testTag("clear_prompt_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = strings.clearTextDesc,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                minLines = 3,
                maxLines = 5,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.56f),
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("prompt_text_field")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // AI Magic Script Writer ("خلي JIMI يكتب ليا النص")
            FilledTonalButton(
                onClick = onWriteWithJimi,
                enabled = !isLoading,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("btn_write_with_jimi")
            ) {
                Icon(
                    imageVector = Icons.Default.AutoFixHigh,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = strings.btnWriteWithJimi,
                    style = MaterialTheme.typography.labelLarge
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onTextToVideo,
                enabled = !isLoading,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(vertical = 14.dp, horizontal = 16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_text_to_video")
            ) {
                Icon(
                    imageVector = Icons.Default.MovieCreation,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = strings.btnTextToVideo,
                    style = MaterialTheme.typography.labelLarge
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FeatureActionButton(
                    label = strings.btnAnimatePhoto,
                    icon = Icons.Default.AddPhotoAlternate,
                    enabled = !isLoading,
                    onClick = onAnimatePhoto,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_animate_photo")
                )
                FeatureActionButton(
                    label = strings.btnImageGen,
                    icon = Icons.Default.Image,
                    enabled = !isLoading,
                    onClick = onImageGenerator,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_image_generator")
                )
                FeatureActionButton(
                    label = strings.btnAiCreate,
                    icon = Icons.Default.AutoAwesome,
                    enabled = !isLoading,
                    onClick = onAiCreate,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_ai_create")
                )
            }
        }
    }
}

@Composable
private fun FeatureActionButton(
    label: String,
    icon: ImageVector,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilledTonalButton(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        ),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 10.dp),
        modifier = modifier.height(66.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun GenerationLoadingCard(
    stepLabel: String,
    isDarkMode: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        isDarkMode = isDarkMode
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = pulse)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(32.dp),
                    color = MaterialTheme.colorScheme.primary,
                    strokeWidth = 3.dp
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = stepLabel,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(10.dp))
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(6.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primaryContainer
            )
        }
    }
}

@Composable
private fun ErrorNoticeCard(
    message: String,
    retryLabel: String,
    onRetry: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onRetry,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(text = retryLabel, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun CategoriesSection(
    selectedCategory: VideoCategory?,
    isWide: Boolean,
    isDarkMode: Boolean,
    language: AppLanguage,
    strings: LocalizedStrings,
    onSelectCategory: (VideoCategory) -> Unit,
    onPickSamplePrompt: (String) -> Unit
) {
    val categories = VideoCategory.entries

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.categoriesTitle,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = strings.chooseCategoryHint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (isWide) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                categories.forEach { category ->
                    CategoryImageCard(
                        category = category,
                        isSelected = category == selectedCategory,
                        isDarkMode = isDarkMode,
                        language = language,
                        onClick = { onSelectCategory(category) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                categories.chunked(2).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowItems.forEach { category ->
                            CategoryImageCard(
                                category = category,
                                isSelected = category == selectedCategory,
                                isDarkMode = isDarkMode,
                                language = language,
                                onClick = { onSelectCategory(category) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        if (selectedCategory != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.TipsAndUpdates,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${strings.readyIdeasPrefix} ${selectedCategory.localizedTitle(language)}:",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                selectedCategory.localizedSamples(language).forEach { sample ->
                    SuggestionChip(
                        onClick = { onPickSamplePrompt(sample) },
                        label = {
                            Text(
                                text = sample,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
                            labelColor = MaterialTheme.colorScheme.onSurface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryImageCard(
    category: VideoCategory,
    isSelected: Boolean,
    isDarkMode: Boolean,
    language: AppLanguage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag("category_card_${category.id}"),
        shape = RoundedCornerShape(18.dp),
        isDarkMode = isDarkMode,
        accentColor = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFFC084FC),
        elevation = if (isSelected) 6.dp else 2.dp
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(4f / 3f)
            ) {
                Image(
                    painter = painterResource(id = category.imageRes),
                    contentDescription = category.localizedTitle(language),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.35f))
                            )
                        )
                )
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .size(22.dp)
                            .background(Color.White, CircleShape)
                    )
                }
            }
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                Text(
                    text = category.localizedTitle(language),
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = category.localizedSubtitle(language),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun RecentCreationsSection(
    items: List<GeneratedMedia>,
    title: String,
    isDarkMode: Boolean,
    onSelectItem: (GeneratedMedia) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(10.dp))
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items, key = { it.id }) { item ->
                GlassmorphicCard(
                    modifier = Modifier
                        .width(148.dp)
                        .clickable { onSelectItem(item) }
                        .testTag("recent_item_${item.id}"),
                    shape = RoundedCornerShape(16.dp),
                    isDarkMode = isDarkMode
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                        ) {
                            Image(
                                bitmap = item.bitmap.asImageBitmap(),
                                contentDescription = item.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            if (item.isVideoAnimated) {
                                Icon(
                                    imageVector = Icons.Default.PlayCircleFilled,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.9f),
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .size(34.dp)
                                )
                            }
                        }
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}
