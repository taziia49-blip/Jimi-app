package com.example.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiMediaRepository
import com.example.data.SettingsRepository
import com.example.device.JimiCommandParser
import com.example.device.JimiIntent
import com.example.device.PhoneControlState
import com.example.device.PhoneController
import com.example.media.AmbientMusicPlayer
import com.example.media.ExportResult
import com.example.media.FaceMotionAnalyzer
import com.example.media.MediaExporter
import com.example.media.SpeechUiState
import com.example.media.VoiceInputManager
import com.example.media.VoiceInputState
import com.example.media.VoiceNarrator
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.localizedName
import com.example.ui.i18n.localizedSampleSpeech
import com.example.ui.i18n.stringsFor
import com.example.ui.model.AiImageEditAction
import com.example.ui.model.AppSettings
import com.example.ui.model.AppTab
import com.example.ui.model.BackgroundMusicMode
import com.example.ui.model.BgChangeSpeed
import com.example.ui.model.ChatMessage
import com.example.ui.model.CreationMode
import com.example.ui.model.ExportUiState
import com.example.ui.model.FaceLandmarks
import com.example.ui.model.FantasyBackground
import com.example.ui.model.GeneratedMedia
import com.example.ui.model.GenerationUiState
import com.example.ui.model.ImageFilterType
import com.example.ui.model.ImageSizeOption
import com.example.ui.model.PhotoAction
import com.example.ui.model.RobotPersonality
import com.example.ui.model.VideoArtStyle
import com.example.ui.model.VideoAspectRatio
import com.example.ui.model.VideoCategory
import com.example.ui.model.VideoDuration
import com.example.ui.model.VideoQuality
import com.example.ui.model.VoiceSpeedOption
import com.example.ui.model.VoiceType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

private const val TAG = "VideoGenViewModel"

class VideoGenViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepo = SettingsRepository(application)
    private val repository = AiMediaRepository()
    private val narrator = VoiceNarrator(application)
    private val voiceInput = VoiceInputManager(application)
    private val phoneController = PhoneController(application)
    private val musicPlayer = AmbientMusicPlayer()

    val speechState: StateFlow<SpeechUiState> = narrator.state
    val voiceInputState: StateFlow<VoiceInputState> = voiceInput.state
    val phoneState: StateFlow<PhoneControlState> = phoneController.state

    private val _settings = MutableStateFlow(settingsRepo.load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private val _isApiKeyDialogOpen = MutableStateFlow(_settings.value.geminiApiKey.isBlank())
    val isApiKeyDialogOpen: StateFlow<Boolean> = _isApiKeyDialogOpen.asStateFlow()

    private val _isTomorrowBgPreviewOpen = MutableStateFlow(false)
    val isTomorrowBgPreviewOpen: StateFlow<Boolean> = _isTomorrowBgPreviewOpen.asStateFlow()

    private val _selectedTab = MutableStateFlow(AppTab.VIDEO)
    val selectedTab: StateFlow<AppTab> = _selectedTab.asStateFlow()

    // Floating JIMI Assistant Overlay State
    private val _isFloatingJimiOpen = MutableStateFlow(false)
    val isFloatingJimiOpen: StateFlow<Boolean> = _isFloatingJimiOpen.asStateFlow()

    private val _isFloatingListeningCmd = MutableStateFlow(false)
    val isFloatingListeningCmd: StateFlow<Boolean> = _isFloatingListeningCmd.asStateFlow()

    private val _floatingLastTranscript = MutableStateFlow("")
    val floatingLastTranscript: StateFlow<String> = _floatingLastTranscript.asStateFlow()

    private val _floatingJimiResponse = MutableStateFlow("")
    val floatingJimiResponse: StateFlow<String> = _floatingJimiResponse.asStateFlow()

    // Text-to-Video + Pro Video Options state
    private val _promptText = MutableStateFlow("")
    val promptText: StateFlow<String> = _promptText.asStateFlow()

    private val _selectedCategory = MutableStateFlow<VideoCategory?>(VideoCategory.STORIES)
    val selectedCategory: StateFlow<VideoCategory?> = _selectedCategory.asStateFlow()

    private val _selectedVideoStyle = MutableStateFlow(VideoArtStyle.FANTASY)
    val selectedVideoStyle: StateFlow<VideoArtStyle> = _selectedVideoStyle.asStateFlow()

    private val _selectedDuration = MutableStateFlow(VideoDuration.S10)
    val selectedDuration: StateFlow<VideoDuration> = _selectedDuration.asStateFlow()

    private val _selectedMusicMode = MutableStateFlow(BackgroundMusicMode.CALM)
    val selectedMusicMode: StateFlow<BackgroundMusicMode> = _selectedMusicMode.asStateFlow()

    private val _selectedQuality = MutableStateFlow(VideoQuality.HD)
    val selectedQuality: StateFlow<VideoQuality> = _selectedQuality.asStateFlow()

    private val _selectedAspectRatio = MutableStateFlow(VideoAspectRatio.VERTICAL_9_16)
    val selectedAspectRatio: StateFlow<VideoAspectRatio> = _selectedAspectRatio.asStateFlow()

    // Image Studio & Image-to-Video state
    private val _photoGenPromptText = MutableStateFlow("")
    val photoGenPromptText: StateFlow<String> = _photoGenPromptText.asStateFlow()

    private val _selectedImageStyle = MutableStateFlow(VideoArtStyle.FANTASY)
    val selectedImageStyle: StateFlow<VideoArtStyle> = _selectedImageStyle.asStateFlow()

    private val _selectedImageSize = MutableStateFlow(ImageSizeOption.SQUARE)
    val selectedImageSize: StateFlow<ImageSizeOption> = _selectedImageSize.asStateFlow()

    private val _selectedFilter = MutableStateFlow(ImageFilterType.NONE)
    val selectedFilter: StateFlow<ImageFilterType> = _selectedFilter.asStateFlow()

    private val _aiEditPromptText = MutableStateFlow("")
    val aiEditPromptText: StateFlow<String> = _aiEditPromptText.asStateFlow()

    private val _uploadedPhotoBitmap = MutableStateFlow<Bitmap?>(null)
    val uploadedPhotoBitmap: StateFlow<Bitmap?> = _uploadedPhotoBitmap.asStateFlow()

    private val _uploadedPhotoLandmarks = MutableStateFlow<FaceLandmarks?>(null)
    val uploadedPhotoLandmarks: StateFlow<FaceLandmarks?> = _uploadedPhotoLandmarks.asStateFlow()

    private val _selectedPhotoAction = MutableStateFlow(PhotoAction.SPEAK)
    val selectedPhotoAction: StateFlow<PhotoAction> = _selectedPhotoAction.asStateFlow()

    private val _imageToVideoSpeechText = MutableStateFlow("")
    val imageToVideoSpeechText: StateFlow<String> = _imageToVideoSpeechText.asStateFlow()

    // Shared media output & playback state
    private val _uiState = MutableStateFlow<GenerationUiState>(GenerationUiState.Idle)
    val uiState: StateFlow<GenerationUiState> = _uiState.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _exportState = MutableStateFlow<ExportUiState>(ExportUiState.Idle)
    val exportState: StateFlow<ExportUiState> = _exportState.asStateFlow()

    private val _recentCreations = MutableStateFlow<List<GeneratedMedia>>(emptyList())
    val recentCreations: StateFlow<List<GeneratedMedia>> = _recentCreations.asStateFlow()

    // JIMI Chat state
    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "welcome",
                text = stringsFor(_settings.value.language).robotWelcomeMessage,
                isFromUser = false
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _robotInputText = MutableStateFlow("")
    val robotInputText: StateFlow<String> = _robotInputText.asStateFlow()

    private val _isRobotThinking = MutableStateFlow(false)
    val isRobotThinking: StateFlow<Boolean> = _isRobotThinking.asStateFlow()

    private val _robotErrorText = MutableStateFlow<String?>(null)
    val robotErrorText: StateFlow<String?> = _robotErrorText.asStateFlow()

    private var robotJob: Job? = null
    private var bgAutoChangeJob: Job? = null

    private val _shareEvents = MutableSharedFlow<Pair<ExportResult, String>>()
    val shareEvents: SharedFlow<Pair<ExportResult, String>> = _shareEvents.asSharedFlow()

    init {
        syncNarratorWithSettings(_settings.value)
        ensureDailyBackgroundCached()
        scheduleMidnightBackgroundRefresh()

        viewModelScope.launch {
            speechState.collect { st ->
                voiceInput.setPausedForTts(st.isSpeaking)
            }
        }

        if (_settings.value.wakeWordEnabled && hasMicPermission()) {
            startWakeMonitor()
        }
    }

    private fun currentDateKey(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    private fun millisUntilNextMidnight(): Long {
        val now = Calendar.getInstance()
        val nextMidnight = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 2)
            set(Calendar.MILLISECOND, 0)
        }
        return (nextMidnight.timeInMillis - now.timeInMillis).coerceAtLeast(60_000L)
    }

    private fun ensureDailyBackgroundCached() {
        val todayKey = currentDateKey()
        val cur = _settings.value
        if (cur.cachedBgDate == todayKey) {
            return // Already cached for today: keep one background per day without reloading
        }
        val nextBg = if (cur.cachedBgDate.isBlank()) {
            cur.selectedBackground
        } else if (cur.autoChangeBackground) {
            cur.selectedBackground.next()
        } else {
            cur.selectedBackground
        }
        updateAndPersistSettings { s ->
            s.copy(
                selectedBackground = nextBg,
                useCustomBackground = if (s.cachedBgDate.isNotBlank() && s.autoChangeBackground) false else s.useCustomBackground,
                cachedBgDate = todayKey
            )
        }
    }

    private fun hasMicPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            getApplication(),
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun syncNarratorWithSettings(s: AppSettings) {
        narrator.applyVoiceSettings(
            language = s.language,
            enabled = s.voiceEnabled,
            voiceType = s.voiceType,
            speedOption = s.voiceSpeed
        )
    }

    private fun updateAndPersistSettings(transform: (AppSettings) -> AppSettings) {
        val updated = transform(_settings.value)
        _settings.value = updated
        settingsRepo.save(updated)
        syncNarratorWithSettings(updated)
    }

    private fun scheduleMidnightBackgroundRefresh() {
        bgAutoChangeJob?.cancel()
        if (!_settings.value.autoChangeBackground) return
        bgAutoChangeJob = viewModelScope.launch {
            while (true) {
                delay(millisUntilNextMidnight())
                ensureDailyBackgroundCached()
            }
        }
    }

    // ---------------- Gemini API Key & Tomorrow Preview ----------------

    fun openApiKeyDialog() {
        _isApiKeyDialogOpen.value = true
    }

    fun closeApiKeyDialog() {
        _isApiKeyDialogOpen.value = false
    }

    fun saveGeminiApiKey(rawKey: String) {
        val cleaned = rawKey.trim()
        if (cleaned.isEmpty()) return
        updateAndPersistSettings { it.copy(geminiApiKey = cleaned) }
        _isApiKeyDialogOpen.value = false
        _robotErrorText.value = null
        if (_uiState.value is GenerationUiState.Error) {
            _uiState.value = GenerationUiState.Idle
        }
    }

    fun openTomorrowBgPreview() {
        _isTomorrowBgPreviewOpen.value = true
    }

    fun closeTomorrowBgPreview() {
        _isTomorrowBgPreviewOpen.value = false
    }

    private fun requireUserApiKeyOrPrompt(): String? {
        val key = _settings.value.geminiApiKey.trim()
        if (key.isEmpty()) {
            val msg = stringsFor(_settings.value.language).apiKeyMissingError
            _uiState.value = GenerationUiState.Error(msg)
            _robotErrorText.value = msg
            _isApiKeyDialogOpen.value = true
            return null
        }
        return key
    }

    // ---------------- Settings Actions ----------------

    fun openSettings() {
        phoneController.refreshVolume()
        _isSettingsOpen.value = true
    }

    fun closeSettings() {
        _isSettingsOpen.value = false
    }

    fun setAutoChangeBackground(enabled: Boolean) {
        updateAndPersistSettings { it.copy(autoChangeBackground = enabled) }
        scheduleMidnightBackgroundRefresh()
    }

    fun setBackgroundSpeed(speed: BgChangeSpeed) {
        updateAndPersistSettings { it.copy(backgroundChangeSpeed = speed) }
    }

    fun selectBackground(bg: FantasyBackground) {
        val todayKey = currentDateKey()
        updateAndPersistSettings {
            it.copy(
                selectedBackground = bg,
                useCustomBackground = false,
                cachedBgDate = todayKey
            )
        }
    }

    fun cycleBackgroundNow() {
        val todayKey = currentDateKey()
        updateAndPersistSettings {
            it.copy(
                selectedBackground = it.selectedBackground.next(),
                useCustomBackground = false,
                cachedBgDate = todayKey
            )
        }
    }

    fun onCustomBackgroundUploaded(uri: Uri) {
        viewModelScope.launch {
            val savedPath = withContext(Dispatchers.IO) {
                val bmp = decodeScaledBitmap(uri) ?: return@withContext null
                val dest = File(getApplication<Application>().filesDir, "custom_fantasy_bg.jpg")
                FileOutputStream(dest).use { out ->
                    bmp.compress(Bitmap.CompressFormat.JPEG, 92, out)
                }
                dest.absolutePath
            }
            if (savedPath != null) {
                val todayKey = currentDateKey()
                updateAndPersistSettings {
                    it.copy(
                        customBackgroundPath = savedPath,
                        useCustomBackground = true,
                        cachedBgDate = todayKey
                    )
                }
            }
        }
    }

    fun setLanguage(language: AppLanguage) {
        if (_settings.value.language == language) return
        updateAndPersistSettings { it.copy(language = language) }
        narrator.stop()
        musicPlayer.stop()
        voiceInput.stopListening()
        voiceInput.clearError()
        _isPlaying.value = false
        _robotErrorText.value = null

        val newWelcome = stringsFor(language).robotWelcomeMessage
        _chatMessages.update { msgs ->
            if (msgs.size == 1 && msgs.first().id == "welcome") {
                listOf(msgs.first().copy(text = newWelcome))
            } else {
                msgs
            }
        }
        if (_settings.value.wakeWordEnabled && hasMicPermission()) {
            startWakeMonitor()
        }
    }

    fun setVoiceEnabled(enabled: Boolean) {
        updateAndPersistSettings { it.copy(voiceEnabled = enabled) }
    }

    fun setVoiceType(voiceType: VoiceType) {
        updateAndPersistSettings { it.copy(voiceType = voiceType) }
    }

    fun setVoiceSpeed(speedOption: VoiceSpeedOption) {
        updateAndPersistSettings { it.copy(voiceSpeed = speedOption) }
    }

    fun setRobotName(name: String) {
        updateAndPersistSettings { it.copy(robotName = name) }
    }

    fun setRobotPersonality(personality: RobotPersonality) {
        updateAndPersistSettings { it.copy(robotPersonality = personality) }
    }

    fun setDarkMode(dark: Boolean) {
        updateAndPersistSettings { it.copy(isDarkMode = dark) }
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        updateAndPersistSettings { it.copy(wakeWordEnabled = enabled) }
        if (enabled) {
            startWakeMonitor()
        } else {
            voiceInput.stopWakeWordLoop()
        }
    }

    private fun startWakeMonitor() {
        val lang = _settings.value.language
        val strings = stringsFor(lang)
        voiceInput.startWakeWordLoop(
            languageTag = lang.speechRecognizerTag,
            unavailableMsg = strings.robotMicUnavailableError
        ) { transcript ->
            if (JimiCommandParser.containsWakeWord(transcript)) {
                handleJimiVoiceOrCommand(rawInput = transcript, alreadyAwake = false)
            }
        }
    }

    // ---------------- Phone Controls ----------------

    fun openWhatsApp(): String = phoneController.openWhatsApp(_settings.value.language).spokenFeedback
    fun openYouTube(): String = phoneController.openYouTube(_settings.value.language).spokenFeedback
    fun openTikTok(): String = phoneController.openTikTok(_settings.value.language).spokenFeedback
    fun vibratePhone(): String = phoneController.vibratePhone(_settings.value.language).spokenFeedback
    fun toggleFlashlight(): String = phoneController.toggleFlashlight(_settings.value.language).spokenFeedback
    fun volumeDown(): String = phoneController.adjustVolume(increase = false, _settings.value.language).spokenFeedback
    fun volumeUp(): String = phoneController.adjustVolume(increase = true, _settings.value.language).spokenFeedback
    fun pinJimiHomeIcon(): String = phoneController.pinJimiHomeShortcut(_settings.value.language).spokenFeedback

    // ---------------- Floating JIMI Assistant ----------------

    fun saveFloatingOrbPosition(onRight: Boolean, yFraction: Float) {
        updateAndPersistSettings {
            it.copy(
                floatingOrbOnRight = onRight,
                floatingOrbYFraction = yFraction.coerceIn(0f, 1f)
            )
        }
    }

    fun openFloatingJimi() {
        _isFloatingJimiOpen.value = true
        if (_floatingJimiResponse.value.isBlank()) {
            _floatingJimiResponse.value = stringsFor(_settings.value.language).floatingJimiWakeGreeting
        }
    }

    fun closeFloatingJimi() {
        _isFloatingJimiOpen.value = false
        _isFloatingListeningCmd.value = false
        if (!_settings.value.wakeWordEnabled) {
            voiceInput.stopListening()
        }
    }

    fun wakeJimiAndListen() {
        val lang = _settings.value.language
        val strings = stringsFor(lang)
        _isFloatingJimiOpen.value = true
        _floatingLastTranscript.value = ""
        _floatingJimiResponse.value = strings.floatingJimiWakeGreeting

        narrator.speak(
            text = strings.floatingJimiWakeGreeting,
            pitch = 1.0f,
            tag = "jimi_wake"
        ) {
            startSingleCommandListening()
        }
    }

    private fun startSingleCommandListening() {
        val lang = _settings.value.language
        val strings = stringsFor(lang)
        _isFloatingListeningCmd.value = true
        voiceInput.startListening(
            languageTag = lang.speechRecognizerTag,
            unavailableMsg = strings.robotMicUnavailableError
        ) { spoken ->
            _isFloatingListeningCmd.value = false
            if (spoken.isNotBlank()) {
                handleJimiVoiceOrCommand(rawInput = spoken, alreadyAwake = true)
            }
        }
    }

    fun stopFloatingListening() {
        _isFloatingListeningCmd.value = false
        voiceInput.stopListening()
    }

    fun handleJimiVoiceOrCommand(rawInput: String, alreadyAwake: Boolean = true) {
        val lang = _settings.value.language
        val strings = stringsFor(lang)
        _isFloatingJimiOpen.value = true
        _floatingLastTranscript.value = rawInput

        when (val intent = JimiCommandParser.parse(rawInput, alreadyAwake = alreadyAwake)) {
            is JimiIntent.WakeUpOnly -> {
                _floatingJimiResponse.value = strings.floatingJimiWakeGreeting
                narrator.speak(
                    text = strings.floatingJimiWakeGreeting,
                    pitch = 1.0f,
                    tag = "jimi_wake"
                ) {
                    startSingleCommandListening()
                }
            }
            is JimiIntent.OpenYouTube -> {
                val res = phoneController.openYouTube(lang).spokenFeedback
                speakFloatingResult(res)
            }
            is JimiIntent.OpenWhatsApp -> {
                val res = phoneController.openWhatsApp(lang).spokenFeedback
                speakFloatingResult(res)
            }
            is JimiIntent.OpenTikTok -> {
                val res = phoneController.openTikTok(lang).spokenFeedback
                speakFloatingResult(res)
            }
            is JimiIntent.ChangeBackground -> {
                cycleBackgroundNow()
                val bgName = _settings.value.selectedBackground.localizedName(lang)
                val res = when (lang) {
                    AppLanguage.DARIJA -> "بدلت ليك الخلفية لـ $bgName!"
                    AppLanguage.ARABIC -> "تم تغيير الخلفية إلى $bgName."
                    AppLanguage.FRENCH -> "Fond changé pour : $bgName !"
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Background switched to $bgName!"
                }
                speakFloatingResult(res)
            }
            is JimiIntent.SetFlashlight -> {
                val res = phoneController.setFlashlight(intent.on, lang).spokenFeedback
                speakFloatingResult(res)
            }
            is JimiIntent.ToggleFlashlight -> {
                val res = phoneController.toggleFlashlight(lang).spokenFeedback
                speakFloatingResult(res)
            }
            is JimiIntent.VibratePhone -> {
                val res = phoneController.vibratePhone(lang).spokenFeedback
                speakFloatingResult(res)
            }
            is JimiIntent.AdjustVolume -> {
                val res = phoneController.adjustVolume(intent.increase, lang).spokenFeedback
                speakFloatingResult(res)
            }
            is JimiIntent.MuteVolume -> {
                val res = phoneController.setVolumePercent(0, lang).spokenFeedback
                speakFloatingResult(res)
            }
            is JimiIntent.OpenSettings -> {
                openSettings()
                _isFloatingJimiOpen.value = false
                val res = when (lang) {
                    AppLanguage.DARIJA -> "فتحت ليك الإعدادات!"
                    AppLanguage.ARABIC -> "تم فتح الإعدادات."
                    AppLanguage.FRENCH -> "Paramètres ouverts !"
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Opening Settings!"
                }
                speakFloatingResult(res)
            }
            is JimiIntent.AskJimiQuestion -> {
                _isFloatingJimiOpen.value = false
                _isSettingsOpen.value = false
                _selectedTab.value = AppTab.ROBOT
                sendRobotMessage(questionOverride = intent.question)
            }
        }
    }

    private fun speakFloatingResult(feedback: String) {
        _floatingJimiResponse.value = feedback
        narrator.speak(text = feedback, pitch = 1.0f, tag = "jimi_cmd_feedback")
    }

    // ---------------- Navigation & Video Option Setters ----------------

    fun selectTab(tab: AppTab) {
        _selectedTab.value = tab
    }

    fun updatePrompt(text: String) {
        _promptText.value = text
    }

    fun selectCategory(category: VideoCategory) {
        _selectedCategory.value = category
    }

    fun applySamplePrompt(sample: String) {
        _promptText.value = sample
    }

    fun selectVideoStyle(style: VideoArtStyle) {
        _selectedVideoStyle.value = style
    }

    fun selectDuration(duration: VideoDuration) {
        _selectedDuration.value = duration
    }

    fun selectMusicMode(mode: BackgroundMusicMode) {
        _selectedMusicMode.value = mode
    }

    fun selectQuality(quality: VideoQuality) {
        _selectedQuality.value = quality
    }

    fun selectAspectRatio(ratio: VideoAspectRatio) {
        _selectedAspectRatio.value = ratio
    }

    // ---------------- Photo Studio & Image-to-Video Setters ----------------

    fun updatePhotoGenPrompt(text: String) {
        _photoGenPromptText.value = text
    }

    fun selectImageStyle(style: VideoArtStyle) {
        _selectedImageStyle.value = style
    }

    fun selectImageSize(size: ImageSizeOption) {
        _selectedImageSize.value = size
    }

    fun selectFilter(filter: ImageFilterType) {
        _selectedFilter.value = filter
        // If current player shows a photo or photo-video, update preview filter immediately
        val currentState = _uiState.value
        if (currentState is GenerationUiState.Success) {
            _uiState.value = GenerationUiState.Success(currentState.media.copy(filter = filter))
        }
    }

    fun updateAiEditPrompt(text: String) {
        _aiEditPromptText.value = text
    }

    fun selectPhotoAction(action: PhotoAction) {
        _selectedPhotoAction.value = action
    }

    fun updateImageToVideoSpeechText(text: String) {
        _imageToVideoSpeechText.value = text
    }

    fun applySampleSpeechForSelectedAction() {
        _imageToVideoSpeechText.value = _selectedPhotoAction.value.localizedSampleSpeech(_settings.value.language)
    }

    // ---------------- AI Script Writer ("خلي JIMI يكتب ليا النص") ----------------

    fun writeScriptWithJimi() {
        val userKey = requireUserApiKeyOrPrompt() ?: return
        val lang = _settings.value.language
        val strings = stringsFor(lang)
        viewModelScope.launch {
            _uiState.value = GenerationUiState.Loading(
                stepLabel = strings.stepWritingScript,
                mode = CreationMode.AI_STUDIO
            )
            val result = repository.generateScriptIdea(
                apiKey = userKey,
                topicSeed = _promptText.value.trim(),
                category = _selectedCategory.value,
                artStyle = _selectedVideoStyle.value,
                duration = _selectedDuration.value,
                language = lang
            )
            result.onSuccess { generatedScript ->
                _promptText.value = generatedScript
                _uiState.value = GenerationUiState.Idle
            }.onFailure { err ->
                _uiState.value = GenerationUiState.Error(err.message ?: "Failed to write script.")
            }
        }
    }

    // ---------------- Video Generation ----------------

    fun generateTextToVideo() {
        val strings = stringsFor(_settings.value.language)
        val input = _promptText.value.trim()
        if (input.isEmpty()) {
            _uiState.value = GenerationUiState.Error(strings.emptyPromptError)
            return
        }
        runAiGeneration(
            userText = input,
            mode = CreationMode.TEXT_TO_VIDEO,
            expandScript = false,
            animateAsVideo = true
        )
    }

    fun generateImageOnly() {
        val strings = stringsFor(_settings.value.language)
        val input = _promptText.value.trim()
        if (input.isEmpty()) {
            _uiState.value = GenerationUiState.Error(strings.emptyImagePromptError)
            return
        }
        runAiGeneration(
            userText = input,
            mode = CreationMode.IMAGE_ONLY,
            expandScript = false,
            animateAsVideo = false
        )
    }

    fun generateWithAiAssistant() {
        val lang = _settings.value.language
        val category = _selectedCategory.value ?: VideoCategory.STORIES
        val seed = _promptText.value.trim().ifEmpty {
            "Creative ${category.id} video idea in ${lang.aiLanguageInstruction}"
        }
        runAiGeneration(
            userText = seed,
            mode = CreationMode.AI_STUDIO,
            expandScript = true,
            animateAsVideo = true
        )
    }

    private fun runAiGeneration(
        userText: String,
        mode: CreationMode,
        expandScript: Boolean,
        animateAsVideo: Boolean
    ) {
        val userKey = requireUserApiKeyOrPrompt() ?: return
        val lang = _settings.value.language
        val strings = stringsFor(lang)
        val style = _selectedVideoStyle.value
        val duration = _selectedDuration.value
        val quality = _selectedQuality.value
        val aspect = _selectedAspectRatio.value
        val music = _selectedMusicMode.value

        viewModelScope.launch {
            narrator.stop()
            musicPlayer.stop()
            _isPlaying.value = false
            _exportState.value = ExportUiState.Idle
            _uiState.value = GenerationUiState.Loading(
                stepLabel = strings.stepPreparingScript,
                mode = mode
            )

            val planResult = repository.planVideoFromPrompt(
                apiKey = userKey,
                userText = userText,
                category = _selectedCategory.value,
                language = lang,
                expandScript = expandScript,
                artStyle = style,
                duration = duration,
                quality = quality,
                aspectHint = aspect.promptHint
            )
            val plan = planResult.getOrElse { err ->
                _uiState.value = GenerationUiState.Error(err.message ?: "Error preparing script.")
                return@launch
            }

            if (expandScript) {
                _promptText.value = plan.narrationDarija
            }

            _uiState.value = GenerationUiState.Loading(
                stepLabel = strings.stepGeneratingImage,
                mode = mode
            )

            val imageResult = repository.generateImage(
                apiKey = userKey,
                visualPromptEnglish = plan.visualPromptEnglish
            )
            val bitmap = imageResult.getOrElse { err ->
                _uiState.value = GenerationUiState.Error(err.message ?: "Failed to generate image.")
                return@launch
            }

            _uiState.value = GenerationUiState.Loading(
                stepLabel = strings.stepAnalyzingFace,
                mode = mode
            )

            val landmarks = withContext(Dispatchers.Default) {
                FaceMotionAnalyzer.analyze(bitmap)
            }

            val media = GeneratedMedia(
                id = UUID.randomUUID().toString().take(8),
                title = plan.titleArabic,
                narrationText = plan.narrationDarija,
                bitmap = bitmap,
                faceLandmarks = landmarks,
                mode = mode,
                category = _selectedCategory.value,
                isVideoAnimated = animateAsVideo,
                photoAction = PhotoAction.SPEAK,
                aspectRatio = aspect.ratioFloat,
                durationSeconds = duration.seconds,
                artStyle = style,
                quality = quality,
                musicMode = music,
                filter = ImageFilterType.NONE
            )

            publishMedia(media)
        }
    }

    // ---------------- Photo Tab: Generate, Edit with AI & Animate ----------------

    fun generatePhotoStudioImage() {
        val userKey = requireUserApiKeyOrPrompt() ?: return
        val lang = _settings.value.language
        val strings = stringsFor(lang)
        val prompt = _photoGenPromptText.value.trim()
        if (prompt.isEmpty()) {
            _uiState.value = GenerationUiState.Error(strings.emptyImagePromptError)
            return
        }

        val style = _selectedImageStyle.value
        val sizeOption = _selectedImageSize.value
        val filter = _selectedFilter.value
        val aspectHint = when (sizeOption) {
            ImageSizeOption.SQUARE -> "1:1 square centered portrait/scene composition"
            ImageSizeOption.STORY -> "9:16 vertical mobile story portrait composition"
            ImageSizeOption.COVER -> "16:9 wide cinematic cover banner composition"
        }

        viewModelScope.launch {
            narrator.stop()
            musicPlayer.stop()
            _isPlaying.value = false
            _exportState.value = ExportUiState.Idle
            _uiState.value = GenerationUiState.Loading(
                stepLabel = strings.stepGeneratingImage,
                mode = CreationMode.IMAGE_ONLY
            )

            val planResult = repository.planVideoFromPrompt(
                apiKey = userKey,
                userText = prompt,
                category = null,
                language = lang,
                expandScript = false,
                artStyle = style,
                duration = VideoDuration.S10,
                quality = VideoQuality.HD,
                aspectHint = aspectHint
            )
            val visualPrompt = planResult.getOrNull()?.visualPromptEnglish
                ?: "$prompt, ${style.promptEnglish}, $aspectHint"
            val title = planResult.getOrNull()?.titleArabic ?: prompt.take(26)

            val imgResult = repository.generateImage(
                apiKey = userKey,
                visualPromptEnglish = visualPrompt
            )
            val bitmap = imgResult.getOrElse { err ->
                _uiState.value = GenerationUiState.Error(err.message ?: "Failed to generate photo.")
                return@launch
            }

            val landmarks = withContext(Dispatchers.Default) {
                FaceMotionAnalyzer.analyze(bitmap)
            }

            _uploadedPhotoBitmap.value = bitmap
            _uploadedPhotoLandmarks.value = landmarks

            val media = GeneratedMedia(
                id = UUID.randomUUID().toString().take(8),
                title = title,
                narrationText = prompt,
                bitmap = bitmap,
                faceLandmarks = landmarks,
                mode = CreationMode.IMAGE_ONLY,
                category = null,
                isVideoAnimated = false,
                photoAction = _selectedPhotoAction.value,
                aspectRatio = sizeOption.ratioFloat,
                artStyle = style,
                quality = VideoQuality.HD,
                musicMode = BackgroundMusicMode.NONE,
                filter = filter
            )
            publishMedia(media)
        }
    }

    fun applyAiImageEdit(action: AiImageEditAction? = null, customPrompt: String? = null) {
        val userKey = requireUserApiKeyOrPrompt() ?: return
        val strings = stringsFor(_settings.value.language)
        val sourceBitmap = _uploadedPhotoBitmap.value
        if (sourceBitmap == null) {
            _uiState.value = GenerationUiState.Error(strings.emptyPhotoError)
            return
        }

        val customText = (customPrompt ?: _aiEditPromptText.value).trim()
        val editInstruction = when {
            action != null && customText.isNotEmpty() -> "${action.editInstructionEnglish} Also apply this user detail: $customText"
            action != null -> action.editInstructionEnglish
            customText.isNotEmpty() -> customText
            else -> {
                _uiState.value = GenerationUiState.Error(strings.emptyAiEditError)
                return
            }
        }

        viewModelScope.launch {
            narrator.stop()
            musicPlayer.stop()
            _isPlaying.value = false
            _exportState.value = ExportUiState.Idle
            _uiState.value = GenerationUiState.Loading(
                stepLabel = strings.stepEditingImage,
                mode = CreationMode.IMAGE_ONLY
            )

            val editedResult = repository.editImageWithAi(
                apiKey = userKey,
                inputBitmap = sourceBitmap,
                editInstruction = editInstruction
            )
            val editedBitmap = editedResult.getOrElse { err ->
                _uiState.value = GenerationUiState.Error(err.message ?: "AI image editing failed.")
                return@launch
            }

            val landmarks = withContext(Dispatchers.Default) {
                FaceMotionAnalyzer.analyze(editedBitmap)
            }
            _uploadedPhotoBitmap.value = editedBitmap
            _uploadedPhotoLandmarks.value = landmarks

            val media = GeneratedMedia(
                id = UUID.randomUUID().toString().take(8),
                title = action?.let { "✨ ${strings.secAiImageEdit}" } ?: customText.take(26).ifBlank { strings.tabPhoto },
                narrationText = customText.ifBlank { _imageToVideoSpeechText.value },
                bitmap = editedBitmap,
                faceLandmarks = landmarks,
                mode = CreationMode.IMAGE_ONLY,
                category = null,
                isVideoAnimated = false,
                photoAction = _selectedPhotoAction.value,
                aspectRatio = _selectedImageSize.value.ratioFloat,
                artStyle = _selectedImageStyle.value,
                quality = VideoQuality.HD,
                musicMode = BackgroundMusicMode.NONE,
                filter = _selectedFilter.value
            )
            publishMedia(media)
        }
    }

    fun onPhotoUploaded(uri: Uri) {
        val strings = stringsFor(_settings.value.language)
        viewModelScope.launch {
            _selectedTab.value = AppTab.IMAGE_TO_VIDEO
            _exportState.value = ExportUiState.Idle
            _uiState.value = GenerationUiState.Loading(
                stepLabel = strings.stepAnalyzingPhoto,
                mode = CreationMode.ANIMATE_PHOTO
            )

            val bitmap = withContext(Dispatchers.IO) {
                decodeScaledBitmap(uri)
            }
            if (bitmap == null) {
                _uiState.value = GenerationUiState.Error("Unable to load selected photo.")
                return@launch
            }

            val landmarks = withContext(Dispatchers.Default) {
                FaceMotionAnalyzer.analyze(bitmap)
            }

            _uploadedPhotoBitmap.value = bitmap
            _uploadedPhotoLandmarks.value = landmarks
            _uiState.value = GenerationUiState.Idle
        }
    }

    fun generateImageToVideo() {
        val strings = stringsFor(_settings.value.language)
        val bitmap = _uploadedPhotoBitmap.value
        if (bitmap == null) {
            _uiState.value = GenerationUiState.Error(strings.emptyPhotoError)
            return
        }
        val speechText = _imageToVideoSpeechText.value.trim()
        if (speechText.isEmpty()) {
            _uiState.value = GenerationUiState.Error(strings.emptySpeechError)
            return
        }

        val action = _selectedPhotoAction.value
        val landmarks = _uploadedPhotoLandmarks.value ?: FaceLandmarks(hasFace = false)
        val media = GeneratedMedia(
            id = UUID.randomUUID().toString().take(8),
            title = "${action.emoji} ${strings.tabPhoto}",
            narrationText = speechText,
            bitmap = bitmap,
            faceLandmarks = landmarks,
            mode = CreationMode.ANIMATE_PHOTO,
            category = null,
            isVideoAnimated = true,
            photoAction = action,
            aspectRatio = _selectedImageSize.value.ratioFloat,
            durationSeconds = _selectedDuration.value.seconds,
            artStyle = _selectedImageStyle.value,
            quality = _selectedQuality.value,
            musicMode = _selectedMusicMode.value,
            filter = _selectedFilter.value
        )
        publishMedia(media)
    }

    fun convertCurrentImageToVideo() {
        val current = (_uiState.value as? GenerationUiState.Success)?.media ?: return
        val narration = _imageToVideoSpeechText.value.trim()
            .ifEmpty { _promptText.value.trim() }
            .ifEmpty { current.narrationText }
            .ifEmpty { _selectedPhotoAction.value.localizedSampleSpeech(_settings.value.language) }
        val updated = current.copy(
            id = UUID.randomUUID().toString().take(8),
            narrationText = narration,
            isVideoAnimated = true,
            mode = CreationMode.TEXT_TO_VIDEO,
            musicMode = _selectedMusicMode.value,
            durationSeconds = _selectedDuration.value.seconds
        )
        publishMedia(updated)
    }

    private fun publishMedia(media: GeneratedMedia) {
        _uiState.value = GenerationUiState.Success(media)
        _recentCreations.update { existing ->
            (listOf(media) + existing.filterNot { it.id == media.id }).take(10)
        }
        if (media.isVideoAnimated) {
            startPlayback(media)
        } else {
            musicPlayer.stop()
            _isPlaying.value = false
        }
    }

    fun selectRecentItem(media: GeneratedMedia) {
        _exportState.value = ExportUiState.Idle
        _uiState.value = GenerationUiState.Success(media)
        if (media.isVideoAnimated) {
            startPlayback(media)
        } else {
            narrator.stop()
            musicPlayer.stop()
            _isPlaying.value = false
        }
    }

    fun togglePlayPause() {
        val current = (_uiState.value as? GenerationUiState.Success)?.media ?: return
        if (!current.isVideoAnimated) return

        if (_isPlaying.value) {
            _isPlaying.value = false
            narrator.stop()
            musicPlayer.stop()
        } else {
            startPlayback(current)
        }
    }

    fun replay() {
        val current = (_uiState.value as? GenerationUiState.Success)?.media ?: return
        if (!current.isVideoAnimated) return
        startPlayback(current)
    }

    private fun startPlayback(media: GeneratedMedia) {
        _isPlaying.value = true
        musicPlayer.start(media.musicMode)
        narrator.speak(
            text = media.narrationText,
            pitch = media.photoAction.ttsPitch,
            tag = media.id
        ) {
            _isPlaying.value = false
            musicPlayer.stop()
        }
    }

    fun cycleSpeechRate() {
        val next = when (_settings.value.voiceSpeed) {
            VoiceSpeedOption.SLOW -> VoiceSpeedOption.NORMAL
            VoiceSpeedOption.NORMAL -> VoiceSpeedOption.FAST
            VoiceSpeedOption.FAST -> VoiceSpeedOption.SLOW
        }
        setVoiceSpeed(next)
        val media = (_uiState.value as? GenerationUiState.Success)?.media
        if (media != null && _isPlaying.value) {
            startPlayback(media)
        }
    }

    fun downloadCurrent() {
        val strings = stringsFor(_settings.value.language)
        val current = (_uiState.value as? GenerationUiState.Success)?.media ?: return
        viewModelScope.launch {
            _exportState.value = ExportUiState.Exporting(strings.exportingLabel)
            val result = MediaExporter.exportMedia(
                context = getApplication(),
                media = current,
                asVideo = current.isVideoAnimated
            )
            result.onSuccess { exported ->
                _exportState.value = ExportUiState.Completed(exported.message)
            }.onFailure { err ->
                _exportState.value = ExportUiState.Failed(err.message ?: "Export failed.")
            }
        }
    }

    fun shareCurrent() {
        val strings = stringsFor(_settings.value.language)
        val current = (_uiState.value as? GenerationUiState.Success)?.media ?: return
        viewModelScope.launch {
            _exportState.value = ExportUiState.Exporting(strings.exportingLabel)
            val result = MediaExporter.exportMedia(
                context = getApplication(),
                media = current,
                asVideo = current.isVideoAnimated
            )
            result.onSuccess { exported ->
                _exportState.value = ExportUiState.Completed(strings.shareReadyLabel, isShareReady = true)
                _shareEvents.emit(exported to current.narrationText)
            }.onFailure { err ->
                _exportState.value = ExportUiState.Failed(err.message ?: "Share failed.")
            }
        }
    }

    // ---------------- JIMI Chat ----------------

    fun updateRobotInput(text: String) {
        _robotInputText.value = text
        _robotErrorText.value = null
        voiceInput.clearError()
    }

    fun sendRobotMessage(questionOverride: String? = null) {
        val curSettings = _settings.value
        val lang = curSettings.language
        val strings = stringsFor(lang)
        val question = (questionOverride ?: _robotInputText.value).trim()
        if (question.isEmpty()) {
            _robotErrorText.value = strings.robotEmptyQuestionError
            return
        }

        if (questionOverride == null) {
            _robotInputText.value = ""
        }
        _robotErrorText.value = null
        narrator.stop()
        musicPlayer.stop()
        _isPlaying.value = false

        val parsed = JimiCommandParser.parse(question, alreadyAwake = true)
        if (parsed !is JimiIntent.AskJimiQuestion) {
            val replyText = executeChatPhoneIntent(parsed, lang)
            val userMsg = ChatMessage(id = UUID.randomUUID().toString().take(8), text = question, isFromUser = true)
            val replyId = UUID.randomUUID().toString().take(8)
            val replyMsg = ChatMessage(id = replyId, text = replyText, isFromUser = false)
            _chatMessages.update { it + userMsg + replyMsg }
            narrator.speak(text = replyText, pitch = 1.0f, tag = replyId)
            return
        }

        val userKey = requireUserApiKeyOrPrompt() ?: return

        val historySnapshot = _chatMessages.value
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString().take(8),
            text = question,
            isFromUser = true
        )
        val robotMsgId = UUID.randomUUID().toString().take(8)
        val robotPlaceholder = ChatMessage(
            id = robotMsgId,
            text = "",
            isFromUser = false,
            isStreaming = true
        )

        _chatMessages.update { it + userMsg + robotPlaceholder }
        _isRobotThinking.value = true

        robotJob?.cancel()
        robotJob = viewModelScope.launch {
            var latestText = ""
            try {
                repository.streamRobotReply(
                    apiKey = userKey,
                    history = historySnapshot,
                    userQuestion = parsed.question,
                    language = lang,
                    robotName = curSettings.robotName.ifBlank { "JIMI" },
                    personality = curSettings.robotPersonality
                ).collect { streamedText ->
                    latestText = streamedText
                    _chatMessages.update { list ->
                        list.map { msg ->
                            if (msg.id == robotMsgId) msg.copy(text = streamedText, isStreaming = true)
                            else msg
                        }
                    }
                }

                _chatMessages.update { list ->
                    list.map { msg ->
                        if (msg.id == robotMsgId) msg.copy(text = latestText, isStreaming = false)
                        else msg
                    }
                }
                _isRobotThinking.value = false

                if (latestText.isNotBlank()) {
                    narrator.speak(text = latestText, pitch = 1.0f, tag = robotMsgId)
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "JIMI response timed out", e)
                _isRobotThinking.value = false
                updateRobotMessageError(robotMsgId, "Request timed out. Please try again.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "JIMI response failed", e)
                _isRobotThinking.value = false
                updateRobotMessageError(
                    robotMsgId,
                    e.localizedMessage ?: "Failed to reach JIMI."
                )
            }
        }
    }

    private fun executeChatPhoneIntent(intent: JimiIntent, lang: AppLanguage): String {
        val strings = stringsFor(lang)
        return when (intent) {
            is JimiIntent.WakeUpOnly -> strings.floatingJimiWakeGreeting
            is JimiIntent.OpenYouTube -> phoneController.openYouTube(lang).spokenFeedback
            is JimiIntent.OpenWhatsApp -> phoneController.openWhatsApp(lang).spokenFeedback
            is JimiIntent.OpenTikTok -> phoneController.openTikTok(lang).spokenFeedback
            is JimiIntent.ChangeBackground -> {
                cycleBackgroundNow()
                val bgName = _settings.value.selectedBackground.localizedName(lang)
                when (lang) {
                    AppLanguage.DARIJA -> "بدلت ليك الخلفية لـ $bgName!"
                    AppLanguage.ARABIC -> "تم تغيير الخلفية إلى $bgName."
                    AppLanguage.FRENCH -> "Fond changé pour : $bgName !"
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Background switched to $bgName!"
                }
            }
            is JimiIntent.SetFlashlight -> phoneController.setFlashlight(intent.on, lang).spokenFeedback
            is JimiIntent.ToggleFlashlight -> phoneController.toggleFlashlight(lang).spokenFeedback
            is JimiIntent.VibratePhone -> phoneController.vibratePhone(lang).spokenFeedback
            is JimiIntent.AdjustVolume -> phoneController.adjustVolume(intent.increase, lang).spokenFeedback
            is JimiIntent.MuteVolume -> phoneController.setVolumePercent(0, lang).spokenFeedback
            is JimiIntent.OpenSettings -> {
                openSettings()
                when (lang) {
                    AppLanguage.DARIJA -> "فتحت ليك الإعدادات!"
                    AppLanguage.ARABIC -> "تم فتح الإعدادات."
                    AppLanguage.FRENCH -> "Paramètres ouverts !"
                    AppLanguage.ENGLISH, AppLanguage.SPANISH -> "Opening Settings!"
                }
            }
            is JimiIntent.AskJimiQuestion -> ""
        }
    }

    private fun updateRobotMessageError(robotMsgId: String, errorText: String) {
        _chatMessages.update { list ->
            list.map { msg ->
                if (msg.id == robotMsgId) msg.copy(text = "⚠️ $errorText", isStreaming = false)
                else msg
            }
        }
    }

    fun speakChatMessage(message: ChatMessage) {
        if (message.text.isBlank()) return
        narrator.speak(text = message.text, pitch = 1.0f, tag = message.id)
    }

    fun stopSpeech() {
        narrator.stop()
        musicPlayer.stop()
        _isPlaying.value = false
    }

    fun startRobotVoiceInput() {
        val lang = _settings.value.language
        val strings = stringsFor(lang)
        narrator.stop()
        musicPlayer.stop()
        _robotErrorText.value = null
        voiceInput.startListening(
            languageTag = lang.speechRecognizerTag,
            unavailableMsg = strings.robotMicUnavailableError
        ) { recognizedText ->
            if (recognizedText.isNotBlank()) {
                _robotInputText.value = recognizedText
                sendRobotMessage(questionOverride = recognizedText)
            }
        }
    }

    fun stopRobotVoiceInput() {
        voiceInput.stopListening()
    }

    fun onMicPermissionDenied() {
        _robotErrorText.value = stringsFor(_settings.value.language).robotMicDeniedError
    }

    private fun decodeScaledBitmap(uri: Uri): Bitmap? {
        return try {
            val resolver = getApplication<Application>().contentResolver
            val raw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val source = ImageDecoder.createSource(resolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val maxDim = maxOf(info.size.width, info.size.height)
                    if (maxDim > 1080) {
                        val scale = 1080f / maxDim
                        decoder.setTargetSize(
                            (info.size.width * scale).toInt().coerceAtLeast(2),
                            (info.size.height * scale).toInt().coerceAtLeast(2)
                        )
                    }
                }
            } else {
                resolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)
                }
            }
            raw?.let {
                if (it.config == Bitmap.Config.HARDWARE) {
                    it.copy(Bitmap.Config.ARGB_8888, false)
                } else it
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decode picked image", e)
            null
        }
    }

    override fun onCleared() {
        super.onCleared()
        narrator.release()
        voiceInput.destroy()
        musicPlayer.stop()
    }
}
