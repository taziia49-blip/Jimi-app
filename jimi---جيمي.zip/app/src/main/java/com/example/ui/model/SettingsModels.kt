package com.example.ui.model

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color
import com.example.R
import com.example.ui.i18n.AppLanguage

enum class FantasyBackground(
    val id: String,
    @DrawableRes val imageRes: Int,
    val accentColor: Color
) {
    MAGICAL_CASTLE(
        id = "castle",
        imageRes = R.drawable.img_bg_castle,
        accentColor = Color(0xFF38BDF8)
    ),
    NEON_CITY(
        id = "neon_city",
        imageRes = R.drawable.img_bg_neon_city,
        accentColor = Color(0xFFE879F9)
    ),
    GALAXY(
        id = "galaxy",
        imageRes = R.drawable.img_bg_galaxy,
        accentColor = Color(0xFFA78BFA)
    ),
    OCEAN_DREAM(
        id = "ocean",
        imageRes = R.drawable.img_bg_ocean,
        accentColor = Color(0xFF2DD4BF)
    ),
    FOREST_MAGIC(
        id = "forest",
        imageRes = R.drawable.img_bg_forest,
        accentColor = Color(0xFF4ADE80)
    ),
    DESERT_SUNSET(
        id = "desert",
        imageRes = R.drawable.img_bg_desert,
        accentColor = Color(0xFFFB923C)
    ),
    ANIME_WORLD(
        id = "anime",
        imageRes = R.drawable.img_bg_anime,
        accentColor = Color(0xFFF472B6)
    ),
    CYBERPUNK(
        id = "cyberpunk",
        imageRes = R.drawable.img_bg_cyberpunk,
        accentColor = Color(0xFF22D3EE)
    ),
    CLOUD_KINGDOM(
        id = "cloud",
        imageRes = R.drawable.img_bg_cloud,
        accentColor = Color(0xFFFBBF24)
    ),
    FIRE_DRAGON(
        id = "dragon",
        imageRes = R.drawable.img_bg_dragon,
        accentColor = Color(0xFFF97316)
    );

    fun next(): FantasyBackground {
        val list = entries
        return list[(ordinal + 1) % list.size]
    }
}

enum class BgChangeSpeed(val seconds: Int, val millis: Long) {
    FAST_5S(5, 5_000L),
    AUTO_8S(8, 8_000L),
    MEDIUM_15S(15, 15_000L),
    SLOW_30S(30, 30_000L)
}

enum class VoiceType(
    val basePitch: Float,
    @DrawableRes val avatarImageRes: Int
) {
    MALE(0.82f, R.drawable.img_voice_man),
    FEMALE(1.12f, R.drawable.img_voice_woman),
    CHILD(1.34f, R.drawable.img_voice_kid),
    ROBOT(0.66f, R.drawable.jimi_app_icon_fg)
}

enum class VoiceSpeedOption(val rate: Float) {
    SLOW(0.76f),
    NORMAL(1.0f),
    FAST(1.28f)
}

enum class RobotPersonality(val promptInstruction: String) {
    FUNNY("Be playful, witty, and humorous, adding clever light jokes where natural."),
    SERIOUS("Be formal, concise, objective, and highly structured."),
    TEACHER("Be a patient, encouraging teacher explaining concepts clearly step by step with examples."),
    FRIEND("Be a warm, supportive close friend speaking casually and kindly.")
}

data class AppSettings(
    val autoChangeBackground: Boolean = true,
    val backgroundChangeSpeed: BgChangeSpeed = BgChangeSpeed.AUTO_8S,
    val selectedBackground: FantasyBackground = FantasyBackground.MAGICAL_CASTLE,
    val customBackgroundPath: String? = null,
    val useCustomBackground: Boolean = false,
    val language: AppLanguage = AppLanguage.DARIJA,
    val voiceEnabled: Boolean = true,
    val voiceType: VoiceType = VoiceType.FEMALE,
    val voiceSpeed: VoiceSpeedOption = VoiceSpeedOption.NORMAL,
    val robotName: String = "JIMI",
    val robotPersonality: RobotPersonality = RobotPersonality.FRIEND,
    val isDarkMode: Boolean = false,
    val wakeWordEnabled: Boolean = false,
    val floatingOrbOnRight: Boolean = true,
    val floatingOrbYFraction: Float = -1f,
    val cachedBgDate: String = "",
    val geminiApiKey: String = ""
)
