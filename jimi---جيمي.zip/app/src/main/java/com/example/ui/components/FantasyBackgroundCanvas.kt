package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.ui.model.FantasyBackground
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.sin

private sealed interface BgRenderTarget {
    data class Preset(val bg: FantasyBackground) : BgRenderTarget
    data class CustomFile(val path: String, val fallback: FantasyBackground) : BgRenderTarget
}

@Composable
fun FantasyBackdrop(
    background: FantasyBackground,
    isDarkMode: Boolean,
    intense: Boolean,
    customBackgroundPath: String? = null,
    useCustomBackground: Boolean = false,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val renderTarget = if (useCustomBackground && !customBackgroundPath.isNullOrBlank()) {
        BgRenderTarget.CustomFile(customBackgroundPath, background)
    } else {
        BgRenderTarget.Preset(background)
    }

    val customBitmap by produceState<Bitmap?>(initialValue = null, customBackgroundPath, useCustomBackground) {
        value = if (useCustomBackground && !customBackgroundPath.isNullOrBlank()) {
            withContext(Dispatchers.IO) {
                val file = File(customBackgroundPath)
                if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
            }
        } else {
            null
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "fantasySparkles")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.283185f,
        animationSpec = infiniteRepeatable(
            animation = tween(16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sparklePhase"
    )

    Box(modifier = modifier) {
        Crossfade(
            targetState = renderTarget,
            animationSpec = tween(durationMillis = 1200),
            label = "fantasyBgCrossfade",
            modifier = Modifier.fillMaxSize()
        ) { target ->
            val bmp = if (target is BgRenderTarget.CustomFile) customBitmap else null
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                val preset = when (target) {
                    is BgRenderTarget.Preset -> target.bg
                    is BgRenderTarget.CustomFile -> target.fallback
                }
                Image(
                    painter = painterResource(id = preset.imageRes),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Readability & atmospheric gradient scrim over the real AI fantasy artwork
        val scrimBrush = if (isDarkMode || intense) {
            Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF070518).copy(alpha = if (intense) 0.52f else 0.44f),
                    Color(0xFF0B0A22).copy(alpha = if (intense) 0.42f else 0.34f),
                    Color(0xFF070518).copy(alpha = if (intense) 0.62f else 0.56f)
                )
            )
        } else {
            Brush.verticalGradient(
                colors = listOf(
                    Color(0xFFF5F3FF).copy(alpha = 0.52f),
                    Color(0xFFEFF6FF).copy(alpha = 0.38f),
                    Color(0xFFF8FAFC).copy(alpha = 0.56f)
                )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(scrimBrush)
        )

        // Subtle animated magical starlight dust
        Canvas(modifier = Modifier.fillMaxSize()) {
            val starAlpha = if (isDarkMode || intense) 0.58f else 0.42f
            val orbColor = background.accentColor
            val starPositions = listOf(
                0.10f to 0.12f, 0.86f to 0.10f, 0.68f to 0.25f,
                0.20f to 0.42f, 0.91f to 0.50f, 0.14f to 0.76f,
                0.76f to 0.85f, 0.48f to 0.16f, 0.54f to 0.62f,
                0.35f to 0.30f, 0.63f to 0.46f, 0.28f to 0.88f
            )
            starPositions.forEachIndexed { idx, (rx, ry) ->
                val twinkle = 0.3f + 0.7f * ((sin(phase * 2.1f + idx * 1.15f) + 1f) * 0.5f)
                val starColor = if (isDarkMode || intense) Color.White else orbColor
                val center = Offset(size.width * rx, size.height * ry)
                val radius = (1.5f + (idx % 3) * 1.1f) * density
                drawCircle(
                    color = starColor.copy(alpha = starAlpha * twinkle),
                    radius = radius,
                    center = center
                )
            }
        }

        content()
    }
}
