package com.example.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import com.example.ui.i18n.AppLanguage
import com.example.ui.model.ChatMessage
import com.example.ui.model.RobotPersonality
import com.example.ui.model.VideoArtStyle
import com.example.ui.model.VideoCategory
import com.example.ui.model.VideoDuration
import com.example.ui.model.VideoQuality
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

private const val TAG = "AiMediaRepository"
private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
private const val TEXT_MODEL = "gemini-2.5-flash"
private const val IMAGE_MODEL_PRIMARY = "gemini-2.5-flash-image"
private const val IMAGE_MODEL_FALLBACK = "gemini-2.0-flash-exp-image-generation"

class MissingGeminiApiKeyException : IllegalStateException(
    "Gemini API key is required. Please add your Gemini API key first."
)

data class EnhancedVideoPlan(
    val titleArabic: String,
    val narrationDarija: String,
    val visualPromptEnglish: String
)

class AiMediaRepository {

    suspend fun generateScriptIdea(
        apiKey: String,
        topicSeed: String,
        category: VideoCategory?,
        artStyle: VideoArtStyle,
        duration: VideoDuration,
        language: AppLanguage
    ): Result<String> {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return Result.failure(MissingGeminiApiKeyException())
        }
        return try {
            val targetLang = language.aiLanguageInstruction
            val catLabel = category?.let { "${it.titleAr} (${it.id})" } ?: "general creative video"
            val sentenceTarget = when (duration) {
                VideoDuration.S5 -> "1 punchy sentence (around 10-15 words)"
                VideoDuration.S10 -> "2 engaging sentences (around 22-30 words)"
                VideoDuration.S15 -> "3 vivid sentences (around 35-45 words)"
                VideoDuration.S30 -> "4-5 expressive sentences (around 60-80 words)"
            }
            val seedHint = if (topicSeed.isNotBlank()) "Topic hint from user: \"$topicSeed\"." else "Invent an original trending idea."
            val prompt = """
                You are JIMI, an imaginative AI scriptwriter fluent in $targetLang.
                Write a ready-to-generate video script exclusively in $targetLang.
                Category: $catLabel.
                Art style: ${artStyle.name.lowercase()} (${artStyle.promptEnglish}).
                Length: $sentenceTarget.
                $seedHint
                Return ONLY the clean spoken/scene script text without quotes, markdown, or emojis.
            """.trimIndent()

            val payload = JSONObject().apply {
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                        }
                    )
                )
            }

            val responseJson = withTimeout(35_000L) {
                postJson(
                    url = "$BASE_URL/$TEXT_MODEL:generateContent",
                    apiKey = cleanKey,
                    body = payload,
                    readTimeoutMs = 30_000
                )
            }
            val text = extractFirstText(responseJson).trim()
            if (text.isNotEmpty()) {
                Result.success(text)
            } else {
                Result.failure(Exception("JIMI returned an empty script."))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Script writer timed out", e)
            Result.failure(Exception("Request timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Script writer failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Failed to write script."))
        }
    }

    suspend fun planVideoFromPrompt(
        apiKey: String,
        userText: String,
        category: VideoCategory?,
        language: AppLanguage,
        expandScript: Boolean,
        artStyle: VideoArtStyle = VideoArtStyle.FANTASY,
        duration: VideoDuration = VideoDuration.S10,
        quality: VideoQuality = VideoQuality.HD,
        aspectHint: String = "balanced 1:1 composition"
    ): Result<EnhancedVideoPlan> {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return Result.failure(MissingGeminiApiKeyException())
        }
        return try {
            val categoryContext = category?.let { "Category: ${it.titleAr} (${it.id})." } ?: "General creative video."
            val targetLang = language.aiLanguageInstruction
            val styleContext = "Required visual style: ${artStyle.promptEnglish}. Quality: ${quality.promptSuffix}. Framing: $aspectHint."
            val instruction = if (expandScript) {
                """
                You are an expert AI video director fluent in $targetLang.
                $categoryContext
                $styleContext
                Target clip duration: ${duration.seconds} seconds.
                User idea: "$userText"
                1) Create an engaging voiceover script in $targetLang fitting ~${duration.seconds}s (no emojis, ready for Text-to-Speech).
                2) Create a short title in $targetLang.
                3) Write a vivid English image generation prompt incorporating the exact visual style (${artStyle.promptEnglish}) and $aspectHint (portrait/medium shot facing camera if there is a speaker/narrator).
                """.trimIndent()
            } else {
                """
                You are a creative visual prompt translator for a multilingual AI video app.
                Target output language: $targetLang.
                $categoryContext
                $styleContext
                User narration text: "$userText"
                1) Keep narrationDarija faithful to the user's text in $targetLang (clean up only symbols/emojis so Text-to-Speech reads it smoothly).
                2) Create a short title in $targetLang summarizing the text.
                3) Translate and expand the visual scene into a detailed English image generation prompt explicitly applying the style "${artStyle.promptEnglish}", "${quality.promptSuffix}", and "$aspectHint".
                """.trimIndent()
            }

            val schema = JSONObject().apply {
                put("type", "OBJECT")
                put(
                    "properties",
                    JSONObject().apply {
                        put(
                            "titleArabic",
                            JSONObject().apply {
                                put("type", "STRING")
                                put("description", "A short catchy title (3-6 words) in the target language.")
                            }
                        )
                        put(
                            "narrationDarija",
                            JSONObject().apply {
                                put("type", "STRING")
                                put("description", "Natural voiceover script ready for TTS without emojis.")
                            }
                        )
                        put(
                            "visualPromptEnglish",
                            JSONObject().apply {
                                put("type", "STRING")
                                put("description", "Detailed English visual prompt matching the art style.")
                            }
                        )
                    }
                )
                put("required", JSONArray().put("titleArabic").put("narrationDarija").put("visualPromptEnglish"))
            }

            val payload = JSONObject().apply {
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().put(JSONObject().put("text", instruction)))
                        }
                    )
                )
                put(
                    "generationConfig",
                    JSONObject().apply {
                        put("responseMimeType", "application/json")
                        put("responseSchema", schema)
                    }
                )
            }

            val responseJson = withTimeout(45_000L) {
                postJson(
                    url = "$BASE_URL/$TEXT_MODEL:generateContent",
                    apiKey = cleanKey,
                    body = payload,
                    readTimeoutMs = 40_000
                )
            }

            val jsonText = extractFirstText(responseJson)
            if (jsonText.isBlank()) throw IllegalStateException("Empty model response.")
            val json = JSONObject(jsonText)
            val baseVisual = json.optString("visualPromptEnglish", userText)
            val enrichedVisual = "$baseVisual, ${artStyle.promptEnglish}, ${quality.promptSuffix}, $aspectHint"
            Result.success(
                EnhancedVideoPlan(
                    titleArabic = json.optString("titleArabic", userText.take(28)),
                    narrationDarija = json.optString("narrationDarija", userText).ifBlank { userText },
                    visualPromptEnglish = enrichedVisual
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Script planning timed out", e)
            Result.failure(Exception("Request timed out. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Script planning failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Failed to analyze prompt."))
        }
    }

    suspend fun generateImage(
        apiKey: String,
        visualPromptEnglish: String
    ): Result<Bitmap> {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return Result.failure(MissingGeminiApiKeyException())
        }
        return try {
            val payload = JSONObject().apply {
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().put(JSONObject().put("text", visualPromptEnglish)))
                        }
                    )
                )
                put(
                    "generationConfig",
                    JSONObject().apply {
                        put("responseModalities", JSONArray().put("IMAGE"))
                    }
                )
            }

            val responseJson = withTimeout(60_000L) {
                postImageRequestWithFallback(apiKey = cleanKey, body = payload)
            }
            val bitmap = extractFirstBitmap(responseJson)
            if (bitmap != null) {
                Result.success(bitmap)
            } else {
                Result.failure(Exception("No image was returned by the Gemini model."))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Image generation timed out", e)
            Result.failure(Exception("Image generation timed out after 60 seconds."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Image generation failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Image generation failed."))
        }
    }

    suspend fun editImageWithAi(
        apiKey: String,
        inputBitmap: Bitmap,
        editInstruction: String
    ): Result<Bitmap> {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return Result.failure(MissingGeminiApiKeyException())
        }
        return try {
            val base64Jpeg = withContext(Dispatchers.Default) {
                val baos = ByteArrayOutputStream()
                inputBitmap.compress(Bitmap.CompressFormat.JPEG, 90, baos)
                Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
            }

            val parts = JSONArray().apply {
                put(
                    JSONObject().put(
                        "inlineData",
                        JSONObject().apply {
                            put("mimeType", "image/jpeg")
                            put("data", base64Jpeg)
                        }
                    )
                )
                put(
                    JSONObject().put(
                        "text",
                        "Edit this image carefully according to the instruction while preserving identity and natural coherence: $editInstruction"
                    )
                )
            }

            val payload = JSONObject().apply {
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject().apply {
                            put("role", "user")
                            put("parts", parts)
                        }
                    )
                )
                put(
                    "generationConfig",
                    JSONObject().apply {
                        put("responseModalities", JSONArray().put("IMAGE"))
                    }
                )
            }

            val responseJson = withTimeout(60_000L) {
                postImageRequestWithFallback(apiKey = cleanKey, body = payload)
            }
            val editedBitmap = extractFirstBitmap(responseJson)
            if (editedBitmap != null) {
                Result.success(editedBitmap)
            } else {
                Result.failure(Exception("The AI editor did not return an edited image."))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI image edit timed out", e)
            Result.failure(Exception("AI image editing timed out after 60 seconds."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI image editing failed", e)
            Result.failure(Exception(e.localizedMessage ?: "AI image editing failed."))
        }
    }

    fun streamRobotReply(
        apiKey: String,
        history: List<ChatMessage>,
        userQuestion: String,
        language: AppLanguage,
        robotName: String,
        personality: RobotPersonality
    ): Flow<String> = flow {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            throw MissingGeminiApiKeyException()
        }

        val targetLang = language.aiLanguageInstruction
        val systemGuidance = """
            You are an AI Robot assistant named "$robotName" inside a mobile app.
            Personality style: ${personality.promptInstruction}
            You can answer any question clearly: school lessons, homework help, short stories, fun jokes, science, coding, and daily advice.
            IMPORTANT: Always respond exclusively in $targetLang.
            Keep your answers clear, concise (2-5 sentences unless a step-by-step explanation is needed), and easy to read aloud cleanly (avoid excessive markdown symbols).
        """.trimIndent()

        val contentsArray = JSONArray()
        history
            .filter { !it.isStreaming && it.text.isNotBlank() }
            .takeLast(8)
            .forEach { msg ->
                contentsArray.put(
                    JSONObject().apply {
                        put("role", if (msg.isFromUser) "user" else "model")
                        put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                    }
                )
            }
        contentsArray.put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", userQuestion)))
            }
        )

        val payload = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemGuidance)))
            )
            put("contents", contentsArray)
        }

        val url = URL("$BASE_URL/$TEXT_MODEL:streamGenerateContent?alt=sse")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 60_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("x-goog-api-key", cleanKey)
        }

        try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(payload.toString())
            }

            val code = conn.responseCode
            if (code !in 200..299) {
                val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw IllegalStateException(parseGeminiErrorMessage(code, errBody))
            }

            val accumulated = StringBuilder()
            withTimeout(60_000L) {
                BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { reader ->
                    while (true) {
                        val line = reader.readLine() ?: break
                        if (line.startsWith("data:")) {
                            val rawJson = line.removePrefix("data:").trim()
                            if (rawJson.isNotEmpty() && rawJson != "[DONE]") {
                                val chunkJson = runCatching { JSONObject(rawJson) }.getOrNull()
                                val delta = chunkJson?.let { extractFirstText(it) }.orEmpty()
                                if (delta.isNotEmpty()) {
                                    accumulated.append(delta)
                                    emit(accumulated.toString())
                                }
                            }
                        }
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException("JIMI returned an empty response.")
            }
        } finally {
            conn.disconnect()
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun postImageRequestWithFallback(
        apiKey: String,
        body: JSONObject
    ): JSONObject {
        return try {
            postJson(
                url = "$BASE_URL/$IMAGE_MODEL_PRIMARY:generateContent",
                apiKey = apiKey,
                body = body,
                readTimeoutMs = 55_000
            )
        } catch (e: HttpStatusException) {
            if (e.code == 404) {
                postJson(
                    url = "$BASE_URL/$IMAGE_MODEL_FALLBACK:generateContent",
                    apiKey = apiKey,
                    body = body,
                    readTimeoutMs = 55_000
                )
            } else {
                throw e
            }
        }
    }

    private suspend fun postJson(
        url: String,
        apiKey: String,
        body: JSONObject,
        readTimeoutMs: Int
    ): JSONObject = withContext(Dispatchers.IO) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = readTimeoutMs
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(body.toString())
            }
            val code = conn.responseCode
            val raw = if (code in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                val errBody = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw HttpStatusException(code, parseGeminiErrorMessage(code, errBody))
            }
            JSONObject(raw)
        } finally {
            conn.disconnect()
        }
    }

    private fun extractFirstText(responseJson: JSONObject): String {
        val candidates = responseJson.optJSONArray("candidates") ?: return ""
        val first = candidates.optJSONObject(0) ?: return ""
        val content = first.optJSONObject("content") ?: return ""
        val parts = content.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            val t = part.optString("text", "")
            if (t.isNotEmpty()) sb.append(t)
        }
        return sb.toString()
    }

    private fun extractFirstBitmap(responseJson: JSONObject): Bitmap? {
        val candidates = responseJson.optJSONArray("candidates") ?: return null
        val first = candidates.optJSONObject(0) ?: return null
        val content = first.optJSONObject("content") ?: return null
        val parts = content.optJSONArray("parts") ?: return null
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            val inlineObj = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data")
            val b64 = inlineObj?.optString("data", "").orEmpty()
            if (b64.isNotEmpty()) {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp != null) return bmp
            }
        }
        return null
    }

    private fun parseGeminiErrorMessage(code: Int, errBody: String): String {
        val apiMsg = runCatching {
            JSONObject(errBody).optJSONObject("error")?.optString("message", "")
        }.getOrNull().orEmpty()
        return when {
            code == 400 && apiMsg.contains("API key", ignoreCase = true) ->
                "Invalid Gemini API Key. Please check or update your key in Settings."
            code == 401 || code == 403 ->
                "Gemini API Key unauthorized or invalid. Please update your key in Settings."
            code == 429 ->
                "Gemini API rate limit or quota exceeded for your key. Please try again shortly."
            apiMsg.isNotBlank() -> apiMsg
            else -> "Gemini API error (HTTP $code)"
        }
    }

    private class HttpStatusException(val code: Int, message: String) : Exception(message)
}
