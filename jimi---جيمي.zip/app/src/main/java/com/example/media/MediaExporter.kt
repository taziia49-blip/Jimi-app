package com.example.media

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import com.example.ui.model.GeneratedMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

private const val TAG = "MediaExporter"

data class ExportResult(
    val shareUri: Uri,
    val mimeType: String,
    val message: String
)

object MediaExporter {

    suspend fun exportMedia(
        context: Context,
        media: GeneratedMedia,
        asVideo: Boolean
    ): Result<ExportResult> = withContext(Dispatchers.IO) {
        try {
            val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
            if (asVideo && media.isVideoAnimated) {
                val mp4File = File(exportsDir, "jimi_video_${media.id}.mp4")
                val encoded = tryEncodeMp4(media, mp4File)
                if (encoded && mp4File.exists() && mp4File.length() > 0L) {
                    saveVideoToGallery(context, mp4File, media.title)
                    val uri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        mp4File
                    )
                    return@withContext Result.success(
                        ExportResult(
                            shareUri = uri,
                            mimeType = "video/mp4",
                            message = "تم حفظ الفيديو بصيغة MP4 بنجاح"
                        )
                    )
                }
            }

            // Image export with optional filter baked in
            val pngFile = File(exportsDir, "jimi_image_${media.id}.png")
            val filteredBitmap = renderFilteredBitmap(media)
            FileOutputStream(pngFile).use { out ->
                filteredBitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
            }
            if (filteredBitmap !== media.bitmap) {
                filteredBitmap.recycle()
            }
            saveImageToGallery(context, pngFile, media.title)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pngFile
            )
            Result.success(
                ExportResult(
                    shareUri = uri,
                    mimeType = "image/png",
                    message = "تم حفظ الصورة في المعرض بنجاح"
                )
            )
        } catch (e: Exception) {
            Log.e(TAG, "Export failed", e)
            Result.failure(Exception("تعذر حفظ الملف: ${e.localizedMessage ?: "خطأ غير معروف"}"))
        }
    }

    private fun renderFilteredBitmap(media: GeneratedMedia): Bitmap {
        val cm = media.filter.toColorMatrix() ?: return media.bitmap
        val out = Bitmap.createBitmap(media.bitmap.width, media.bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        }
        canvas.drawBitmap(media.bitmap, 0f, 0f, paint)
        return out
    }

    private fun computeEvenDimensions(media: GeneratedMedia): Pair<Int, Int> {
        val maxSide = media.quality.exportMaxSide
        val ratio = media.aspectRatio.coerceIn(0.45f, 2.2f)
        val rawW: Int
        val rawH: Int
        if (ratio >= 1f) {
            rawW = maxSide
            rawH = (maxSide / ratio).roundToInt()
        } else {
            rawH = maxSide
            rawW = (maxSide * ratio).roundToInt()
        }
        // Video codecs require dimensions divisible by 16 (or at least 2)
        val evenW = ((rawW / 16) * 16).coerceAtLeast(320)
        val evenH = ((rawH / 16) * 16).coerceAtLeast(320)
        return evenW to evenH
    }

    private fun tryEncodeMp4(media: GeneratedMedia, outFile: File): Boolean {
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var inputSurface: android.view.Surface? = null
        var muxerStarted = false

        return try {
            val (width, height) = computeEvenDimensions(media)
            val fps = 24
            // Keep exported MP4 crisp and fast while honoring user selection up to 12s per clip
            val clipSeconds = media.durationSeconds.coerceIn(5, 12)
            val totalFrames = fps * clipSeconds
            val bitRate = if (media.quality.exportMaxSide >= 1080) 3_800_000 else 2_200_000

            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = codec.createInputSurface()
            codec.start()

            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var trackIndex = -1
            val bufferInfo = MediaCodec.BufferInfo()

            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG)

            for (frameIdx in 0 until totalFrames) {
                val timeSec = frameIdx.toFloat() / fps
                val canvas = inputSurface.lockCanvas(null)
                try {
                    drawAnimatedFrame(
                        canvas = canvas,
                        canvasW = width.toFloat(),
                        canvasH = height.toFloat(),
                        media = media,
                        timeSec = timeSec,
                        isSpeaking = true,
                        bitmapPaint = paint,
                        overlayPaint = overlayPaint
                    )
                } finally {
                    inputSurface.unlockCanvasAndPost(canvas)
                }

                trackIndex = drainEncoder(codec, muxer, bufferInfo, trackIndex, endOfStream = false) { newTrack ->
                    muxer.start()
                    muxerStarted = true
                    newTrack
                }
            }

            codec.signalEndOfInputStream()
            trackIndex = drainEncoder(codec, muxer, bufferInfo, trackIndex, endOfStream = true) { newTrack ->
                if (!muxerStarted) {
                    muxer.start()
                    muxerStarted = true
                }
                newTrack
            }
            muxerStarted && trackIndex >= 0
        } catch (e: Exception) {
            Log.w(TAG, "MP4 hardware/software encoding failed, falling back to image", e)
            false
        } finally {
            try { inputSurface?.release() } catch (_: Exception) {}
            try { codec?.stop(); codec?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop(); muxer?.release() } catch (_: Exception) {}
        }
    }

    private fun drainEncoder(
        codec: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        currentTrackIndex: Int,
        endOfStream: Boolean,
        onFormatChanged: (Int) -> Int
    ): Int {
        var trackIdx = currentTrackIndex
        while (true) {
            val status = codec.dequeueOutputBuffer(bufferInfo, if (endOfStream) 10_000L else 0L)
            when {
                status == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) break
                }
                status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    trackIdx = onFormatChanged(muxer.addTrack(codec.outputFormat))
                }
                status >= 0 -> {
                    val encodedData = codec.getOutputBuffer(status)
                    if (encodedData != null && bufferInfo.size > 0 &&
                        (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 &&
                        trackIdx >= 0
                    ) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(trackIdx, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(status, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                }
            }
        }
        return trackIdx
    }

    fun drawAnimatedFrame(
        canvas: Canvas,
        canvasW: Float,
        canvasH: Float,
        media: GeneratedMedia,
        timeSec: Float,
        isSpeaking: Boolean,
        bitmapPaint: Paint,
        overlayPaint: Paint
    ) {
        canvas.drawColor(Color.BLACK)
        val bmp = media.bitmap
        val landmarks = media.faceLandmarks
        val action = media.photoAction

        // Apply active color filter to bitmapPaint
        val cm = media.filter.toColorMatrix()
        bitmapPaint.colorFilter = cm?.let { ColorMatrixColorFilter(it) }

        val zoom = 1.03f + 0.09f * ((sin(timeSec * 0.6f) + 1f) * 0.5f)
        val panAmpX = when (action) {
            com.example.ui.model.PhotoAction.MOVE_HEAD -> 0.042f
            com.example.ui.model.PhotoAction.SING -> 0.032f
            com.example.ui.model.PhotoAction.LAUGH -> 0.028f
            else -> 0.022f
        }
        val panFreqX = when (action) {
            com.example.ui.model.PhotoAction.MOVE_HEAD -> 1.75f
            com.example.ui.model.PhotoAction.SING -> 2.1f
            com.example.ui.model.PhotoAction.LAUGH -> 3.0f
            else -> 0.95f
        }
        val panX = sin(timeSec * panFreqX) * (canvasW * panAmpX)
        val panY = when (action) {
            com.example.ui.model.PhotoAction.LAUGH -> abs(sin(timeSec * 7.2f)) * (-canvasH * 0.015f)
            com.example.ui.model.PhotoAction.SING -> sin(timeSec * 4.2f) * (canvasH * 0.012f)
            com.example.ui.model.PhotoAction.CRY -> (canvasH * 0.012f) + sin(timeSec * 1.4f) * (canvasH * 0.008f)
            else -> sin(timeSec * 0.6f + 0.9f) * (canvasH * 0.014f)
        }
        val headTiltDeg = when (action) {
            com.example.ui.model.PhotoAction.MOVE_HEAD -> sin(timeSec * 1.85f) * 4.6f
            com.example.ui.model.PhotoAction.SING -> sin(timeSec * 2.4f) * 3.4f
            com.example.ui.model.PhotoAction.LAUGH -> sin(timeSec * 5.2f) * 2.8f
            com.example.ui.model.PhotoAction.SMILE -> sin(timeSec * 1.1f) * 2.2f
            com.example.ui.model.PhotoAction.CRY -> -2.2f + sin(timeSec * 1.3f) * 1.2f
            com.example.ui.model.PhotoAction.SPEAK -> if (isSpeaking) {
                sin(timeSec * 2.1f) * 2.1f + sin(timeSec * 4.3f) * 0.6f
            } else {
                sin(timeSec * 0.9f) * 0.9f
            }
        }
        val breathY = if (isSpeaking) abs(sin(timeSec * 4.2f)) * (canvasH * 0.006f) else 0f

        canvas.save()
        canvas.translate(canvasW / 2f + panX, canvasH / 2f + panY + breathY)
        canvas.rotate(headTiltDeg)
        canvas.scale(zoom, zoom)

        val scale = maxOf(canvasW / bmp.width, canvasH / bmp.height)
        val drawW = bmp.width * scale
        val drawH = bmp.height * scale
        val left = -drawW / 2f
        val top = -drawH / 2f
        val destRect = RectF(left, top, left + drawW, top + drawH)
        canvas.drawBitmap(bmp, null, destRect, bitmapPaint)

        if (landmarks.hasFace) {
            val blinkInterval = if (action == com.example.ui.model.PhotoAction.CRY) 2.1f else 3.1f
            val blinkPhase = (timeSec % blinkInterval)
            val blinkStart = blinkInterval - 0.32f
            val blinkEnd = blinkInterval - 0.12f
            val blinkAmount = if (blinkPhase in blinkStart..blinkEnd) {
                sin(((blinkPhase - blinkStart) / 0.20f) * PI).toFloat().coerceIn(0f, 1f)
            } else 0f

            val eyeR = landmarks.eyeRadiusNorm * drawW
            val lx = left + landmarks.leftEyeX * drawW
            val ly = top + landmarks.leftEyeY * drawH
            val rx = left + landmarks.rightEyeX * drawW
            val ry = top + landmarks.rightEyeY * drawH

            if (blinkAmount > 0.04f) {
                overlayPaint.color = landmarks.skinColorArgb
                overlayPaint.style = Paint.Style.FILL
                val lidHalfH = eyeR * 0.9f * blinkAmount

                canvas.drawOval(
                    RectF(lx - eyeR * 1.2f, ly - lidHalfH, lx + eyeR * 1.2f, ly + lidHalfH),
                    overlayPaint
                )
                canvas.drawOval(
                    RectF(rx - eyeR * 1.2f, ry - lidHalfH, rx + eyeR * 1.2f, ry + lidHalfH),
                    overlayPaint
                )
            }

            if (action == com.example.ui.model.PhotoAction.CRY) {
                overlayPaint.style = Paint.Style.FILL
                overlayPaint.color = Color.argb(190, 125, 211, 252)
                for (dropIdx in 0..1) {
                    val tProgress = ((timeSec * 0.85f + dropIdx * 0.5f) % 1f)
                    val tearAlpha = ((1f - tProgress) * 210).toInt().coerceIn(0, 210)
                    overlayPaint.alpha = tearAlpha
                    val dropOffsetY = eyeR * 0.8f + tProgress * (drawH * 0.14f)
                    val dropR = eyeR * 0.32f
                    canvas.drawOval(
                        RectF(lx - dropR, ly + dropOffsetY - dropR * 1.3f, lx + dropR, ly + dropOffsetY + dropR * 1.3f),
                        overlayPaint
                    )
                    canvas.drawOval(
                        RectF(rx - dropR, ry + dropOffsetY - dropR * 1.3f, rx + dropR, ry + dropOffsetY + dropR * 1.3f),
                        overlayPaint
                    )
                }
                overlayPaint.alpha = 255
            } else if (action == com.example.ui.model.PhotoAction.SMILE || action == com.example.ui.model.PhotoAction.LAUGH) {
                val cheekY = top + (landmarks.leftEyeY + (landmarks.mouthCenterY - landmarks.leftEyeY) * 0.62f) * drawH
                val cheekR = eyeR * 1.45f
                overlayPaint.style = Paint.Style.FILL
                overlayPaint.color = Color.argb(42, 244, 114, 182)
                canvas.drawOval(RectF(lx - cheekR, cheekY - cheekR * 0.6f, lx + cheekR, cheekY + cheekR * 0.6f), overlayPaint)
                canvas.drawOval(RectF(rx - cheekR, cheekY - cheekR * 0.6f, rx + cheekR, cheekY + cheekR * 0.6f), overlayPaint)
                overlayPaint.alpha = 255
            }

            val mouthCx = left + landmarks.mouthCenterX * drawW
            val mouthCy = top + landmarks.mouthCenterY * drawH
            val mouthW = landmarks.mouthWidthNorm * drawW
            val mouthH = landmarks.mouthHeightNorm * drawH

            val jawMultiplier = when (action) {
                com.example.ui.model.PhotoAction.LAUGH -> 1.25f
                com.example.ui.model.PhotoAction.SING -> 1.15f
                com.example.ui.model.PhotoAction.SMILE -> 0.85f
                com.example.ui.model.PhotoAction.CRY -> 0.70f
                else -> 1.0f
            }

            if (isSpeaking) {
                val baseOsc = (abs(sin(timeSec * 9.5f)) * 0.65f + abs(sin(timeSec * 14.2f)) * 0.35f)
                    .coerceIn(0f, 1f)
                val jawOsc = (baseOsc * jawMultiplier).coerceIn(0f, 1.15f)
                val jawDropPx = mouthH * 0.58f * jawOsc

                overlayPaint.style = Paint.Style.FILL
                overlayPaint.color = landmarks.lipShadowArgb
                overlayPaint.alpha = (190 * jawOsc.coerceAtMost(1f)).toInt()
                canvas.drawOval(
                    RectF(
                        mouthCx - mouthW * 0.36f,
                        mouthCy - mouthH * 0.12f,
                        mouthCx + mouthW * 0.36f,
                        mouthCy + jawDropPx * 0.92f + mouthH * 0.16f
                    ),
                    overlayPaint
                )
                overlayPaint.alpha = 255

                val srcLeft = ((landmarks.mouthCenterX - landmarks.mouthWidthNorm * 0.7f) * bmp.width)
                    .toInt().coerceIn(0, bmp.width - 2)
                val srcRight = ((landmarks.mouthCenterX + landmarks.mouthWidthNorm * 0.7f) * bmp.width)
                    .toInt().coerceIn(srcLeft + 1, bmp.width)
                val srcTop = (landmarks.mouthCenterY * bmp.height)
                    .toInt().coerceIn(0, bmp.height - 2)
                val srcBottom = ((landmarks.mouthCenterY + landmarks.mouthHeightNorm * 1.4f) * bmp.height)
                    .toInt().coerceIn(srcTop + 1, bmp.height)

                val dstLeft = mouthCx - mouthW * 0.7f
                val dstRight = mouthCx + mouthW * 0.7f
                val dstTop = mouthCy + jawDropPx * 0.55f
                val dstBottom = mouthCy + mouthH * 1.4f + jawDropPx

                canvas.drawBitmap(
                    bmp,
                    Rect(srcLeft, srcTop, srcRight, srcBottom),
                    RectF(dstLeft, dstTop, dstRight, dstBottom),
                    bitmapPaint
                )
            } else if (action == com.example.ui.model.PhotoAction.SMILE) {
                overlayPaint.style = Paint.Style.STROKE
                overlayPaint.strokeWidth = (mouthH * 0.16f).coerceAtLeast(3f)
                overlayPaint.color = Color.argb(110, 120, 40, 40)
                canvas.drawArc(
                    RectF(mouthCx - mouthW * 0.4f, mouthCy - mouthH * 0.2f, mouthCx + mouthW * 0.4f, mouthCy + mouthH * 0.5f),
                    15f,
                    150f,
                    false,
                    overlayPaint
                )
                overlayPaint.style = Paint.Style.FILL
            }
        }
        canvas.restore()

        if (action == com.example.ui.model.PhotoAction.SING) {
            overlayPaint.style = Paint.Style.FILL
            overlayPaint.textSize = canvasW * 0.065f
            val notes = listOf("♪", "♫", "♩")
            for (i in 0..2) {
                val p = ((timeSec * 0.55f + i * 0.33f) % 1f)
                val nx = canvasW * (0.15f + i * 0.34f) + sin(timeSec * 2.5f + i) * (canvasW * 0.04f)
                val ny = canvasH * (0.72f - p * 0.55f)
                overlayPaint.color = Color.argb(((1f - p) * 220).toInt().coerceIn(0, 220), 96, 165, 250)
                canvas.drawText(notes[i % notes.size], nx, ny, overlayPaint)
            }
            overlayPaint.alpha = 255
        }
    }

    private fun saveVideoToGallery(context: Context, sourceFile: File, title: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "${sanitizeName(title)}_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/JimiVideoAI")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return
            resolver.openOutputStream(uri)?.use { out ->
                sourceFile.inputStream().use { input -> input.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        }
    }

    private fun saveImageToGallery(context: Context, sourceFile: File, title: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "${sanitizeName(title)}_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/JimiVideoAI")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
            resolver.openOutputStream(uri)?.use { out ->
                sourceFile.inputStream().use { input -> input.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        }
    }

    private fun sanitizeName(raw: String): String {
        val cleaned = raw.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").take(24)
        return cleaned.ifBlank { "jimi_ai" }
    }
}
