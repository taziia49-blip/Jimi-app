package com.example.media

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

private const val TAG = "VoiceInputManager"

data class VoiceInputState(
    val isAvailable: Boolean = true,
    val isListening: Boolean = false,
    val isWakeMonitorActive: Boolean = false,
    val partialText: String = "",
    val rmsLevel: Float = 0f,
    val errorMessage: String? = null
)

class VoiceInputManager(context: Context) {

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _state = MutableStateFlow(
        VoiceInputState(isAvailable = SpeechRecognizer.isRecognitionAvailable(appContext))
    )
    val state: StateFlow<VoiceInputState> = _state.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var onFinalResultCallback: ((String) -> Unit)? = null
    private var wakeLoopActive = false
    private var wakeLanguageTag = "ar-MA"
    private var wakeOnTranscriptCallback: ((String) -> Unit)? = null
    private var isPausedForSpeech = false

    fun startListening(languageTag: String, unavailableMsg: String, onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            _state.update { it.copy(isAvailable = false, errorMessage = unavailableMsg) }
            return
        }

        stopCurrentRecognizerOnly()
        onFinalResultCallback = onResult
        launchRecognizer(languageTag = languageTag, isWakeLoop = false, unavailableMsg = unavailableMsg)
    }

    fun startWakeWordLoop(
        languageTag: String,
        unavailableMsg: String,
        onTranscript: (String) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            _state.update {
                it.copy(
                    isAvailable = false,
                    isWakeMonitorActive = false,
                    errorMessage = unavailableMsg
                )
            }
            return
        }
        wakeLoopActive = true
        wakeLanguageTag = languageTag
        wakeOnTranscriptCallback = onTranscript
        _state.update { it.copy(isWakeMonitorActive = true, errorMessage = null) }
        if (!isPausedForSpeech && !_state.value.isListening) {
            launchRecognizer(languageTag = languageTag, isWakeLoop = true, unavailableMsg = unavailableMsg)
        }
    }

    fun stopWakeWordLoop() {
        wakeLoopActive = false
        wakeOnTranscriptCallback = null
        mainHandler.removeCallbacksAndMessages(null)
        stopCurrentRecognizerOnly()
        _state.update { it.copy(isWakeMonitorActive = false, isListening = false, rmsLevel = 0f) }
    }

    fun setPausedForTts(paused: Boolean) {
        isPausedForSpeech = paused
        if (paused) {
            if (wakeLoopActive) {
                mainHandler.removeCallbacksAndMessages(null)
                stopCurrentRecognizerOnly()
            }
        } else if (wakeLoopActive && !_state.value.isListening) {
            scheduleNextWakeCycle(450L)
        }
    }

    private fun scheduleNextWakeCycle(delayMs: Long) {
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({
            if (wakeLoopActive && !isPausedForSpeech && !_state.value.isListening) {
                launchRecognizer(
                    languageTag = wakeLanguageTag,
                    isWakeLoop = true,
                    unavailableMsg = ""
                )
            }
        }, delayMs)
    }

    private fun launchRecognizer(
        languageTag: String,
        isWakeLoop: Boolean,
        unavailableMsg: String
    ) {
        stopCurrentRecognizerOnly()
        try {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(appContext)
            speechRecognizer = recognizer
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _state.update {
                        it.copy(
                            isListening = true,
                            partialText = if (isWakeLoop) it.partialText else "",
                            errorMessage = null
                        )
                    }
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    val norm = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                    _state.update { it.copy(rmsLevel = norm) }
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _state.update { it.copy(isListening = false, rmsLevel = 0f) }
                }

                override fun onError(error: Int) {
                    Log.w(TAG, "SpeechRecognizer error code=$error isWakeLoop=$isWakeLoop")
                    _state.update { it.copy(isListening = false, rmsLevel = 0f) }
                    if (isWakeLoop && wakeLoopActive && !isPausedForSpeech) {
                        val backoff = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                            error == SpeechRecognizer.ERROR_CLIENT
                        ) 1200L else 550L
                        scheduleNextWakeCycle(backoff)
                    }
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull()?.trim().orEmpty()
                    _state.update { it.copy(isListening = false, partialText = "", rmsLevel = 0f) }
                    if (isWakeLoop) {
                        if (spoken.isNotEmpty()) {
                            wakeOnTranscriptCallback?.invoke(spoken)
                        }
                        if (wakeLoopActive && !isPausedForSpeech) {
                            scheduleNextWakeCycle(600L)
                        }
                    } else {
                        if (spoken.isNotEmpty()) {
                            onFinalResultCallback?.invoke(spoken)
                        }
                        if (wakeLoopActive && !isPausedForSpeech) {
                            scheduleNextWakeCycle(800L)
                        }
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                    if (partial.isNotBlank()) {
                        _state.update { it.copy(partialText = partial) }
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            _state.update { it.copy(isListening = true, errorMessage = null) }
            recognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start SpeechRecognizer", e)
            _state.update {
                it.copy(
                    isListening = false,
                    rmsLevel = 0f,
                    errorMessage = unavailableMsg.ifBlank { null }
                )
            }
        }
    }

    private fun stopCurrentRecognizerOnly() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
    }

    fun stopListening() {
        stopCurrentRecognizerOnly()
        _state.update { it.copy(isListening = false, rmsLevel = 0f) }
        if (wakeLoopActive && !isPausedForSpeech) {
            scheduleNextWakeCycle(700L)
        }
    }

    fun clearError() {
        _state.update { it.copy(errorMessage = null) }
    }

    fun destroy() {
        wakeLoopActive = false
        mainHandler.removeCallbacksAndMessages(null)
        stopCurrentRecognizerOnly()
        _state.update { it.copy(isListening = false, isWakeMonitorActive = false, rmsLevel = 0f) }
    }
}
