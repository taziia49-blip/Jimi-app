package com.example.media

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import com.example.ui.model.BackgroundMusicMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

private const val TAG = "AmbientMusicPlayer"

class AmbientMusicPlayer {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var playJob: Job? = null

    fun start(mode: BackgroundMusicMode) {
        stop()
        if (mode == BackgroundMusicMode.NONE) return

        playJob = scope.launch {
            val sampleRate = 22050
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(2048)

            var track: AudioTrack? = null
            try {
                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBuf)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                track.play()

                val chunkSamples = 1024
                val pcm = ShortArray(chunkSamples)
                var sampleIndex = 0L

                val notes = when (mode) {
                    BackgroundMusicMode.ENERGETIC -> doubleArrayOf(261.63, 329.63, 392.00, 523.25, 392.00, 440.00, 493.88, 523.25)
                    BackgroundMusicMode.CALM -> doubleArrayOf(220.00, 261.63, 329.63, 392.00, 329.63, 293.66, 261.63, 246.94)
                    BackgroundMusicMode.FUNNY -> doubleArrayOf(392.00, 440.00, 523.25, 493.88, 587.33, 523.25, 659.25, 523.25)
                    BackgroundMusicMode.NONE -> doubleArrayOf(0.0)
                }
                val noteDurationSec = when (mode) {
                    BackgroundMusicMode.ENERGETIC -> 0.28
                    BackgroundMusicMode.CALM -> 0.85
                    BackgroundMusicMode.FUNNY -> 0.24
                    BackgroundMusicMode.NONE -> 1.0
                }
                val baseGain = when (mode) {
                    BackgroundMusicMode.ENERGETIC -> 1800.0
                    BackgroundMusicMode.CALM -> 1400.0
                    BackgroundMusicMode.FUNNY -> 1700.0
                    BackgroundMusicMode.NONE -> 0.0
                }

                while (isActive) {
                    for (i in 0 until chunkSamples) {
                        val t = (sampleIndex + i).toDouble() / sampleRate
                        val noteSlot = (t / noteDurationSec).toInt()
                        val localT = t - noteSlot * noteDurationSec
                        val freq = notes[noteSlot % notes.size]
                        val env = when (mode) {
                            BackgroundMusicMode.CALM -> sin(PI * (localT / noteDurationSec).coerceIn(0.0, 1.0))
                            BackgroundMusicMode.ENERGETIC -> exp(-localT * 4.5)
                            BackgroundMusicMode.FUNNY -> exp(-localT * 7.5)
                            BackgroundMusicMode.NONE -> 0.0
                        }
                        val wave = sin(2.0 * PI * freq * t) + 0.35 * sin(2.0 * PI * (freq * 0.5) * t)
                        val sample = (wave * env * baseGain).toInt().coerceIn(-32767, 32767)
                        pcm[i] = sample.toShort()
                    }
                    sampleIndex += chunkSamples
                    track.write(pcm, 0, chunkSamples)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Ambient music playback stopped", e)
            } finally {
                try {
                    track?.stop()
                    track?.release()
                } catch (_: Exception) {
                }
            }
        }
    }

    fun stop() {
        playJob?.cancel()
        playJob = null
    }
}
