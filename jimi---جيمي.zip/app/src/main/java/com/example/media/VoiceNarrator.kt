package com.example.media

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.ui.i18n.AppLanguage
import com.example.ui.model.VoiceSpeedOption
import com.example.ui.model.VoiceType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

private const val TAG = "VoiceNarrator"

data class SpeechUiState(
    val isTtsAvailable: Boolean = false,
    val isLanguageSupported: Boolean = false,
    val isVoiceEnabled: Boolean = true,
    val isSpeaking: Boolean = false,
    val speakingTag: String? = null,
    val progress: Float = 0f,
    val speechRate: Float = 1.0f,
    val voiceType: VoiceType = VoiceType.FEMALE,
    val activeLanguage: AppLanguage = AppLanguage.DARIJA,
    val activeLocaleLabel: String = AppLanguage.DARIJA.chipLabel,
    val currentWordRange: IntRange = IntRange.EMPTY
)

class VoiceNarrator(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _state = MutableStateFlow(SpeechUiState())
    val state: StateFlow<SpeechUiState> = _state.asStateFlow()

    private var tts: TextToSpeech? = null
    private var fallbackJob: Job? = null
    private var currentUtteranceId: String? = null
    private var currentTextLength: Int = 1
    private var onFinishedCallback: (() -> Unit)? = null

    init {
        try {
            tts = TextToSpeech(appContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    setupListener()
                    applyLanguage(_state.value.activeLanguage)
                } else {
                    Log.w(TAG, "TTS initialization returned status $status")
                    _state.update { it.copy(isTtsAvailable = false) }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to construct TextToSpeech", e)
        }
    }

    private fun setupListener() {
        val engine = tts ?: return
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                if (utteranceId == currentUtteranceId) {
                    scope.launch {
                        _state.update { it.copy(isSpeaking = true, progress = 0.02f) }
                    }
                }
            }

            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                if (utteranceId == currentUtteranceId) {
                    val pct = (end.toFloat() / currentTextLength.coerceAtLeast(1)).coerceIn(0f, 1f)
                    scope.launch {
                        _state.update {
                            it.copy(
                                isSpeaking = true,
                                progress = pct,
                                currentWordRange = start until end
                            )
                        }
                    }
                }
            }

            override fun onDone(utteranceId: String?) {
                if (utteranceId == currentUtteranceId) {
                    scope.launch {
                        _state.update {
                            it.copy(
                                isSpeaking = false,
                                speakingTag = null,
                                progress = 1f,
                                currentWordRange = IntRange.EMPTY
                            )
                        }
                        onFinishedCallback?.invoke()
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == currentUtteranceId) {
                    scope.launch {
                        _state.update { it.copy(isSpeaking = false, speakingTag = null) }
                    }
                }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                if (utteranceId == currentUtteranceId) {
                    Log.w(TAG, "TTS utterance error code=$errorCode")
                    scope.launch {
                        _state.update { it.copy(isSpeaking = false, speakingTag = null) }
                    }
                }
            }
        })
    }

    fun applyVoiceSettings(
        language: AppLanguage,
        enabled: Boolean,
        voiceType: VoiceType,
        speedOption: VoiceSpeedOption
    ) {
        if (!enabled) {
            stop()
        }
        _state.update {
            it.copy(
                activeLanguage = language,
                activeLocaleLabel = language.chipLabel,
                isVoiceEnabled = enabled,
                voiceType = voiceType,
                speechRate = speedOption.rate
            )
        }
        if (tts != null) {
            applyLanguage(language)
            tts?.setSpeechRate(speedOption.rate)
        }
    }

    fun setLanguage(language: AppLanguage) {
        _state.update {
            it.copy(
                activeLanguage = language,
                activeLocaleLabel = language.chipLabel
            )
        }
        if (tts != null) {
            applyLanguage(language)
        }
    }

    private fun applyLanguage(language: AppLanguage) {
        val engine = tts ?: return
        var matched = false
        for (locale in language.ttsLocales) {
            val res = engine.isLanguageAvailable(locale)
            if (res >= TextToSpeech.LANG_AVAILABLE) {
                engine.language = locale
                matched = true
                break
            }
        }
        if (!matched) {
            engine.language = language.ttsLocales.firstOrNull() ?: Locale.getDefault()
        }
        _state.update {
            it.copy(
                isTtsAvailable = true,
                isLanguageSupported = matched,
                activeLanguage = language,
                activeLocaleLabel = language.chipLabel
            )
        }
    }

    fun setSpeechRate(rate: Float) {
        val clamped = rate.coerceIn(0.65f, 1.5f)
        tts?.setSpeechRate(clamped)
        _state.update { it.copy(speechRate = clamped) }
    }

    fun speak(
        text: String,
        pitch: Float = 1.0f,
        tag: String? = null,
        onFinished: (() -> Unit)? = null
    ) {
        stop()
        val cleanText = text.replace(Regex("[\\p{So}\\p{Cn}]"), " ").trim()
        if (cleanText.isEmpty()) return

        onFinishedCallback = onFinished
        currentTextLength = cleanText.length

        // If Voice is turned OFF in settings, keep visual cadence silent
        if (!_state.value.isVoiceEnabled) {
            startVisualCadenceSafety(cleanText, tag = tag, onlyProgressIfStalled = false)
            return
        }

        val effectivePitch = (_state.value.voiceType.basePitch * pitch).coerceIn(0.65f, 1.5f)
        val engine = tts
        val canSpeakNative = engine != null && _state.value.isTtsAvailable

        if (canSpeakNative) {
            val id = UUID.randomUUID().toString()
            currentUtteranceId = id
            engine!!.setSpeechRate(_state.value.speechRate)
            engine.setPitch(effectivePitch)
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
            }
            val result = engine.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, id)
            if (result == TextToSpeech.SUCCESS) {
                _state.update { it.copy(isSpeaking = true, speakingTag = tag, progress = 0f) }
                startVisualCadenceSafety(cleanText, tag = tag, onlyProgressIfStalled = true)
                return
            }
        }

        startVisualCadenceSafety(cleanText, tag = tag, onlyProgressIfStalled = false)
    }

    private fun startVisualCadenceSafety(
        text: String,
        tag: String?,
        onlyProgressIfStalled: Boolean
    ) {
        fallbackJob?.cancel()
        fallbackJob = scope.launch {
            val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
            val durationMs = ((words.size.coerceAtLeast(4) * 380L) / _state.value.speechRate).toLong()
                .coerceIn(2800L, 22000L)
            val startTime = System.currentTimeMillis()
            if (!onlyProgressIfStalled) {
                _state.update { it.copy(isSpeaking = true, speakingTag = tag, progress = 0f) }
            }
            while (true) {
                val elapsed = System.currentTimeMillis() - startTime
                val pct = (elapsed.toFloat() / durationMs).coerceIn(0f, 1f)
                if (!onlyProgressIfStalled) {
                    _state.update { it.copy(isSpeaking = true, speakingTag = tag, progress = pct) }
                } else if (_state.value.isSpeaking && _state.value.progress < 0.03f && pct > 0.1f) {
                    _state.update { it.copy(progress = pct) }
                }
                if (pct >= 1f) {
                    if (!onlyProgressIfStalled) {
                        _state.update { it.copy(isSpeaking = false, speakingTag = null, progress = 1f) }
                        onFinishedCallback?.invoke()
                    }
                    break
                }
                delay(60L)
            }
        }
    }

    fun stop() {
        fallbackJob?.cancel()
        fallbackJob = null
        currentUtteranceId = null
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        _state.update {
            it.copy(isSpeaking = false, speakingTag = null, currentWordRange = IntRange.EMPTY)
        }
    }

    fun release() {
        stop()
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
    }
}
