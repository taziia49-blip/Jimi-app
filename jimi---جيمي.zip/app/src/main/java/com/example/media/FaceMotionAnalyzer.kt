package com.example.media

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import android.media.FaceDetector
import android.util.Log
import com.example.ui.model.FaceLandmarks
import kotlin.math.roundToInt

private const val TAG = "FaceMotionAnalyzer"

object FaceMotionAnalyzer {

    @Suppress("DEPRECATION")
    fun analyze(source: Bitmap): FaceLandmarks {
        return try {
            // Android FaceDetector requires RGB_565 and an even width
            val targetMaxDim = 512
            val scale = minOf(
                targetMaxDim.toFloat() / source.width.coerceAtLeast(1),
                targetMaxDim.toFloat() / source.height.coerceAtLeast(1),
                1f
            )
            var w = (source.width * scale).roundToInt().coerceAtLeast(2)
            if (w % 2 != 0) w -= 1
            val h = (source.height * scale).roundToInt().coerceAtLeast(2)

            val scaled = Bitmap.createScaledBitmap(source, w, h, true)
            val rgb565 = if (scaled.config == Bitmap.Config.RGB_565) {
                scaled
            } else {
                scaled.copy(Bitmap.Config.RGB_565, false)
            }

            val detector = FaceDetector(w, h, 1)
            val faces = arrayOfNulls<FaceDetector.Face>(1)
            val count = detector.findFaces(rgb565, faces)

            if (count > 0 && faces[0] != null) {
                val face = faces[0]!!
                val mid = PointF()
                face.getMidPoint(mid)
                val eyeDist = face.eyesDistance().coerceAtLeast(w * 0.05f)

                val leftEyeX = ((mid.x - eyeDist * 0.5f) / w).coerceIn(0.08f, 0.92f)
                val rightEyeX = ((mid.x + eyeDist * 0.5f) / w).coerceIn(0.08f, 0.92f)
                val eyesY = (mid.y / h).coerceIn(0.08f, 0.85f)

                val mouthX = (mid.x / w).coerceIn(0.15f, 0.85f)
                val mouthY = ((mid.y + eyeDist * 0.92f) / h).coerceIn(0.20f, 0.92f)
                val eyeRadiusNorm = (eyeDist * 0.28f / w).coerceIn(0.018f, 0.07f)
                val mouthWidthNorm = (eyeDist * 1.15f / w).coerceIn(0.08f, 0.30f)
                val mouthHeightNorm = (eyeDist * 0.55f / h).coerceIn(0.03f, 0.14f)

                // Sample forehead/cheek skin tone near eye bridge for natural eyelid blinking
                val sampleX = mid.x.roundToInt().coerceIn(0, w - 1)
                val sampleY = (mid.y - eyeDist * 0.35f).roundToInt().coerceIn(0, h - 1)
                val sampledPixel = rgb565.getPixel(sampleX, sampleY)
                val darkenedSkin = Color.rgb(
                    (Color.red(sampledPixel) * 0.88f).roundToInt(),
                    (Color.green(sampledPixel) * 0.85f).roundToInt(),
                    (Color.blue(sampledPixel) * 0.84f).roundToInt()
                )

                if (rgb565 !== scaled) rgb565.recycle()
                if (scaled !== source) scaled.recycle()

                FaceLandmarks(
                    hasFace = true,
                    leftEyeX = leftEyeX,
                    leftEyeY = eyesY,
                    rightEyeX = rightEyeX,
                    rightEyeY = eyesY,
                    eyeRadiusNorm = eyeRadiusNorm,
                    mouthCenterX = mouthX,
                    mouthCenterY = mouthY,
                    mouthWidthNorm = mouthWidthNorm,
                    mouthHeightNorm = mouthHeightNorm,
                    skinColorArgb = darkenedSkin
                )
            } else {
                if (rgb565 !== scaled) rgb565.recycle()
                if (scaled !== source) scaled.recycle()
                FaceLandmarks(hasFace = false)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Face detection skipped: ${e.message}")
            FaceLandmarks(hasFace = false)
        }
    }
}
